import fs from "node:fs/promises";
import http from "node:http";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import path from "node:path";
import os from "node:os";
import { spawn } from "node:child_process";
//#region node_modules/zod/v3/helpers/util.js
var util;
(function(util) {
	util.assertEqual = (_) => {};
	function assertIs(_arg) {}
	util.assertIs = assertIs;
	function assertNever(_x) {
		throw new Error();
	}
	util.assertNever = assertNever;
	util.arrayToEnum = (items) => {
		const obj = {};
		for (const item of items) obj[item] = item;
		return obj;
	};
	util.getValidEnumValues = (obj) => {
		const validKeys = util.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
		const filtered = {};
		for (const k of validKeys) filtered[k] = obj[k];
		return util.objectValues(filtered);
	};
	util.objectValues = (obj) => {
		return util.objectKeys(obj).map(function(e) {
			return obj[e];
		});
	};
	util.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
		const keys = [];
		for (const key in object) if (Object.prototype.hasOwnProperty.call(object, key)) keys.push(key);
		return keys;
	};
	util.find = (arr, checker) => {
		for (const item of arr) if (checker(item)) return item;
	};
	util.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
	function joinValues(array, separator = " | ") {
		return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
	}
	util.joinValues = joinValues;
	util.jsonStringifyReplacer = (_, value) => {
		if (typeof value === "bigint") return value.toString();
		return value;
	};
})(util || (util = {}));
var objectUtil;
(function(objectUtil) {
	objectUtil.mergeShapes = (first, second) => {
		return {
			...first,
			...second
		};
	};
})(objectUtil || (objectUtil = {}));
const ZodParsedType = util.arrayToEnum([
	"string",
	"nan",
	"number",
	"integer",
	"float",
	"boolean",
	"date",
	"bigint",
	"symbol",
	"function",
	"undefined",
	"null",
	"array",
	"object",
	"unknown",
	"promise",
	"void",
	"never",
	"map",
	"set"
]);
const getParsedType = (data) => {
	switch (typeof data) {
		case "undefined": return ZodParsedType.undefined;
		case "string": return ZodParsedType.string;
		case "number": return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
		case "boolean": return ZodParsedType.boolean;
		case "function": return ZodParsedType.function;
		case "bigint": return ZodParsedType.bigint;
		case "symbol": return ZodParsedType.symbol;
		case "object":
			if (Array.isArray(data)) return ZodParsedType.array;
			if (data === null) return ZodParsedType.null;
			if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") return ZodParsedType.promise;
			if (typeof Map !== "undefined" && data instanceof Map) return ZodParsedType.map;
			if (typeof Set !== "undefined" && data instanceof Set) return ZodParsedType.set;
			if (typeof Date !== "undefined" && data instanceof Date) return ZodParsedType.date;
			return ZodParsedType.object;
		default: return ZodParsedType.unknown;
	}
};
//#endregion
//#region node_modules/zod/v3/ZodError.js
const ZodIssueCode = util.arrayToEnum([
	"invalid_type",
	"invalid_literal",
	"custom",
	"invalid_union",
	"invalid_union_discriminator",
	"invalid_enum_value",
	"unrecognized_keys",
	"invalid_arguments",
	"invalid_return_type",
	"invalid_date",
	"invalid_string",
	"too_small",
	"too_big",
	"invalid_intersection_types",
	"not_multiple_of",
	"not_finite"
]);
var ZodError = class ZodError extends Error {
	get errors() {
		return this.issues;
	}
	constructor(issues) {
		super();
		this.issues = [];
		this.addIssue = (sub) => {
			this.issues = [...this.issues, sub];
		};
		this.addIssues = (subs = []) => {
			this.issues = [...this.issues, ...subs];
		};
		const actualProto = new.target.prototype;
		if (Object.setPrototypeOf) Object.setPrototypeOf(this, actualProto);
		else this.__proto__ = actualProto;
		this.name = "ZodError";
		this.issues = issues;
	}
	format(_mapper) {
		const mapper = _mapper || function(issue) {
			return issue.message;
		};
		const fieldErrors = { _errors: [] };
		const processError = (error) => {
			for (const issue of error.issues) if (issue.code === "invalid_union") issue.unionErrors.map(processError);
			else if (issue.code === "invalid_return_type") processError(issue.returnTypeError);
			else if (issue.code === "invalid_arguments") processError(issue.argumentsError);
			else if (issue.path.length === 0) fieldErrors._errors.push(mapper(issue));
			else {
				let curr = fieldErrors;
				let i = 0;
				while (i < issue.path.length) {
					const el = issue.path[i];
					if (!(i === issue.path.length - 1)) curr[el] = curr[el] || { _errors: [] };
					else {
						curr[el] = curr[el] || { _errors: [] };
						curr[el]._errors.push(mapper(issue));
					}
					curr = curr[el];
					i++;
				}
			}
		};
		processError(this);
		return fieldErrors;
	}
	static assert(value) {
		if (!(value instanceof ZodError)) throw new Error(`Not a ZodError: ${value}`);
	}
	toString() {
		return this.message;
	}
	get message() {
		return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
	}
	get isEmpty() {
		return this.issues.length === 0;
	}
	flatten(mapper = (issue) => issue.message) {
		const fieldErrors = {};
		const formErrors = [];
		for (const sub of this.issues) if (sub.path.length > 0) {
			const firstEl = sub.path[0];
			fieldErrors[firstEl] = fieldErrors[firstEl] || [];
			fieldErrors[firstEl].push(mapper(sub));
		} else formErrors.push(mapper(sub));
		return {
			formErrors,
			fieldErrors
		};
	}
	get formErrors() {
		return this.flatten();
	}
};
ZodError.create = (issues) => {
	return new ZodError(issues);
};
//#endregion
//#region node_modules/zod/v3/locales/en.js
const errorMap = (issue, _ctx) => {
	let message;
	switch (issue.code) {
		case ZodIssueCode.invalid_type:
			if (issue.received === ZodParsedType.undefined) message = "Required";
			else message = `Expected ${issue.expected}, received ${issue.received}`;
			break;
		case ZodIssueCode.invalid_literal:
			message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
			break;
		case ZodIssueCode.unrecognized_keys:
			message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
			break;
		case ZodIssueCode.invalid_union:
			message = `Invalid input`;
			break;
		case ZodIssueCode.invalid_union_discriminator:
			message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
			break;
		case ZodIssueCode.invalid_enum_value:
			message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
			break;
		case ZodIssueCode.invalid_arguments:
			message = `Invalid function arguments`;
			break;
		case ZodIssueCode.invalid_return_type:
			message = `Invalid function return type`;
			break;
		case ZodIssueCode.invalid_date:
			message = `Invalid date`;
			break;
		case ZodIssueCode.invalid_string:
			if (typeof issue.validation === "object") if ("includes" in issue.validation) {
				message = `Invalid input: must include "${issue.validation.includes}"`;
				if (typeof issue.validation.position === "number") message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
			} else if ("startsWith" in issue.validation) message = `Invalid input: must start with "${issue.validation.startsWith}"`;
			else if ("endsWith" in issue.validation) message = `Invalid input: must end with "${issue.validation.endsWith}"`;
			else util.assertNever(issue.validation);
			else if (issue.validation !== "regex") message = `Invalid ${issue.validation}`;
			else message = "Invalid";
			break;
		case ZodIssueCode.too_small:
			if (issue.type === "array") message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
			else if (issue.type === "string") message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
			else if (issue.type === "number") message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
			else if (issue.type === "bigint") message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
			else if (issue.type === "date") message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
			else message = "Invalid input";
			break;
		case ZodIssueCode.too_big:
			if (issue.type === "array") message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
			else if (issue.type === "string") message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
			else if (issue.type === "number") message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
			else if (issue.type === "bigint") message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
			else if (issue.type === "date") message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
			else message = "Invalid input";
			break;
		case ZodIssueCode.custom:
			message = `Invalid input`;
			break;
		case ZodIssueCode.invalid_intersection_types:
			message = `Intersection results could not be merged`;
			break;
		case ZodIssueCode.not_multiple_of:
			message = `Number must be a multiple of ${issue.multipleOf}`;
			break;
		case ZodIssueCode.not_finite:
			message = "Number must be finite";
			break;
		default:
			message = _ctx.defaultError;
			util.assertNever(issue);
	}
	return { message };
};
//#endregion
//#region node_modules/zod/v3/errors.js
let overrideErrorMap = errorMap;
function getErrorMap() {
	return overrideErrorMap;
}
//#endregion
//#region node_modules/zod/v3/helpers/parseUtil.js
const makeIssue = (params) => {
	const { data, path, errorMaps, issueData } = params;
	const fullPath = [...path, ...issueData.path || []];
	const fullIssue = {
		...issueData,
		path: fullPath
	};
	if (issueData.message !== void 0) return {
		...issueData,
		path: fullPath,
		message: issueData.message
	};
	let errorMessage = "";
	const maps = errorMaps.filter((m) => !!m).slice().reverse();
	for (const map of maps) errorMessage = map(fullIssue, {
		data,
		defaultError: errorMessage
	}).message;
	return {
		...issueData,
		path: fullPath,
		message: errorMessage
	};
};
function addIssueToContext(ctx, issueData) {
	const overrideMap = getErrorMap();
	const issue = makeIssue({
		issueData,
		data: ctx.data,
		path: ctx.path,
		errorMaps: [
			ctx.common.contextualErrorMap,
			ctx.schemaErrorMap,
			overrideMap,
			overrideMap === errorMap ? void 0 : errorMap
		].filter((x) => !!x)
	});
	ctx.common.issues.push(issue);
}
var ParseStatus = class ParseStatus {
	constructor() {
		this.value = "valid";
	}
	dirty() {
		if (this.value === "valid") this.value = "dirty";
	}
	abort() {
		if (this.value !== "aborted") this.value = "aborted";
	}
	static mergeArray(status, results) {
		const arrayValue = [];
		for (const s of results) {
			if (s.status === "aborted") return INVALID;
			if (s.status === "dirty") status.dirty();
			arrayValue.push(s.value);
		}
		return {
			status: status.value,
			value: arrayValue
		};
	}
	static async mergeObjectAsync(status, pairs) {
		const syncPairs = [];
		for (const pair of pairs) {
			const key = await pair.key;
			const value = await pair.value;
			syncPairs.push({
				key,
				value
			});
		}
		return ParseStatus.mergeObjectSync(status, syncPairs);
	}
	static mergeObjectSync(status, pairs) {
		const finalObject = {};
		for (const pair of pairs) {
			const { key, value } = pair;
			if (key.status === "aborted") return INVALID;
			if (value.status === "aborted") return INVALID;
			if (key.status === "dirty") status.dirty();
			if (value.status === "dirty") status.dirty();
			if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) finalObject[key.value] = value.value;
		}
		return {
			status: status.value,
			value: finalObject
		};
	}
};
const INVALID = Object.freeze({ status: "aborted" });
const DIRTY = (value) => ({
	status: "dirty",
	value
});
const OK = (value) => ({
	status: "valid",
	value
});
const isAborted = (x) => x.status === "aborted";
const isDirty = (x) => x.status === "dirty";
const isValid = (x) => x.status === "valid";
const isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;
//#endregion
//#region node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil) {
	errorUtil.errToObj = (message) => typeof message === "string" ? { message } : message || {};
	errorUtil.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));
//#endregion
//#region node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
	constructor(parent, value, path, key) {
		this._cachedPath = [];
		this.parent = parent;
		this.data = value;
		this._path = path;
		this._key = key;
	}
	get path() {
		if (!this._cachedPath.length) if (Array.isArray(this._key)) this._cachedPath.push(...this._path, ...this._key);
		else this._cachedPath.push(...this._path, this._key);
		return this._cachedPath;
	}
};
const handleResult = (ctx, result) => {
	if (isValid(result)) return {
		success: true,
		data: result.value
	};
	else {
		if (!ctx.common.issues.length) throw new Error("Validation failed but no issues detected.");
		return {
			success: false,
			get error() {
				if (this._error) return this._error;
				const error = new ZodError(ctx.common.issues);
				this._error = error;
				return this._error;
			}
		};
	}
};
function processCreateParams(params) {
	if (!params) return {};
	const { errorMap, invalid_type_error, required_error, description } = params;
	if (errorMap && (invalid_type_error || required_error)) throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
	if (errorMap) return {
		errorMap,
		description
	};
	const customMap = (iss, ctx) => {
		const { message } = params;
		if (iss.code === "invalid_enum_value") return { message: message ?? ctx.defaultError };
		if (typeof ctx.data === "undefined") return { message: message ?? required_error ?? ctx.defaultError };
		if (iss.code !== "invalid_type") return { message: ctx.defaultError };
		return { message: message ?? invalid_type_error ?? ctx.defaultError };
	};
	return {
		errorMap: customMap,
		description
	};
}
var ZodType = class {
	get description() {
		return this._def.description;
	}
	_getType(input) {
		return getParsedType(input.data);
	}
	_getOrReturnCtx(input, ctx) {
		return ctx || {
			common: input.parent.common,
			data: input.data,
			parsedType: getParsedType(input.data),
			schemaErrorMap: this._def.errorMap,
			path: input.path,
			parent: input.parent
		};
	}
	_processInputParams(input) {
		return {
			status: new ParseStatus(),
			ctx: {
				common: input.parent.common,
				data: input.data,
				parsedType: getParsedType(input.data),
				schemaErrorMap: this._def.errorMap,
				path: input.path,
				parent: input.parent
			}
		};
	}
	_parseSync(input) {
		const result = this._parse(input);
		if (isAsync(result)) throw new Error("Synchronous parse encountered promise.");
		return result;
	}
	_parseAsync(input) {
		const result = this._parse(input);
		return Promise.resolve(result);
	}
	parse(data, params) {
		const result = this.safeParse(data, params);
		if (result.success) return result.data;
		throw result.error;
	}
	safeParse(data, params) {
		const ctx = {
			common: {
				issues: [],
				async: params?.async ?? false,
				contextualErrorMap: params?.errorMap
			},
			path: params?.path || [],
			schemaErrorMap: this._def.errorMap,
			parent: null,
			data,
			parsedType: getParsedType(data)
		};
		return handleResult(ctx, this._parseSync({
			data,
			path: ctx.path,
			parent: ctx
		}));
	}
	"~validate"(data) {
		const ctx = {
			common: {
				issues: [],
				async: !!this["~standard"].async
			},
			path: [],
			schemaErrorMap: this._def.errorMap,
			parent: null,
			data,
			parsedType: getParsedType(data)
		};
		if (!this["~standard"].async) try {
			const result = this._parseSync({
				data,
				path: [],
				parent: ctx
			});
			return isValid(result) ? { value: result.value } : { issues: ctx.common.issues };
		} catch (err) {
			if (err?.message?.toLowerCase()?.includes("encountered")) this["~standard"].async = true;
			ctx.common = {
				issues: [],
				async: true
			};
		}
		return this._parseAsync({
			data,
			path: [],
			parent: ctx
		}).then((result) => isValid(result) ? { value: result.value } : { issues: ctx.common.issues });
	}
	async parseAsync(data, params) {
		const result = await this.safeParseAsync(data, params);
		if (result.success) return result.data;
		throw result.error;
	}
	async safeParseAsync(data, params) {
		const ctx = {
			common: {
				issues: [],
				contextualErrorMap: params?.errorMap,
				async: true
			},
			path: params?.path || [],
			schemaErrorMap: this._def.errorMap,
			parent: null,
			data,
			parsedType: getParsedType(data)
		};
		const maybeAsyncResult = this._parse({
			data,
			path: ctx.path,
			parent: ctx
		});
		return handleResult(ctx, await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult)));
	}
	refine(check, message) {
		const getIssueProperties = (val) => {
			if (typeof message === "string" || typeof message === "undefined") return { message };
			else if (typeof message === "function") return message(val);
			else return message;
		};
		return this._refinement((val, ctx) => {
			const result = check(val);
			const setError = () => ctx.addIssue({
				code: ZodIssueCode.custom,
				...getIssueProperties(val)
			});
			if (typeof Promise !== "undefined" && result instanceof Promise) return result.then((data) => {
				if (!data) {
					setError();
					return false;
				} else return true;
			});
			if (!result) {
				setError();
				return false;
			} else return true;
		});
	}
	refinement(check, refinementData) {
		return this._refinement((val, ctx) => {
			if (!check(val)) {
				ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
				return false;
			} else return true;
		});
	}
	_refinement(refinement) {
		return new ZodEffects({
			schema: this,
			typeName: ZodFirstPartyTypeKind.ZodEffects,
			effect: {
				type: "refinement",
				refinement
			}
		});
	}
	superRefine(refinement) {
		return this._refinement(refinement);
	}
	constructor(def) {
		/** Alias of safeParseAsync */
		this.spa = this.safeParseAsync;
		this._def = def;
		this.parse = this.parse.bind(this);
		this.safeParse = this.safeParse.bind(this);
		this.parseAsync = this.parseAsync.bind(this);
		this.safeParseAsync = this.safeParseAsync.bind(this);
		this.spa = this.spa.bind(this);
		this.refine = this.refine.bind(this);
		this.refinement = this.refinement.bind(this);
		this.superRefine = this.superRefine.bind(this);
		this.optional = this.optional.bind(this);
		this.nullable = this.nullable.bind(this);
		this.nullish = this.nullish.bind(this);
		this.array = this.array.bind(this);
		this.promise = this.promise.bind(this);
		this.or = this.or.bind(this);
		this.and = this.and.bind(this);
		this.transform = this.transform.bind(this);
		this.brand = this.brand.bind(this);
		this.default = this.default.bind(this);
		this.catch = this.catch.bind(this);
		this.describe = this.describe.bind(this);
		this.pipe = this.pipe.bind(this);
		this.readonly = this.readonly.bind(this);
		this.isNullable = this.isNullable.bind(this);
		this.isOptional = this.isOptional.bind(this);
		this["~standard"] = {
			version: 1,
			vendor: "zod",
			validate: (data) => this["~validate"](data)
		};
	}
	optional() {
		return ZodOptional.create(this, this._def);
	}
	nullable() {
		return ZodNullable.create(this, this._def);
	}
	nullish() {
		return this.nullable().optional();
	}
	array() {
		return ZodArray.create(this);
	}
	promise() {
		return ZodPromise.create(this, this._def);
	}
	or(option) {
		return ZodUnion.create([this, option], this._def);
	}
	and(incoming) {
		return ZodIntersection.create(this, incoming, this._def);
	}
	transform(transform) {
		return new ZodEffects({
			...processCreateParams(this._def),
			schema: this,
			typeName: ZodFirstPartyTypeKind.ZodEffects,
			effect: {
				type: "transform",
				transform
			}
		});
	}
	default(def) {
		const defaultValueFunc = typeof def === "function" ? def : () => def;
		return new ZodDefault({
			...processCreateParams(this._def),
			innerType: this,
			defaultValue: defaultValueFunc,
			typeName: ZodFirstPartyTypeKind.ZodDefault
		});
	}
	brand() {
		return new ZodBranded({
			typeName: ZodFirstPartyTypeKind.ZodBranded,
			type: this,
			...processCreateParams(this._def)
		});
	}
	catch(def) {
		const catchValueFunc = typeof def === "function" ? def : () => def;
		return new ZodCatch({
			...processCreateParams(this._def),
			innerType: this,
			catchValue: catchValueFunc,
			typeName: ZodFirstPartyTypeKind.ZodCatch
		});
	}
	describe(description) {
		const This = this.constructor;
		return new This({
			...this._def,
			description
		});
	}
	pipe(target) {
		return ZodPipeline.create(this, target);
	}
	readonly() {
		return ZodReadonly.create(this);
	}
	isOptional() {
		return this.safeParse(void 0).success;
	}
	isNullable() {
		return this.safeParse(null).success;
	}
};
const cuidRegex = /^c[^\s-]{8,}$/i;
const cuid2Regex = /^[0-9a-z]+$/;
const ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
const uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
const nanoidRegex = /^[a-z0-9_-]{21}$/i;
const jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
const durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
const emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
const _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
let emojiRegex;
const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
const ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
const ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
const ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
const base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
const base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
const dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
const dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
	let secondsRegexSource = `[0-5]\\d`;
	if (args.precision) secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
	else if (args.precision == null) secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
	const secondsQuantifier = args.precision ? "+" : "?";
	return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
	return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
	let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
	const opts = [];
	opts.push(args.local ? `Z?` : `Z`);
	if (args.offset) opts.push(`([+-]\\d{2}:?\\d{2})`);
	regex = `${regex}(${opts.join("|")})`;
	return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
	if ((version === "v4" || !version) && ipv4Regex.test(ip)) return true;
	if ((version === "v6" || !version) && ipv6Regex.test(ip)) return true;
	return false;
}
function isValidJWT(jwt, alg) {
	if (!jwtRegex.test(jwt)) return false;
	try {
		const [header] = jwt.split(".");
		if (!header) return false;
		const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
		const decoded = JSON.parse(atob(base64));
		if (typeof decoded !== "object" || decoded === null) return false;
		if ("typ" in decoded && decoded?.typ !== "JWT") return false;
		if (!decoded.alg) return false;
		if (alg && decoded.alg !== alg) return false;
		return true;
	} catch {
		return false;
	}
}
function isValidCidr(ip, version) {
	if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) return true;
	if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) return true;
	return false;
}
var ZodString = class ZodString extends ZodType {
	_parse(input) {
		if (this._def.coerce) input.data = String(input.data);
		if (this._getType(input) !== ZodParsedType.string) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.string,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const status = new ParseStatus();
		let ctx = void 0;
		for (const check of this._def.checks) if (check.kind === "min") {
			if (input.data.length < check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: check.value,
					type: "string",
					inclusive: true,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (input.data.length > check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: check.value,
					type: "string",
					inclusive: true,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "length") {
			const tooBig = input.data.length > check.value;
			const tooSmall = input.data.length < check.value;
			if (tooBig || tooSmall) {
				ctx = this._getOrReturnCtx(input, ctx);
				if (tooBig) addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: check.value,
					type: "string",
					inclusive: true,
					exact: true,
					message: check.message
				});
				else if (tooSmall) addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: check.value,
					type: "string",
					inclusive: true,
					exact: true,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "email") {
			if (!emailRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "email",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "emoji") {
			if (!emojiRegex) emojiRegex = new RegExp(_emojiRegex, "u");
			if (!emojiRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "emoji",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "uuid") {
			if (!uuidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "uuid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "nanoid") {
			if (!nanoidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "nanoid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "cuid") {
			if (!cuidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "cuid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "cuid2") {
			if (!cuid2Regex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "cuid2",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "ulid") {
			if (!ulidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "ulid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "url") try {
			new URL(input.data);
		} catch {
			ctx = this._getOrReturnCtx(input, ctx);
			addIssueToContext(ctx, {
				validation: "url",
				code: ZodIssueCode.invalid_string,
				message: check.message
			});
			status.dirty();
		}
		else if (check.kind === "regex") {
			check.regex.lastIndex = 0;
			if (!check.regex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "regex",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "trim") input.data = input.data.trim();
		else if (check.kind === "includes") {
			if (!input.data.includes(check.value, check.position)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: {
						includes: check.value,
						position: check.position
					},
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "toLowerCase") input.data = input.data.toLowerCase();
		else if (check.kind === "toUpperCase") input.data = input.data.toUpperCase();
		else if (check.kind === "startsWith") {
			if (!input.data.startsWith(check.value)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: { startsWith: check.value },
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "endsWith") {
			if (!input.data.endsWith(check.value)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: { endsWith: check.value },
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "datetime") {
			if (!datetimeRegex(check).test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: "datetime",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "date") {
			if (!dateRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: "date",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "time") {
			if (!timeRegex(check).test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: "time",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "duration") {
			if (!durationRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "duration",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "ip") {
			if (!isValidIP(input.data, check.version)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "ip",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "jwt") {
			if (!isValidJWT(input.data, check.alg)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "jwt",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "cidr") {
			if (!isValidCidr(input.data, check.version)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "cidr",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "base64") {
			if (!base64Regex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "base64",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "base64url") {
			if (!base64urlRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "base64url",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: input.data
		};
	}
	_regex(regex, validation, message) {
		return this.refinement((data) => regex.test(data), {
			validation,
			code: ZodIssueCode.invalid_string,
			...errorUtil.errToObj(message)
		});
	}
	_addCheck(check) {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	email(message) {
		return this._addCheck({
			kind: "email",
			...errorUtil.errToObj(message)
		});
	}
	url(message) {
		return this._addCheck({
			kind: "url",
			...errorUtil.errToObj(message)
		});
	}
	emoji(message) {
		return this._addCheck({
			kind: "emoji",
			...errorUtil.errToObj(message)
		});
	}
	uuid(message) {
		return this._addCheck({
			kind: "uuid",
			...errorUtil.errToObj(message)
		});
	}
	nanoid(message) {
		return this._addCheck({
			kind: "nanoid",
			...errorUtil.errToObj(message)
		});
	}
	cuid(message) {
		return this._addCheck({
			kind: "cuid",
			...errorUtil.errToObj(message)
		});
	}
	cuid2(message) {
		return this._addCheck({
			kind: "cuid2",
			...errorUtil.errToObj(message)
		});
	}
	ulid(message) {
		return this._addCheck({
			kind: "ulid",
			...errorUtil.errToObj(message)
		});
	}
	base64(message) {
		return this._addCheck({
			kind: "base64",
			...errorUtil.errToObj(message)
		});
	}
	base64url(message) {
		return this._addCheck({
			kind: "base64url",
			...errorUtil.errToObj(message)
		});
	}
	jwt(options) {
		return this._addCheck({
			kind: "jwt",
			...errorUtil.errToObj(options)
		});
	}
	ip(options) {
		return this._addCheck({
			kind: "ip",
			...errorUtil.errToObj(options)
		});
	}
	cidr(options) {
		return this._addCheck({
			kind: "cidr",
			...errorUtil.errToObj(options)
		});
	}
	datetime(options) {
		if (typeof options === "string") return this._addCheck({
			kind: "datetime",
			precision: null,
			offset: false,
			local: false,
			message: options
		});
		return this._addCheck({
			kind: "datetime",
			precision: typeof options?.precision === "undefined" ? null : options?.precision,
			offset: options?.offset ?? false,
			local: options?.local ?? false,
			...errorUtil.errToObj(options?.message)
		});
	}
	date(message) {
		return this._addCheck({
			kind: "date",
			message
		});
	}
	time(options) {
		if (typeof options === "string") return this._addCheck({
			kind: "time",
			precision: null,
			message: options
		});
		return this._addCheck({
			kind: "time",
			precision: typeof options?.precision === "undefined" ? null : options?.precision,
			...errorUtil.errToObj(options?.message)
		});
	}
	duration(message) {
		return this._addCheck({
			kind: "duration",
			...errorUtil.errToObj(message)
		});
	}
	regex(regex, message) {
		return this._addCheck({
			kind: "regex",
			regex,
			...errorUtil.errToObj(message)
		});
	}
	includes(value, options) {
		return this._addCheck({
			kind: "includes",
			value,
			position: options?.position,
			...errorUtil.errToObj(options?.message)
		});
	}
	startsWith(value, message) {
		return this._addCheck({
			kind: "startsWith",
			value,
			...errorUtil.errToObj(message)
		});
	}
	endsWith(value, message) {
		return this._addCheck({
			kind: "endsWith",
			value,
			...errorUtil.errToObj(message)
		});
	}
	min(minLength, message) {
		return this._addCheck({
			kind: "min",
			value: minLength,
			...errorUtil.errToObj(message)
		});
	}
	max(maxLength, message) {
		return this._addCheck({
			kind: "max",
			value: maxLength,
			...errorUtil.errToObj(message)
		});
	}
	length(len, message) {
		return this._addCheck({
			kind: "length",
			value: len,
			...errorUtil.errToObj(message)
		});
	}
	/**
	* Equivalent to `.min(1)`
	*/
	nonempty(message) {
		return this.min(1, errorUtil.errToObj(message));
	}
	trim() {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, { kind: "trim" }]
		});
	}
	toLowerCase() {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, { kind: "toLowerCase" }]
		});
	}
	toUpperCase() {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, { kind: "toUpperCase" }]
		});
	}
	get isDatetime() {
		return !!this._def.checks.find((ch) => ch.kind === "datetime");
	}
	get isDate() {
		return !!this._def.checks.find((ch) => ch.kind === "date");
	}
	get isTime() {
		return !!this._def.checks.find((ch) => ch.kind === "time");
	}
	get isDuration() {
		return !!this._def.checks.find((ch) => ch.kind === "duration");
	}
	get isEmail() {
		return !!this._def.checks.find((ch) => ch.kind === "email");
	}
	get isURL() {
		return !!this._def.checks.find((ch) => ch.kind === "url");
	}
	get isEmoji() {
		return !!this._def.checks.find((ch) => ch.kind === "emoji");
	}
	get isUUID() {
		return !!this._def.checks.find((ch) => ch.kind === "uuid");
	}
	get isNANOID() {
		return !!this._def.checks.find((ch) => ch.kind === "nanoid");
	}
	get isCUID() {
		return !!this._def.checks.find((ch) => ch.kind === "cuid");
	}
	get isCUID2() {
		return !!this._def.checks.find((ch) => ch.kind === "cuid2");
	}
	get isULID() {
		return !!this._def.checks.find((ch) => ch.kind === "ulid");
	}
	get isIP() {
		return !!this._def.checks.find((ch) => ch.kind === "ip");
	}
	get isCIDR() {
		return !!this._def.checks.find((ch) => ch.kind === "cidr");
	}
	get isBase64() {
		return !!this._def.checks.find((ch) => ch.kind === "base64");
	}
	get isBase64url() {
		return !!this._def.checks.find((ch) => ch.kind === "base64url");
	}
	get minLength() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min;
	}
	get maxLength() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max;
	}
};
ZodString.create = (params) => {
	return new ZodString({
		checks: [],
		typeName: ZodFirstPartyTypeKind.ZodString,
		coerce: params?.coerce ?? false,
		...processCreateParams(params)
	});
};
function floatSafeRemainder(val, step) {
	const valDecCount = (val.toString().split(".")[1] || "").length;
	const stepDecCount = (step.toString().split(".")[1] || "").length;
	const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
	return Number.parseInt(val.toFixed(decCount).replace(".", "")) % Number.parseInt(step.toFixed(decCount).replace(".", "")) / 10 ** decCount;
}
var ZodNumber = class ZodNumber extends ZodType {
	constructor() {
		super(...arguments);
		this.min = this.gte;
		this.max = this.lte;
		this.step = this.multipleOf;
	}
	_parse(input) {
		if (this._def.coerce) input.data = Number(input.data);
		if (this._getType(input) !== ZodParsedType.number) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.number,
				received: ctx.parsedType
			});
			return INVALID;
		}
		let ctx = void 0;
		const status = new ParseStatus();
		for (const check of this._def.checks) if (check.kind === "int") {
			if (!util.isInteger(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_type,
					expected: "integer",
					received: "float",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "min") {
			if (check.inclusive ? input.data < check.value : input.data <= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: check.value,
					type: "number",
					inclusive: check.inclusive,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (check.inclusive ? input.data > check.value : input.data >= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: check.value,
					type: "number",
					inclusive: check.inclusive,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "multipleOf") {
			if (floatSafeRemainder(input.data, check.value) !== 0) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.not_multiple_of,
					multipleOf: check.value,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "finite") {
			if (!Number.isFinite(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.not_finite,
					message: check.message
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: input.data
		};
	}
	gte(value, message) {
		return this.setLimit("min", value, true, errorUtil.toString(message));
	}
	gt(value, message) {
		return this.setLimit("min", value, false, errorUtil.toString(message));
	}
	lte(value, message) {
		return this.setLimit("max", value, true, errorUtil.toString(message));
	}
	lt(value, message) {
		return this.setLimit("max", value, false, errorUtil.toString(message));
	}
	setLimit(kind, value, inclusive, message) {
		return new ZodNumber({
			...this._def,
			checks: [...this._def.checks, {
				kind,
				value,
				inclusive,
				message: errorUtil.toString(message)
			}]
		});
	}
	_addCheck(check) {
		return new ZodNumber({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	int(message) {
		return this._addCheck({
			kind: "int",
			message: errorUtil.toString(message)
		});
	}
	positive(message) {
		return this._addCheck({
			kind: "min",
			value: 0,
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	negative(message) {
		return this._addCheck({
			kind: "max",
			value: 0,
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	nonpositive(message) {
		return this._addCheck({
			kind: "max",
			value: 0,
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	nonnegative(message) {
		return this._addCheck({
			kind: "min",
			value: 0,
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	multipleOf(value, message) {
		return this._addCheck({
			kind: "multipleOf",
			value,
			message: errorUtil.toString(message)
		});
	}
	finite(message) {
		return this._addCheck({
			kind: "finite",
			message: errorUtil.toString(message)
		});
	}
	safe(message) {
		return this._addCheck({
			kind: "min",
			inclusive: true,
			value: Number.MIN_SAFE_INTEGER,
			message: errorUtil.toString(message)
		})._addCheck({
			kind: "max",
			inclusive: true,
			value: Number.MAX_SAFE_INTEGER,
			message: errorUtil.toString(message)
		});
	}
	get minValue() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min;
	}
	get maxValue() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max;
	}
	get isInt() {
		return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
	}
	get isFinite() {
		let max = null;
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") return true;
		else if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		} else if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return Number.isFinite(min) && Number.isFinite(max);
	}
};
ZodNumber.create = (params) => {
	return new ZodNumber({
		checks: [],
		typeName: ZodFirstPartyTypeKind.ZodNumber,
		coerce: params?.coerce || false,
		...processCreateParams(params)
	});
};
var ZodBigInt = class ZodBigInt extends ZodType {
	constructor() {
		super(...arguments);
		this.min = this.gte;
		this.max = this.lte;
	}
	_parse(input) {
		if (this._def.coerce) try {
			input.data = BigInt(input.data);
		} catch {
			return this._getInvalidInput(input);
		}
		if (this._getType(input) !== ZodParsedType.bigint) return this._getInvalidInput(input);
		let ctx = void 0;
		const status = new ParseStatus();
		for (const check of this._def.checks) if (check.kind === "min") {
			if (check.inclusive ? input.data < check.value : input.data <= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					type: "bigint",
					minimum: check.value,
					inclusive: check.inclusive,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (check.inclusive ? input.data > check.value : input.data >= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					type: "bigint",
					maximum: check.value,
					inclusive: check.inclusive,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "multipleOf") {
			if (input.data % check.value !== BigInt(0)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.not_multiple_of,
					multipleOf: check.value,
					message: check.message
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: input.data
		};
	}
	_getInvalidInput(input) {
		const ctx = this._getOrReturnCtx(input);
		addIssueToContext(ctx, {
			code: ZodIssueCode.invalid_type,
			expected: ZodParsedType.bigint,
			received: ctx.parsedType
		});
		return INVALID;
	}
	gte(value, message) {
		return this.setLimit("min", value, true, errorUtil.toString(message));
	}
	gt(value, message) {
		return this.setLimit("min", value, false, errorUtil.toString(message));
	}
	lte(value, message) {
		return this.setLimit("max", value, true, errorUtil.toString(message));
	}
	lt(value, message) {
		return this.setLimit("max", value, false, errorUtil.toString(message));
	}
	setLimit(kind, value, inclusive, message) {
		return new ZodBigInt({
			...this._def,
			checks: [...this._def.checks, {
				kind,
				value,
				inclusive,
				message: errorUtil.toString(message)
			}]
		});
	}
	_addCheck(check) {
		return new ZodBigInt({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	positive(message) {
		return this._addCheck({
			kind: "min",
			value: BigInt(0),
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	negative(message) {
		return this._addCheck({
			kind: "max",
			value: BigInt(0),
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	nonpositive(message) {
		return this._addCheck({
			kind: "max",
			value: BigInt(0),
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	nonnegative(message) {
		return this._addCheck({
			kind: "min",
			value: BigInt(0),
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	multipleOf(value, message) {
		return this._addCheck({
			kind: "multipleOf",
			value,
			message: errorUtil.toString(message)
		});
	}
	get minValue() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min;
	}
	get maxValue() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max;
	}
};
ZodBigInt.create = (params) => {
	return new ZodBigInt({
		checks: [],
		typeName: ZodFirstPartyTypeKind.ZodBigInt,
		coerce: params?.coerce ?? false,
		...processCreateParams(params)
	});
};
var ZodBoolean = class extends ZodType {
	_parse(input) {
		if (this._def.coerce) input.data = Boolean(input.data);
		if (this._getType(input) !== ZodParsedType.boolean) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.boolean,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodBoolean.create = (params) => {
	return new ZodBoolean({
		typeName: ZodFirstPartyTypeKind.ZodBoolean,
		coerce: params?.coerce || false,
		...processCreateParams(params)
	});
};
var ZodDate = class ZodDate extends ZodType {
	_parse(input) {
		if (this._def.coerce) input.data = new Date(input.data);
		if (this._getType(input) !== ZodParsedType.date) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.date,
				received: ctx.parsedType
			});
			return INVALID;
		}
		if (Number.isNaN(input.data.getTime())) {
			addIssueToContext(this._getOrReturnCtx(input), { code: ZodIssueCode.invalid_date });
			return INVALID;
		}
		const status = new ParseStatus();
		let ctx = void 0;
		for (const check of this._def.checks) if (check.kind === "min") {
			if (input.data.getTime() < check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					message: check.message,
					inclusive: true,
					exact: false,
					minimum: check.value,
					type: "date"
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (input.data.getTime() > check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					message: check.message,
					inclusive: true,
					exact: false,
					maximum: check.value,
					type: "date"
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: new Date(input.data.getTime())
		};
	}
	_addCheck(check) {
		return new ZodDate({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	min(minDate, message) {
		return this._addCheck({
			kind: "min",
			value: minDate.getTime(),
			message: errorUtil.toString(message)
		});
	}
	max(maxDate, message) {
		return this._addCheck({
			kind: "max",
			value: maxDate.getTime(),
			message: errorUtil.toString(message)
		});
	}
	get minDate() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min != null ? new Date(min) : null;
	}
	get maxDate() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max != null ? new Date(max) : null;
	}
};
ZodDate.create = (params) => {
	return new ZodDate({
		checks: [],
		coerce: params?.coerce || false,
		typeName: ZodFirstPartyTypeKind.ZodDate,
		...processCreateParams(params)
	});
};
var ZodSymbol = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.symbol) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.symbol,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodSymbol.create = (params) => {
	return new ZodSymbol({
		typeName: ZodFirstPartyTypeKind.ZodSymbol,
		...processCreateParams(params)
	});
};
var ZodUndefined = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.undefined) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.undefined,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodUndefined.create = (params) => {
	return new ZodUndefined({
		typeName: ZodFirstPartyTypeKind.ZodUndefined,
		...processCreateParams(params)
	});
};
var ZodNull = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.null) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.null,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodNull.create = (params) => {
	return new ZodNull({
		typeName: ZodFirstPartyTypeKind.ZodNull,
		...processCreateParams(params)
	});
};
var ZodAny = class extends ZodType {
	constructor() {
		super(...arguments);
		this._any = true;
	}
	_parse(input) {
		return OK(input.data);
	}
};
ZodAny.create = (params) => {
	return new ZodAny({
		typeName: ZodFirstPartyTypeKind.ZodAny,
		...processCreateParams(params)
	});
};
var ZodUnknown = class extends ZodType {
	constructor() {
		super(...arguments);
		this._unknown = true;
	}
	_parse(input) {
		return OK(input.data);
	}
};
ZodUnknown.create = (params) => {
	return new ZodUnknown({
		typeName: ZodFirstPartyTypeKind.ZodUnknown,
		...processCreateParams(params)
	});
};
var ZodNever = class extends ZodType {
	_parse(input) {
		const ctx = this._getOrReturnCtx(input);
		addIssueToContext(ctx, {
			code: ZodIssueCode.invalid_type,
			expected: ZodParsedType.never,
			received: ctx.parsedType
		});
		return INVALID;
	}
};
ZodNever.create = (params) => {
	return new ZodNever({
		typeName: ZodFirstPartyTypeKind.ZodNever,
		...processCreateParams(params)
	});
};
var ZodVoid = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.undefined) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.void,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodVoid.create = (params) => {
	return new ZodVoid({
		typeName: ZodFirstPartyTypeKind.ZodVoid,
		...processCreateParams(params)
	});
};
var ZodArray = class ZodArray extends ZodType {
	_parse(input) {
		const { ctx, status } = this._processInputParams(input);
		const def = this._def;
		if (ctx.parsedType !== ZodParsedType.array) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.array,
				received: ctx.parsedType
			});
			return INVALID;
		}
		if (def.exactLength !== null) {
			const tooBig = ctx.data.length > def.exactLength.value;
			const tooSmall = ctx.data.length < def.exactLength.value;
			if (tooBig || tooSmall) {
				addIssueToContext(ctx, {
					code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
					minimum: tooSmall ? def.exactLength.value : void 0,
					maximum: tooBig ? def.exactLength.value : void 0,
					type: "array",
					inclusive: true,
					exact: true,
					message: def.exactLength.message
				});
				status.dirty();
			}
		}
		if (def.minLength !== null) {
			if (ctx.data.length < def.minLength.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: def.minLength.value,
					type: "array",
					inclusive: true,
					exact: false,
					message: def.minLength.message
				});
				status.dirty();
			}
		}
		if (def.maxLength !== null) {
			if (ctx.data.length > def.maxLength.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: def.maxLength.value,
					type: "array",
					inclusive: true,
					exact: false,
					message: def.maxLength.message
				});
				status.dirty();
			}
		}
		if (ctx.common.async) return Promise.all([...ctx.data].map((item, i) => {
			return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
		})).then((result) => {
			return ParseStatus.mergeArray(status, result);
		});
		const result = [...ctx.data].map((item, i) => {
			return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
		});
		return ParseStatus.mergeArray(status, result);
	}
	get element() {
		return this._def.type;
	}
	min(minLength, message) {
		return new ZodArray({
			...this._def,
			minLength: {
				value: minLength,
				message: errorUtil.toString(message)
			}
		});
	}
	max(maxLength, message) {
		return new ZodArray({
			...this._def,
			maxLength: {
				value: maxLength,
				message: errorUtil.toString(message)
			}
		});
	}
	length(len, message) {
		return new ZodArray({
			...this._def,
			exactLength: {
				value: len,
				message: errorUtil.toString(message)
			}
		});
	}
	nonempty(message) {
		return this.min(1, message);
	}
};
ZodArray.create = (schema, params) => {
	return new ZodArray({
		type: schema,
		minLength: null,
		maxLength: null,
		exactLength: null,
		typeName: ZodFirstPartyTypeKind.ZodArray,
		...processCreateParams(params)
	});
};
function deepPartialify(schema) {
	if (schema instanceof ZodObject) {
		const newShape = {};
		for (const key in schema.shape) {
			const fieldSchema = schema.shape[key];
			newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
		}
		return new ZodObject({
			...schema._def,
			shape: () => newShape
		});
	} else if (schema instanceof ZodArray) return new ZodArray({
		...schema._def,
		type: deepPartialify(schema.element)
	});
	else if (schema instanceof ZodOptional) return ZodOptional.create(deepPartialify(schema.unwrap()));
	else if (schema instanceof ZodNullable) return ZodNullable.create(deepPartialify(schema.unwrap()));
	else if (schema instanceof ZodTuple) return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
	else return schema;
}
var ZodObject = class ZodObject extends ZodType {
	constructor() {
		super(...arguments);
		this._cached = null;
		/**
		* @deprecated In most cases, this is no longer needed - unknown properties are now silently stripped.
		* If you want to pass through unknown properties, use `.passthrough()` instead.
		*/
		this.nonstrict = this.passthrough;
		/**
		* @deprecated Use `.extend` instead
		*  */
		this.augment = this.extend;
	}
	_getCached() {
		if (this._cached !== null) return this._cached;
		const shape = this._def.shape();
		const keys = util.objectKeys(shape);
		this._cached = {
			shape,
			keys
		};
		return this._cached;
	}
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.object) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.object,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const { status, ctx } = this._processInputParams(input);
		const { shape, keys: shapeKeys } = this._getCached();
		const extraKeys = [];
		if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
			for (const key in ctx.data) if (!shapeKeys.includes(key)) extraKeys.push(key);
		}
		const pairs = [];
		for (const key of shapeKeys) {
			const keyValidator = shape[key];
			const value = ctx.data[key];
			pairs.push({
				key: {
					status: "valid",
					value: key
				},
				value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
				alwaysSet: key in ctx.data
			});
		}
		if (this._def.catchall instanceof ZodNever) {
			const unknownKeys = this._def.unknownKeys;
			if (unknownKeys === "passthrough") for (const key of extraKeys) pairs.push({
				key: {
					status: "valid",
					value: key
				},
				value: {
					status: "valid",
					value: ctx.data[key]
				}
			});
			else if (unknownKeys === "strict") {
				if (extraKeys.length > 0) {
					addIssueToContext(ctx, {
						code: ZodIssueCode.unrecognized_keys,
						keys: extraKeys
					});
					status.dirty();
				}
			} else if (unknownKeys === "strip") {} else throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
		} else {
			const catchall = this._def.catchall;
			for (const key of extraKeys) {
				const value = ctx.data[key];
				pairs.push({
					key: {
						status: "valid",
						value: key
					},
					value: catchall._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
					alwaysSet: key in ctx.data
				});
			}
		}
		if (ctx.common.async) return Promise.resolve().then(async () => {
			const syncPairs = [];
			for (const pair of pairs) {
				const key = await pair.key;
				const value = await pair.value;
				syncPairs.push({
					key,
					value,
					alwaysSet: pair.alwaysSet
				});
			}
			return syncPairs;
		}).then((syncPairs) => {
			return ParseStatus.mergeObjectSync(status, syncPairs);
		});
		else return ParseStatus.mergeObjectSync(status, pairs);
	}
	get shape() {
		return this._def.shape();
	}
	strict(message) {
		errorUtil.errToObj;
		return new ZodObject({
			...this._def,
			unknownKeys: "strict",
			...message !== void 0 ? { errorMap: (issue, ctx) => {
				const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
				if (issue.code === "unrecognized_keys") return { message: errorUtil.errToObj(message).message ?? defaultError };
				return { message: defaultError };
			} } : {}
		});
	}
	strip() {
		return new ZodObject({
			...this._def,
			unknownKeys: "strip"
		});
	}
	passthrough() {
		return new ZodObject({
			...this._def,
			unknownKeys: "passthrough"
		});
	}
	extend(augmentation) {
		return new ZodObject({
			...this._def,
			shape: () => ({
				...this._def.shape(),
				...augmentation
			})
		});
	}
	/**
	* Prior to zod@1.0.12 there was a bug in the
	* inferred type of merged objects. Please
	* upgrade if you are experiencing issues.
	*/
	merge(merging) {
		return new ZodObject({
			unknownKeys: merging._def.unknownKeys,
			catchall: merging._def.catchall,
			shape: () => ({
				...this._def.shape(),
				...merging._def.shape()
			}),
			typeName: ZodFirstPartyTypeKind.ZodObject
		});
	}
	setKey(key, schema) {
		return this.augment({ [key]: schema });
	}
	catchall(index) {
		return new ZodObject({
			...this._def,
			catchall: index
		});
	}
	pick(mask) {
		const shape = {};
		for (const key of util.objectKeys(mask)) if (mask[key] && this.shape[key]) shape[key] = this.shape[key];
		return new ZodObject({
			...this._def,
			shape: () => shape
		});
	}
	omit(mask) {
		const shape = {};
		for (const key of util.objectKeys(this.shape)) if (!mask[key]) shape[key] = this.shape[key];
		return new ZodObject({
			...this._def,
			shape: () => shape
		});
	}
	/**
	* @deprecated
	*/
	deepPartial() {
		return deepPartialify(this);
	}
	partial(mask) {
		const newShape = {};
		for (const key of util.objectKeys(this.shape)) {
			const fieldSchema = this.shape[key];
			if (mask && !mask[key]) newShape[key] = fieldSchema;
			else newShape[key] = fieldSchema.optional();
		}
		return new ZodObject({
			...this._def,
			shape: () => newShape
		});
	}
	required(mask) {
		const newShape = {};
		for (const key of util.objectKeys(this.shape)) if (mask && !mask[key]) newShape[key] = this.shape[key];
		else {
			let newField = this.shape[key];
			while (newField instanceof ZodOptional) newField = newField._def.innerType;
			newShape[key] = newField;
		}
		return new ZodObject({
			...this._def,
			shape: () => newShape
		});
	}
	keyof() {
		return createZodEnum(util.objectKeys(this.shape));
	}
};
ZodObject.create = (shape, params) => {
	return new ZodObject({
		shape: () => shape,
		unknownKeys: "strip",
		catchall: ZodNever.create(),
		typeName: ZodFirstPartyTypeKind.ZodObject,
		...processCreateParams(params)
	});
};
ZodObject.strictCreate = (shape, params) => {
	return new ZodObject({
		shape: () => shape,
		unknownKeys: "strict",
		catchall: ZodNever.create(),
		typeName: ZodFirstPartyTypeKind.ZodObject,
		...processCreateParams(params)
	});
};
ZodObject.lazycreate = (shape, params) => {
	return new ZodObject({
		shape,
		unknownKeys: "strip",
		catchall: ZodNever.create(),
		typeName: ZodFirstPartyTypeKind.ZodObject,
		...processCreateParams(params)
	});
};
var ZodUnion = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		const options = this._def.options;
		function handleResults(results) {
			for (const result of results) if (result.result.status === "valid") return result.result;
			for (const result of results) if (result.result.status === "dirty") {
				ctx.common.issues.push(...result.ctx.common.issues);
				return result.result;
			}
			const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_union,
				unionErrors
			});
			return INVALID;
		}
		if (ctx.common.async) return Promise.all(options.map(async (option) => {
			const childCtx = {
				...ctx,
				common: {
					...ctx.common,
					issues: []
				},
				parent: null
			};
			return {
				result: await option._parseAsync({
					data: ctx.data,
					path: ctx.path,
					parent: childCtx
				}),
				ctx: childCtx
			};
		})).then(handleResults);
		else {
			let dirty = void 0;
			const issues = [];
			for (const option of options) {
				const childCtx = {
					...ctx,
					common: {
						...ctx.common,
						issues: []
					},
					parent: null
				};
				const result = option._parseSync({
					data: ctx.data,
					path: ctx.path,
					parent: childCtx
				});
				if (result.status === "valid") return result;
				else if (result.status === "dirty" && !dirty) dirty = {
					result,
					ctx: childCtx
				};
				if (childCtx.common.issues.length) issues.push(childCtx.common.issues);
			}
			if (dirty) {
				ctx.common.issues.push(...dirty.ctx.common.issues);
				return dirty.result;
			}
			const unionErrors = issues.map((issues) => new ZodError(issues));
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_union,
				unionErrors
			});
			return INVALID;
		}
	}
	get options() {
		return this._def.options;
	}
};
ZodUnion.create = (types, params) => {
	return new ZodUnion({
		options: types,
		typeName: ZodFirstPartyTypeKind.ZodUnion,
		...processCreateParams(params)
	});
};
const getDiscriminator = (type) => {
	if (type instanceof ZodLazy) return getDiscriminator(type.schema);
	else if (type instanceof ZodEffects) return getDiscriminator(type.innerType());
	else if (type instanceof ZodLiteral) return [type.value];
	else if (type instanceof ZodEnum) return type.options;
	else if (type instanceof ZodNativeEnum) return util.objectValues(type.enum);
	else if (type instanceof ZodDefault) return getDiscriminator(type._def.innerType);
	else if (type instanceof ZodUndefined) return [void 0];
	else if (type instanceof ZodNull) return [null];
	else if (type instanceof ZodOptional) return [void 0, ...getDiscriminator(type.unwrap())];
	else if (type instanceof ZodNullable) return [null, ...getDiscriminator(type.unwrap())];
	else if (type instanceof ZodBranded) return getDiscriminator(type.unwrap());
	else if (type instanceof ZodReadonly) return getDiscriminator(type.unwrap());
	else if (type instanceof ZodCatch) return getDiscriminator(type._def.innerType);
	else return [];
};
var ZodDiscriminatedUnion = class ZodDiscriminatedUnion extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.object) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.object,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const discriminator = this.discriminator;
		const discriminatorValue = ctx.data[discriminator];
		const option = this.optionsMap.get(discriminatorValue);
		if (!option) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_union_discriminator,
				options: Array.from(this.optionsMap.keys()),
				path: [discriminator]
			});
			return INVALID;
		}
		if (ctx.common.async) return option._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		});
		else return option._parseSync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		});
	}
	get discriminator() {
		return this._def.discriminator;
	}
	get options() {
		return this._def.options;
	}
	get optionsMap() {
		return this._def.optionsMap;
	}
	/**
	* The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
	* However, it only allows a union of objects, all of which need to share a discriminator property. This property must
	* have a different value for each object in the union.
	* @param discriminator the name of the discriminator property
	* @param types an array of object schemas
	* @param params
	*/
	static create(discriminator, options, params) {
		const optionsMap = /* @__PURE__ */ new Map();
		for (const type of options) {
			const discriminatorValues = getDiscriminator(type.shape[discriminator]);
			if (!discriminatorValues.length) throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
			for (const value of discriminatorValues) {
				if (optionsMap.has(value)) throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
				optionsMap.set(value, type);
			}
		}
		return new ZodDiscriminatedUnion({
			typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
			discriminator,
			options,
			optionsMap,
			...processCreateParams(params)
		});
	}
};
function mergeValues(a, b) {
	const aType = getParsedType(a);
	const bType = getParsedType(b);
	if (a === b) return {
		valid: true,
		data: a
	};
	else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
		const bKeys = util.objectKeys(b);
		const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
		const newObj = {
			...a,
			...b
		};
		for (const key of sharedKeys) {
			const sharedValue = mergeValues(a[key], b[key]);
			if (!sharedValue.valid) return { valid: false };
			newObj[key] = sharedValue.data;
		}
		return {
			valid: true,
			data: newObj
		};
	} else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
		if (a.length !== b.length) return { valid: false };
		const newArray = [];
		for (let index = 0; index < a.length; index++) {
			const itemA = a[index];
			const itemB = b[index];
			const sharedValue = mergeValues(itemA, itemB);
			if (!sharedValue.valid) return { valid: false };
			newArray.push(sharedValue.data);
		}
		return {
			valid: true,
			data: newArray
		};
	} else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) return {
		valid: true,
		data: a
	};
	else return { valid: false };
}
var ZodIntersection = class extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		const handleParsed = (parsedLeft, parsedRight) => {
			if (isAborted(parsedLeft) || isAborted(parsedRight)) return INVALID;
			const merged = mergeValues(parsedLeft.value, parsedRight.value);
			if (!merged.valid) {
				addIssueToContext(ctx, { code: ZodIssueCode.invalid_intersection_types });
				return INVALID;
			}
			if (isDirty(parsedLeft) || isDirty(parsedRight)) status.dirty();
			return {
				status: status.value,
				value: merged.data
			};
		};
		if (ctx.common.async) return Promise.all([this._def.left._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}), this._def.right._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		})]).then(([left, right]) => handleParsed(left, right));
		else return handleParsed(this._def.left._parseSync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}), this._def.right._parseSync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}));
	}
};
ZodIntersection.create = (left, right, params) => {
	return new ZodIntersection({
		left,
		right,
		typeName: ZodFirstPartyTypeKind.ZodIntersection,
		...processCreateParams(params)
	});
};
var ZodTuple = class ZodTuple extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.array) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.array,
				received: ctx.parsedType
			});
			return INVALID;
		}
		if (ctx.data.length < this._def.items.length) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.too_small,
				minimum: this._def.items.length,
				inclusive: true,
				exact: false,
				type: "array"
			});
			return INVALID;
		}
		if (!this._def.rest && ctx.data.length > this._def.items.length) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.too_big,
				maximum: this._def.items.length,
				inclusive: true,
				exact: false,
				type: "array"
			});
			status.dirty();
		}
		const items = [...ctx.data].map((item, itemIndex) => {
			const schema = this._def.items[itemIndex] || this._def.rest;
			if (!schema) return null;
			return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
		}).filter((x) => !!x);
		if (ctx.common.async) return Promise.all(items).then((results) => {
			return ParseStatus.mergeArray(status, results);
		});
		else return ParseStatus.mergeArray(status, items);
	}
	get items() {
		return this._def.items;
	}
	rest(rest) {
		return new ZodTuple({
			...this._def,
			rest
		});
	}
};
ZodTuple.create = (schemas, params) => {
	if (!Array.isArray(schemas)) throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
	return new ZodTuple({
		items: schemas,
		typeName: ZodFirstPartyTypeKind.ZodTuple,
		rest: null,
		...processCreateParams(params)
	});
};
var ZodRecord = class ZodRecord extends ZodType {
	get keySchema() {
		return this._def.keyType;
	}
	get valueSchema() {
		return this._def.valueType;
	}
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.object) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.object,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const pairs = [];
		const keyType = this._def.keyType;
		const valueType = this._def.valueType;
		for (const key in ctx.data) pairs.push({
			key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
			value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
			alwaysSet: key in ctx.data
		});
		if (ctx.common.async) return ParseStatus.mergeObjectAsync(status, pairs);
		else return ParseStatus.mergeObjectSync(status, pairs);
	}
	get element() {
		return this._def.valueType;
	}
	static create(first, second, third) {
		if (second instanceof ZodType) return new ZodRecord({
			keyType: first,
			valueType: second,
			typeName: ZodFirstPartyTypeKind.ZodRecord,
			...processCreateParams(third)
		});
		return new ZodRecord({
			keyType: ZodString.create(),
			valueType: first,
			typeName: ZodFirstPartyTypeKind.ZodRecord,
			...processCreateParams(second)
		});
	}
};
var ZodMap = class extends ZodType {
	get keySchema() {
		return this._def.keyType;
	}
	get valueSchema() {
		return this._def.valueType;
	}
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.map) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.map,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const keyType = this._def.keyType;
		const valueType = this._def.valueType;
		const pairs = [...ctx.data.entries()].map(([key, value], index) => {
			return {
				key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
				value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
			};
		});
		if (ctx.common.async) {
			const finalMap = /* @__PURE__ */ new Map();
			return Promise.resolve().then(async () => {
				for (const pair of pairs) {
					const key = await pair.key;
					const value = await pair.value;
					if (key.status === "aborted" || value.status === "aborted") return INVALID;
					if (key.status === "dirty" || value.status === "dirty") status.dirty();
					finalMap.set(key.value, value.value);
				}
				return {
					status: status.value,
					value: finalMap
				};
			});
		} else {
			const finalMap = /* @__PURE__ */ new Map();
			for (const pair of pairs) {
				const key = pair.key;
				const value = pair.value;
				if (key.status === "aborted" || value.status === "aborted") return INVALID;
				if (key.status === "dirty" || value.status === "dirty") status.dirty();
				finalMap.set(key.value, value.value);
			}
			return {
				status: status.value,
				value: finalMap
			};
		}
	}
};
ZodMap.create = (keyType, valueType, params) => {
	return new ZodMap({
		valueType,
		keyType,
		typeName: ZodFirstPartyTypeKind.ZodMap,
		...processCreateParams(params)
	});
};
var ZodSet = class ZodSet extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.set) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.set,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const def = this._def;
		if (def.minSize !== null) {
			if (ctx.data.size < def.minSize.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: def.minSize.value,
					type: "set",
					inclusive: true,
					exact: false,
					message: def.minSize.message
				});
				status.dirty();
			}
		}
		if (def.maxSize !== null) {
			if (ctx.data.size > def.maxSize.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: def.maxSize.value,
					type: "set",
					inclusive: true,
					exact: false,
					message: def.maxSize.message
				});
				status.dirty();
			}
		}
		const valueType = this._def.valueType;
		function finalizeSet(elements) {
			const parsedSet = /* @__PURE__ */ new Set();
			for (const element of elements) {
				if (element.status === "aborted") return INVALID;
				if (element.status === "dirty") status.dirty();
				parsedSet.add(element.value);
			}
			return {
				status: status.value,
				value: parsedSet
			};
		}
		const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
		if (ctx.common.async) return Promise.all(elements).then((elements) => finalizeSet(elements));
		else return finalizeSet(elements);
	}
	min(minSize, message) {
		return new ZodSet({
			...this._def,
			minSize: {
				value: minSize,
				message: errorUtil.toString(message)
			}
		});
	}
	max(maxSize, message) {
		return new ZodSet({
			...this._def,
			maxSize: {
				value: maxSize,
				message: errorUtil.toString(message)
			}
		});
	}
	size(size, message) {
		return this.min(size, message).max(size, message);
	}
	nonempty(message) {
		return this.min(1, message);
	}
};
ZodSet.create = (valueType, params) => {
	return new ZodSet({
		valueType,
		minSize: null,
		maxSize: null,
		typeName: ZodFirstPartyTypeKind.ZodSet,
		...processCreateParams(params)
	});
};
var ZodFunction = class ZodFunction extends ZodType {
	constructor() {
		super(...arguments);
		this.validate = this.implement;
	}
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.function) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.function,
				received: ctx.parsedType
			});
			return INVALID;
		}
		function makeArgsIssue(args, error) {
			return makeIssue({
				data: args,
				path: ctx.path,
				errorMaps: [
					ctx.common.contextualErrorMap,
					ctx.schemaErrorMap,
					getErrorMap(),
					errorMap
				].filter((x) => !!x),
				issueData: {
					code: ZodIssueCode.invalid_arguments,
					argumentsError: error
				}
			});
		}
		function makeReturnsIssue(returns, error) {
			return makeIssue({
				data: returns,
				path: ctx.path,
				errorMaps: [
					ctx.common.contextualErrorMap,
					ctx.schemaErrorMap,
					getErrorMap(),
					errorMap
				].filter((x) => !!x),
				issueData: {
					code: ZodIssueCode.invalid_return_type,
					returnTypeError: error
				}
			});
		}
		const params = { errorMap: ctx.common.contextualErrorMap };
		const fn = ctx.data;
		if (this._def.returns instanceof ZodPromise) {
			const me = this;
			return OK(async function(...args) {
				const error = new ZodError([]);
				const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
					error.addIssue(makeArgsIssue(args, e));
					throw error;
				});
				const result = await Reflect.apply(fn, this, parsedArgs);
				return await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
					error.addIssue(makeReturnsIssue(result, e));
					throw error;
				});
			});
		} else {
			const me = this;
			return OK(function(...args) {
				const parsedArgs = me._def.args.safeParse(args, params);
				if (!parsedArgs.success) throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
				const result = Reflect.apply(fn, this, parsedArgs.data);
				const parsedReturns = me._def.returns.safeParse(result, params);
				if (!parsedReturns.success) throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
				return parsedReturns.data;
			});
		}
	}
	parameters() {
		return this._def.args;
	}
	returnType() {
		return this._def.returns;
	}
	args(...items) {
		return new ZodFunction({
			...this._def,
			args: ZodTuple.create(items).rest(ZodUnknown.create())
		});
	}
	returns(returnType) {
		return new ZodFunction({
			...this._def,
			returns: returnType
		});
	}
	implement(func) {
		return this.parse(func);
	}
	strictImplement(func) {
		return this.parse(func);
	}
	static create(args, returns, params) {
		return new ZodFunction({
			args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
			returns: returns || ZodUnknown.create(),
			typeName: ZodFirstPartyTypeKind.ZodFunction,
			...processCreateParams(params)
		});
	}
};
var ZodLazy = class extends ZodType {
	get schema() {
		return this._def.getter();
	}
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		return this._def.getter()._parse({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		});
	}
};
ZodLazy.create = (getter, params) => {
	return new ZodLazy({
		getter,
		typeName: ZodFirstPartyTypeKind.ZodLazy,
		...processCreateParams(params)
	});
};
var ZodLiteral = class extends ZodType {
	_parse(input) {
		if (input.data !== this._def.value) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				received: ctx.data,
				code: ZodIssueCode.invalid_literal,
				expected: this._def.value
			});
			return INVALID;
		}
		return {
			status: "valid",
			value: input.data
		};
	}
	get value() {
		return this._def.value;
	}
};
ZodLiteral.create = (value, params) => {
	return new ZodLiteral({
		value,
		typeName: ZodFirstPartyTypeKind.ZodLiteral,
		...processCreateParams(params)
	});
};
function createZodEnum(values, params) {
	return new ZodEnum({
		values,
		typeName: ZodFirstPartyTypeKind.ZodEnum,
		...processCreateParams(params)
	});
}
var ZodEnum = class ZodEnum extends ZodType {
	_parse(input) {
		if (typeof input.data !== "string") {
			const ctx = this._getOrReturnCtx(input);
			const expectedValues = this._def.values;
			addIssueToContext(ctx, {
				expected: util.joinValues(expectedValues),
				received: ctx.parsedType,
				code: ZodIssueCode.invalid_type
			});
			return INVALID;
		}
		if (!this._cache) this._cache = new Set(this._def.values);
		if (!this._cache.has(input.data)) {
			const ctx = this._getOrReturnCtx(input);
			const expectedValues = this._def.values;
			addIssueToContext(ctx, {
				received: ctx.data,
				code: ZodIssueCode.invalid_enum_value,
				options: expectedValues
			});
			return INVALID;
		}
		return OK(input.data);
	}
	get options() {
		return this._def.values;
	}
	get enum() {
		const enumValues = {};
		for (const val of this._def.values) enumValues[val] = val;
		return enumValues;
	}
	get Values() {
		const enumValues = {};
		for (const val of this._def.values) enumValues[val] = val;
		return enumValues;
	}
	get Enum() {
		const enumValues = {};
		for (const val of this._def.values) enumValues[val] = val;
		return enumValues;
	}
	extract(values, newDef = this._def) {
		return ZodEnum.create(values, {
			...this._def,
			...newDef
		});
	}
	exclude(values, newDef = this._def) {
		return ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
			...this._def,
			...newDef
		});
	}
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
	_parse(input) {
		const nativeEnumValues = util.getValidEnumValues(this._def.values);
		const ctx = this._getOrReturnCtx(input);
		if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
			const expectedValues = util.objectValues(nativeEnumValues);
			addIssueToContext(ctx, {
				expected: util.joinValues(expectedValues),
				received: ctx.parsedType,
				code: ZodIssueCode.invalid_type
			});
			return INVALID;
		}
		if (!this._cache) this._cache = new Set(util.getValidEnumValues(this._def.values));
		if (!this._cache.has(input.data)) {
			const expectedValues = util.objectValues(nativeEnumValues);
			addIssueToContext(ctx, {
				received: ctx.data,
				code: ZodIssueCode.invalid_enum_value,
				options: expectedValues
			});
			return INVALID;
		}
		return OK(input.data);
	}
	get enum() {
		return this._def.values;
	}
};
ZodNativeEnum.create = (values, params) => {
	return new ZodNativeEnum({
		values,
		typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
		...processCreateParams(params)
	});
};
var ZodPromise = class extends ZodType {
	unwrap() {
		return this._def.type;
	}
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.promise,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK((ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data)).then((data) => {
			return this._def.type.parseAsync(data, {
				path: ctx.path,
				errorMap: ctx.common.contextualErrorMap
			});
		}));
	}
};
ZodPromise.create = (schema, params) => {
	return new ZodPromise({
		type: schema,
		typeName: ZodFirstPartyTypeKind.ZodPromise,
		...processCreateParams(params)
	});
};
var ZodEffects = class extends ZodType {
	innerType() {
		return this._def.schema;
	}
	sourceType() {
		return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
	}
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		const effect = this._def.effect || null;
		const checkCtx = {
			addIssue: (arg) => {
				addIssueToContext(ctx, arg);
				if (arg.fatal) status.abort();
				else status.dirty();
			},
			get path() {
				return ctx.path;
			}
		};
		checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
		if (effect.type === "preprocess") {
			const processed = effect.transform(ctx.data, checkCtx);
			if (ctx.common.async) return Promise.resolve(processed).then(async (processed) => {
				if (status.value === "aborted") return INVALID;
				const result = await this._def.schema._parseAsync({
					data: processed,
					path: ctx.path,
					parent: ctx
				});
				if (result.status === "aborted") return INVALID;
				if (result.status === "dirty") return DIRTY(result.value);
				if (status.value === "dirty") return DIRTY(result.value);
				return result;
			});
			else {
				if (status.value === "aborted") return INVALID;
				const result = this._def.schema._parseSync({
					data: processed,
					path: ctx.path,
					parent: ctx
				});
				if (result.status === "aborted") return INVALID;
				if (result.status === "dirty") return DIRTY(result.value);
				if (status.value === "dirty") return DIRTY(result.value);
				return result;
			}
		}
		if (effect.type === "refinement") {
			const executeRefinement = (acc) => {
				const result = effect.refinement(acc, checkCtx);
				if (ctx.common.async) return Promise.resolve(result);
				if (result instanceof Promise) throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
				return acc;
			};
			if (ctx.common.async === false) {
				const inner = this._def.schema._parseSync({
					data: ctx.data,
					path: ctx.path,
					parent: ctx
				});
				if (inner.status === "aborted") return INVALID;
				if (inner.status === "dirty") status.dirty();
				executeRefinement(inner.value);
				return {
					status: status.value,
					value: inner.value
				};
			} else return this._def.schema._parseAsync({
				data: ctx.data,
				path: ctx.path,
				parent: ctx
			}).then((inner) => {
				if (inner.status === "aborted") return INVALID;
				if (inner.status === "dirty") status.dirty();
				return executeRefinement(inner.value).then(() => {
					return {
						status: status.value,
						value: inner.value
					};
				});
			});
		}
		if (effect.type === "transform") if (ctx.common.async === false) {
			const base = this._def.schema._parseSync({
				data: ctx.data,
				path: ctx.path,
				parent: ctx
			});
			if (!isValid(base)) return INVALID;
			const result = effect.transform(base.value, checkCtx);
			if (result instanceof Promise) throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
			return {
				status: status.value,
				value: result
			};
		} else return this._def.schema._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}).then((base) => {
			if (!isValid(base)) return INVALID;
			return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
				status: status.value,
				value: result
			}));
		});
		util.assertNever(effect);
	}
};
ZodEffects.create = (schema, effect, params) => {
	return new ZodEffects({
		schema,
		typeName: ZodFirstPartyTypeKind.ZodEffects,
		effect,
		...processCreateParams(params)
	});
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
	return new ZodEffects({
		schema,
		effect: {
			type: "preprocess",
			transform: preprocess
		},
		typeName: ZodFirstPartyTypeKind.ZodEffects,
		...processCreateParams(params)
	});
};
var ZodOptional = class extends ZodType {
	_parse(input) {
		if (this._getType(input) === ZodParsedType.undefined) return OK(void 0);
		return this._def.innerType._parse(input);
	}
	unwrap() {
		return this._def.innerType;
	}
};
ZodOptional.create = (type, params) => {
	return new ZodOptional({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodOptional,
		...processCreateParams(params)
	});
};
var ZodNullable = class extends ZodType {
	_parse(input) {
		if (this._getType(input) === ZodParsedType.null) return OK(null);
		return this._def.innerType._parse(input);
	}
	unwrap() {
		return this._def.innerType;
	}
};
ZodNullable.create = (type, params) => {
	return new ZodNullable({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodNullable,
		...processCreateParams(params)
	});
};
var ZodDefault = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		let data = ctx.data;
		if (ctx.parsedType === ZodParsedType.undefined) data = this._def.defaultValue();
		return this._def.innerType._parse({
			data,
			path: ctx.path,
			parent: ctx
		});
	}
	removeDefault() {
		return this._def.innerType;
	}
};
ZodDefault.create = (type, params) => {
	return new ZodDefault({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodDefault,
		defaultValue: typeof params.default === "function" ? params.default : () => params.default,
		...processCreateParams(params)
	});
};
var ZodCatch = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		const newCtx = {
			...ctx,
			common: {
				...ctx.common,
				issues: []
			}
		};
		const result = this._def.innerType._parse({
			data: newCtx.data,
			path: newCtx.path,
			parent: { ...newCtx }
		});
		if (isAsync(result)) return result.then((result) => {
			return {
				status: "valid",
				value: result.status === "valid" ? result.value : this._def.catchValue({
					get error() {
						return new ZodError(newCtx.common.issues);
					},
					input: newCtx.data
				})
			};
		});
		else return {
			status: "valid",
			value: result.status === "valid" ? result.value : this._def.catchValue({
				get error() {
					return new ZodError(newCtx.common.issues);
				},
				input: newCtx.data
			})
		};
	}
	removeCatch() {
		return this._def.innerType;
	}
};
ZodCatch.create = (type, params) => {
	return new ZodCatch({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodCatch,
		catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
		...processCreateParams(params)
	});
};
var ZodNaN = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.nan) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.nan,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return {
			status: "valid",
			value: input.data
		};
	}
};
ZodNaN.create = (params) => {
	return new ZodNaN({
		typeName: ZodFirstPartyTypeKind.ZodNaN,
		...processCreateParams(params)
	});
};
var ZodBranded = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		const data = ctx.data;
		return this._def.type._parse({
			data,
			path: ctx.path,
			parent: ctx
		});
	}
	unwrap() {
		return this._def.type;
	}
};
var ZodPipeline = class ZodPipeline extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.common.async) {
			const handleAsync = async () => {
				const inResult = await this._def.in._parseAsync({
					data: ctx.data,
					path: ctx.path,
					parent: ctx
				});
				if (inResult.status === "aborted") return INVALID;
				if (inResult.status === "dirty") {
					status.dirty();
					return DIRTY(inResult.value);
				} else return this._def.out._parseAsync({
					data: inResult.value,
					path: ctx.path,
					parent: ctx
				});
			};
			return handleAsync();
		} else {
			const inResult = this._def.in._parseSync({
				data: ctx.data,
				path: ctx.path,
				parent: ctx
			});
			if (inResult.status === "aborted") return INVALID;
			if (inResult.status === "dirty") {
				status.dirty();
				return {
					status: "dirty",
					value: inResult.value
				};
			} else return this._def.out._parseSync({
				data: inResult.value,
				path: ctx.path,
				parent: ctx
			});
		}
	}
	static create(a, b) {
		return new ZodPipeline({
			in: a,
			out: b,
			typeName: ZodFirstPartyTypeKind.ZodPipeline
		});
	}
};
var ZodReadonly = class extends ZodType {
	_parse(input) {
		const result = this._def.innerType._parse(input);
		const freeze = (data) => {
			if (isValid(data)) data.value = Object.freeze(data.value);
			return data;
		};
		return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
	}
	unwrap() {
		return this._def.innerType;
	}
};
ZodReadonly.create = (type, params) => {
	return new ZodReadonly({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodReadonly,
		...processCreateParams(params)
	});
};
ZodObject.lazycreate;
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind) {
	ZodFirstPartyTypeKind["ZodString"] = "ZodString";
	ZodFirstPartyTypeKind["ZodNumber"] = "ZodNumber";
	ZodFirstPartyTypeKind["ZodNaN"] = "ZodNaN";
	ZodFirstPartyTypeKind["ZodBigInt"] = "ZodBigInt";
	ZodFirstPartyTypeKind["ZodBoolean"] = "ZodBoolean";
	ZodFirstPartyTypeKind["ZodDate"] = "ZodDate";
	ZodFirstPartyTypeKind["ZodSymbol"] = "ZodSymbol";
	ZodFirstPartyTypeKind["ZodUndefined"] = "ZodUndefined";
	ZodFirstPartyTypeKind["ZodNull"] = "ZodNull";
	ZodFirstPartyTypeKind["ZodAny"] = "ZodAny";
	ZodFirstPartyTypeKind["ZodUnknown"] = "ZodUnknown";
	ZodFirstPartyTypeKind["ZodNever"] = "ZodNever";
	ZodFirstPartyTypeKind["ZodVoid"] = "ZodVoid";
	ZodFirstPartyTypeKind["ZodArray"] = "ZodArray";
	ZodFirstPartyTypeKind["ZodObject"] = "ZodObject";
	ZodFirstPartyTypeKind["ZodUnion"] = "ZodUnion";
	ZodFirstPartyTypeKind["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
	ZodFirstPartyTypeKind["ZodIntersection"] = "ZodIntersection";
	ZodFirstPartyTypeKind["ZodTuple"] = "ZodTuple";
	ZodFirstPartyTypeKind["ZodRecord"] = "ZodRecord";
	ZodFirstPartyTypeKind["ZodMap"] = "ZodMap";
	ZodFirstPartyTypeKind["ZodSet"] = "ZodSet";
	ZodFirstPartyTypeKind["ZodFunction"] = "ZodFunction";
	ZodFirstPartyTypeKind["ZodLazy"] = "ZodLazy";
	ZodFirstPartyTypeKind["ZodLiteral"] = "ZodLiteral";
	ZodFirstPartyTypeKind["ZodEnum"] = "ZodEnum";
	ZodFirstPartyTypeKind["ZodEffects"] = "ZodEffects";
	ZodFirstPartyTypeKind["ZodNativeEnum"] = "ZodNativeEnum";
	ZodFirstPartyTypeKind["ZodOptional"] = "ZodOptional";
	ZodFirstPartyTypeKind["ZodNullable"] = "ZodNullable";
	ZodFirstPartyTypeKind["ZodDefault"] = "ZodDefault";
	ZodFirstPartyTypeKind["ZodCatch"] = "ZodCatch";
	ZodFirstPartyTypeKind["ZodPromise"] = "ZodPromise";
	ZodFirstPartyTypeKind["ZodBranded"] = "ZodBranded";
	ZodFirstPartyTypeKind["ZodPipeline"] = "ZodPipeline";
	ZodFirstPartyTypeKind["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
const stringType = ZodString.create;
const numberType = ZodNumber.create;
ZodNaN.create;
ZodBigInt.create;
const booleanType = ZodBoolean.create;
ZodDate.create;
ZodSymbol.create;
ZodUndefined.create;
ZodNull.create;
ZodAny.create;
ZodUnknown.create;
ZodNever.create;
ZodVoid.create;
const arrayType = ZodArray.create;
const objectType = ZodObject.create;
ZodObject.strictCreate;
const unionType = ZodUnion.create;
ZodDiscriminatedUnion.create;
ZodIntersection.create;
ZodTuple.create;
const recordType = ZodRecord.create;
ZodMap.create;
ZodSet.create;
ZodFunction.create;
ZodLazy.create;
const literalType = ZodLiteral.create;
const enumType = ZodEnum.create;
ZodNativeEnum.create;
ZodPromise.create;
ZodEffects.create;
ZodOptional.create;
ZodNullable.create;
ZodEffects.createWithPreprocess;
ZodPipeline.create;
//#endregion
//#region lib/robot-model.ts
const versions = {
	wpilib: "2026.2.1",
	robotpy: "2026.2.2",
	rev: "2026.0.5",
	robotpyRev: "2026.0.4",
	phoenix: "26.3.0",
	pathplanner: "2026.1.2",
	checked: "2026-09-28"
};
const id = stringType().regex(/^[A-Za-z][A-Za-z0-9_]{0,39}$/);
const finite = numberType().finite();
const motorSchema = objectType({
	id,
	name: stringType().min(1).max(60),
	type: enumType([
		"SparkMax",
		"SparkFlex",
		"TalonFX"
	]),
	can: finite.int().min(0).max(62),
	inverted: booleanType(),
	sensorSign: unionType([literalType(1), literalType(-1)]),
	current: finite.int().min(1).max(80),
	subsystem: id,
	role: enumType([
		"left",
		"right",
		"mechanism"
	]),
	limit: finite.int().min(-1).max(9)
}).strict();
const projectSchema = objectType({
	schema: literalType(1),
	name: stringType().min(1).max(60),
	team: finite.int().min(0).max(99999),
	language: enumType([
		"Java",
		"C++",
		"Python"
	]),
	motors: arrayType(motorSchema).min(2).max(40),
	subsystems: arrayType(objectType({
		id,
		name: stringType().min(1).max(40),
		description: stringType().max(200)
	})).min(1).max(20),
	commands: arrayType(objectType({
		id,
		name: stringType().min(1).max(40),
		subsystem: id,
		output: finite.min(-1).max(1),
		timeout: finite.min(.05).max(15)
	})).max(30),
	bindings: arrayType(objectType({
		id,
		controller: enumType(["driver", "operator"]),
		button: finite.int().min(1).max(20),
		command: id,
		behavior: enumType([
			"whileHeld",
			"onPress",
			"toggle"
		])
	})).max(40),
	controls: objectType({
		driverPort: finite.int().min(0).max(5),
		operatorPort: finite.int().min(0).max(5),
		driverType: enumType(["Xbox", "Joystick"]),
		operatorType: enumType(["Xbox", "Joystick"]),
		forwardAxis: finite.int().min(0).max(11),
		turnAxis: finite.int().min(0).max(11),
		forwardSign: unionType([literalType(1), literalType(-1)]),
		turnSign: unionType([literalType(1), literalType(-1)]),
		deadband: finite.min(0).max(.3),
		maxOutput: finite.min(.05).max(1)
	}),
	drive: objectType({
		trackWidth: finite.min(.2).max(2),
		wheelDiameter: finite.min(.04).max(.5),
		gearing: finite.min(1).max(40),
		maxSpeed: finite.min(.1).max(8),
		mass: finite.min(5).max(100),
		moi: finite.min(.1).max(30),
		kS: finite.min(0).max(3),
		kV: finite.min(.1).max(20),
		kP: finite.min(0).max(20),
		gyro: enumType(["ADXRS450", "Pigeon2"]),
		gyroCan: finite.int().min(0).max(62)
	}),
	auto: objectType({
		name: id,
		maxSpeed: finite.min(.1).max(6),
		maxAcceleration: finite.min(.1).max(6),
		waypoints: arrayType(objectType({
			x: finite.min(0).max(16.54),
			y: finite.min(0).max(8.07)
		})).min(2).max(30),
		steps: arrayType(objectType({
			id,
			type: enumType([
				"path",
				"command",
				"wait"
			]),
			command: stringType().max(40),
			seconds: finite.min(.05).max(15)
		})).max(20)
	}),
	checks: recordType(booleanType())
}).strict();
[
	{
		id: "leftFront",
		name: "Left front",
		can: 1,
		role: "left",
		subsystem: "drive",
		inverted: false,
		sensorSign: 1
	},
	{
		id: "leftRear",
		name: "Left rear",
		can: 2,
		role: "left",
		subsystem: "drive",
		inverted: false,
		sensorSign: 1
	},
	{
		id: "rightFront",
		name: "Right front",
		can: 3,
		role: "right",
		subsystem: "drive",
		inverted: true,
		sensorSign: -1
	},
	{
		id: "rightRear",
		name: "Right rear",
		can: 4,
		role: "right",
		subsystem: "drive",
		inverted: true,
		sensorSign: -1
	},
	{
		id: "intakeMotor",
		name: "Intake motor",
		can: 5,
		role: "mechanism",
		subsystem: "intake",
		inverted: false,
		sensorSign: 1
	},
	{
		id: "shooterMotor",
		name: "Shooter motor",
		can: 6,
		role: "mechanism",
		subsystem: "shooter",
		inverted: false,
		sensorSign: 1
	}
].map((m) => ({
	...m,
	type: "SparkMax",
	current: 30,
	limit: -1
}));
const benchChecks = [
	["mechanical", "Robot is supported; mechanisms are clear and secured."],
	["can", "CAN IDs, firmware, wiring, and termination are verified."],
	["direction", "Drive output and encoder signs agree with forward motion."],
	["gyro", "Gyro heading and odometry are verified on the robot."],
	["limits", "Motor current limits and active-low limit switches are tested."],
	["tuning", "Wheel geometry, feedforward, feedback, and path constraints are tuned."],
	["disable", "Disable, button release, command timeout, and autonomous interruption stop outputs."],
	["simulation", "Project compiles and the command flow passes simulation."],
	["field", "Autonomous is tested at reduced speed on the actual field layout."]
];
function validate(p) {
	const issues = [];
	const error = (area, message) => issues.push({
		level: "error",
		area,
		message
	});
	const warn = (area, message) => issues.push({
		level: "warning",
		area,
		message
	});
	const shape = projectSchema.safeParse(p);
	if (!shape.success) {
		shape.error.issues.forEach((i) => error("Configuration", `${i.path.join(" → ")}: ${i.message}`));
		return issues;
	}
	if (p.team < 1) error("Code & export", "Enter your real team number before exporting robot code.");
	const used = /* @__PURE__ */ new Map();
	p.motors.forEach((m) => {
		if (used.has(m.can)) error("Hardware", `CAN ${m.can} is shared by ${used.get(m.can)} and ${m.name}.`);
		used.set(m.can, m.name);
		if (!p.subsystems.some((s) => s.id === m.subsystem)) error("Hardware", `${m.name} references a missing subsystem.`);
		if (m.role === "mechanism" === (m.subsystem === "drive")) error("Hardware", `${m.name}: drivetrain motors need a left/right role; mechanisms need a mechanism role.`);
	});
	if (p.drive.gyro === "Pigeon2" && used.has(p.drive.gyroCan)) error("Hardware", `Pigeon 2 CAN ${p.drive.gyroCan} overlaps a motor.`);
	for (const role of ["left", "right"]) if (!p.motors.some((m) => m.role === role && m.subsystem === "drive")) error("Hardware", `Add at least one ${role} drivetrain motor.`);
	for (const role of ["left", "right"]) {
		const ms = p.motors.filter((m) => m.role === role);
		if (new Set(ms.map((m) => m.type === "TalonFX" ? "kraken" : "neo")).size > 1) error("Hardware", `Use one motor family per drive side for the PathPlanner motor model.`);
	}
	if (new Set(p.motors.filter((m) => m.subsystem === "drive").map((m) => m.type === "TalonFX" ? "kraken" : "neo")).size > 1) error("Hardware", "Both drive sides must use the same motor family.");
	if (p.motors.filter((m) => m.role === "left").length !== p.motors.filter((m) => m.role === "right").length) error("Hardware", "Use equal motor counts on the left and right drive sides.");
	if (!p.subsystems.some((s) => s.id === "drive")) error("Subsystems", "The drivetrain subsystem is required.");
	for (const side of ["left", "right"]) if (p.motors.filter((m) => m.role === side).length !== 2) error("Hardware", "PathPlanner differential configuration requires two drive motors per side.");
	if (new Set(p.motors.filter((m) => m.subsystem === "drive").map((m) => m.type)).size > 1) error("Hardware", "Use the same controller and motor type for all drive motors.");
	const ports = p.motors.filter((m) => m.limit >= 0).map((m) => m.limit);
	if (new Set(ports).size !== ports.length) error("Hardware", "Each limit switch needs a unique DIO channel.");
	for (const group of [
		p.motors,
		p.subsystems,
		p.commands,
		p.bindings,
		p.auto.steps
	]) if (new Set(group.map((x) => x.id)).size !== group.length) error("Configuration", "Duplicate internal identifiers were found.");
	p.commands.forEach((c) => {
		if (c.subsystem === "drive") error("Commands", "Drive actions belong in autonomous paths, not mechanism commands.");
		if (!p.subsystems.some((s) => s.id === c.subsystem)) error("Commands", `${c.name} references a missing subsystem.`);
		if (!p.motors.some((m) => m.subsystem === c.subsystem)) error("Commands", `${c.name} has no motors assigned.`);
	});
	const binds = /* @__PURE__ */ new Set();
	p.bindings.forEach((b) => {
		const key = `${b.controller}:${b.button}`;
		if (binds.has(key)) error("Controls", `${b.controller} button ${b.button} has multiple assignments.`);
		binds.add(key);
		if (!p.commands.some((c) => c.id === b.command)) error("Controls", "A button refers to a deleted command.");
		if (p.controls[`${b.controller}Type`] === "Xbox" && b.button > 10) error("Controls", "Xbox buttons must be 1–10.");
	});
	if (p.controls.driverPort === p.controls.operatorPort) error("Controls", "Driver and operator USB ports must differ.");
	if (p.controls.forwardAxis === p.controls.turnAxis) error("Controls", "Forward and turn must use different axes.");
	p.auto.waypoints.forEach((w, i) => {
		if (i && Math.hypot(w.x - p.auto.waypoints[i - 1].x, w.y - p.auto.waypoints[i - 1].y) < .1) error("Autonomous", "Waypoints must be at least 0.1 m apart.");
	});
	if (p.auto.maxSpeed > p.drive.maxSpeed) error("Autonomous", "Path speed exceeds the drivetrain maximum speed.");
	if (p.auto.steps.filter((s) => s.type === "path").length > 1) error("Autonomous", "This route can appear once in the sequence; duplicate it in PathPlanner for multi-path routines.");
	p.auto.steps.forEach((s) => {
		if (s.type === "command" && !p.commands.some((c) => c.id === s.command)) error("Autonomous", "An autonomous step refers to a missing command.");
	});
	if (!p.auto.steps.length) warn("Autonomous", "No autonomous steps are configured. The robot will remain stopped.");
	warn("Preflight", "Generated source requires a local WPILib build, motor-direction verification, tuning, and on-robot testing.");
	if (benchChecks.some(([key]) => !p.checks[key])) warn("Preflight", "Complete the bench and field checklist before competition.");
	return issues;
}
//#endregion
//#region lib/gen-java.ts
const q$1 = JSON.stringify;
function javaSources(p) {
	const d = p.drive, c = p.controls;
	const motor = (m) => `new MotorIO(${q$1(m.type)}, ${m.can}, ${m.inverted}, ${m.sensorSign}, ${m.current}, ${m.limit})`;
	const driveMotors = (side) => p.motors.filter((m) => m.role === side).map(motor).join(", ");
	const mechanisms = p.subsystems.filter((s) => s.id !== "drive");
	return {
		"src/main/java/frc/robot/Robot.java": `package frc.robot;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.DataLogManager;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
public class Robot extends TimedRobot {
  private RobotContainer container;
  private Command autonomous;
  @Override public void robotInit() { DataLogManager.start(); DriverStation.startDataLog(DataLogManager.getLog()); container = new RobotContainer(); }
  @Override public void robotPeriodic() { CommandScheduler.getInstance().run(); }
  @Override public void autonomousInit() { container.stopAll(); autonomous = container.autonomous(); if (autonomous != null) CommandScheduler.getInstance().schedule(autonomous); }
  @Override public void teleopInit() { if (autonomous != null) autonomous.cancel(); container.stopAll(); }
  @Override public void disabledInit() { CommandScheduler.getInstance().cancelAll(); if (container != null) container.stopAll(); }
  @Override public void testInit() { CommandScheduler.getInstance().cancelAll(); container.stopAll(); }
}
`,
		"src/main/java/frc/robot/Main.java": `package frc.robot;
import edu.wpi.first.wpilibj.RobotBase;
public final class Main { private Main() {} public static void main(String... args) { RobotBase.startRobot(Robot::new); } }
`,
		"src/main/java/frc/robot/MotorIO.java": `package frc.robot;
import com.revrobotics.*;
import com.revrobotics.spark.*;
import com.revrobotics.spark.config.*;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.signals.*;
import edu.wpi.first.wpilibj.*;
import edu.wpi.first.math.MathUtil;
/** Vendor boundary. Encoder units are motor rotations and rotations/second. */
public final class MotorIO {
  private SparkBase spark; private TalonFX talon;
  private final double sign; private final DigitalInput limit;
  private boolean configured = false;
  public MotorIO(String kind, int can, boolean inverted, double encoderSign, int amps, int dio) {
    sign = encoderSign; limit = dio >= 0 ? new DigitalInput(dio) : null;
    if (kind.equals("TalonFX")) {
      talon = new TalonFX(can);
      var config = new TalonFXConfiguration();
      config.MotorOutput.Inverted = inverted ? InvertedValue.Clockwise_Positive : InvertedValue.CounterClockwise_Positive;
      config.MotorOutput.NeutralMode = NeutralModeValue.Brake;
      config.CurrentLimits.StatorCurrentLimitEnable = true;
      config.CurrentLimits.StatorCurrentLimit = amps;
      for (int i=0;i<3&&!configured;i++) configured=talon.getConfigurator().apply(config).isOK();
    } else {
      spark = kind.equals("SparkFlex") ? new SparkFlex(can, SparkLowLevel.MotorType.kBrushless) : new SparkMax(can, SparkLowLevel.MotorType.kBrushless);
      SparkBaseConfig config = kind.equals("SparkFlex") ? new SparkFlexConfig() : new SparkMaxConfig();
      config.inverted(inverted).idleMode(SparkBaseConfig.IdleMode.kBrake).smartCurrentLimit(amps);
      for(int i=0;i<3&&!configured;i++) configured=spark.configure(config, ResetMode.kResetSafeParameters, PersistMode.kPersistParameters)==REVLibError.kOk;
    }
    if(!configured) DriverStation.reportError("Motor configuration failed, output inhibited: CAN "+can,false);
  }
  public double position() { return sign*(spark!=null?spark.getEncoder().getPosition():talon.getPosition().getValueAsDouble()); }
  public double velocity() { return sign*(spark!=null?spark.getEncoder().getVelocity()/60.0:talon.getVelocity().getValueAsDouble()); }
  public boolean ready() { return configured; }
  public void voltage(double volts) {
    if(!configured || !DriverStation.isEnabled() || !Double.isFinite(volts)) volts=0;
    if(limit!=null && !limit.get() && volts>0) volts=0;
    volts=MathUtil.clamp(volts,-12,12);
    if(spark!=null) spark.setVoltage(volts); else talon.setVoltage(volts);
  }
  public void stop() { voltage(0); }
}
`,
		"src/main/java/frc/robot/Mechanism.java": `package frc.robot;
import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj2.command.*;
/** Owns every motor in one mechanism and supplies bounded commands. */
public final class Mechanism extends SubsystemBase {
  private final MotorIO[] motors; private double last=0;
  public Mechanism(String name, MotorIO... motors) { setName(name); this.motors=motors; }
  public void set(double output) { last=Timer.getFPGATimestamp(); for(var motor:motors) motor.voltage(output*12.0); }
  public void stop() { for(var motor:motors) motor.stop(); }
  public Command action(double output,double timeout) { return runEnd(()->set(output),this::stop).withTimeout(timeout); }
  @Override public void periodic() { if(DriverStation.isDisabled()||Timer.getFPGATimestamp()-last>0.1) stop(); }
}
`,
		"src/main/java/frc/robot/Drive.java": `package frc.robot;
import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.smartdashboard.*;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.*;
import edu.wpi.first.math.kinematics.*;
import edu.wpi.first.math.controller.PIDController;
import com.ctre.phoenix6.hardware.Pigeon2;
import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.config.RobotConfig;
import com.pathplanner.lib.controllers.PPLTVController;
public final class Drive extends SubsystemBase {
  private final MotorIO[] left={${driveMotors("left")}};
  private final MotorIO[] right={${driveMotors("right")}};
  private final ${d.gyro === "Pigeon2" ? `Pigeon2 gyro=new Pigeon2(${d.gyroCan})` : "ADXRS450_Gyro gyro=new ADXRS450_Gyro()"};
  private final double metersPerRotation=Math.PI*${d.wheelDiameter}/${d.gearing};
  private final DifferentialDriveKinematics kinematics=new DifferentialDriveKinematics(${d.trackWidth});
  private final DifferentialDriveOdometry odometry;
  private final PIDController leftPID=new PIDController(${d.kP},0,0),rightPID=new PIDController(${d.kP},0,0);
  private final Field2d field=new Field2d();
  private double last=0; private boolean autoReady=false;
  public Drive() {
    ${d.gyro === "ADXRS450" ? "gyro.calibrate();" : ""}
    odometry=new DifferentialDriveOdometry(heading(),distance(left),distance(right));
    SmartDashboard.putData("Robot pose",field);
    try { AutoBuilder.configure(this::pose,this::resetPose,this::speeds,(speeds,feedforwards)->driveSpeeds(speeds),new PPLTVController(0.02),RobotConfig.fromGUISettings(),()->DriverStation.getAlliance().orElse(DriverStation.Alliance.Blue)==DriverStation.Alliance.Red,this);autoReady=true; }
    catch(Exception e) { DriverStation.reportError("Autonomous configuration failed: "+e.getMessage(),false); }
  }
  private Rotation2d heading() { return gyro.getRotation2d(); }
  private double distance(MotorIO[] motors) { double sum=0;for(var m:motors)sum+=m.position();return motors.length==0?0:sum/motors.length*metersPerRotation; }
  private double velocity(MotorIO[] motors) { double sum=0;for(var m:motors)sum+=m.velocity();return motors.length==0?0:sum/motors.length*metersPerRotation; }
  public Pose2d pose() { return odometry.getPoseMeters(); }
  public void resetPose(Pose2d pose) { odometry.resetPosition(heading(),distance(left),distance(right),pose);leftPID.reset();rightPID.reset(); }
  public ChassisSpeeds speeds() { return kinematics.toChassisSpeeds(new DifferentialDriveWheelSpeeds(velocity(left),velocity(right))); }
  public boolean autoReady() { return autoReady; }
  private void voltage(double l,double r) { last=Timer.getFPGATimestamp();for(var m:left)if(!m.ready())l=r=0;for(var m:right)if(!m.ready())l=r=0;for(var m:left)m.voltage(l);for(var m:right)m.voltage(r); }
  public void stop() { voltage(0,0);leftPID.reset();rightPID.reset(); }
  public void arcade(double forward,double turn) {
    if(!DriverStation.isTeleopEnabled()) { stop();return; }
    double l=forward-turn,r=forward+turn,scale=Math.max(1,Math.max(Math.abs(l),Math.abs(r)));
    voltage(l/scale*12*${c.maxOutput},r/scale*12*${c.maxOutput});
  }
  private double ff(double velocity) { return Math.abs(velocity)<0.001?0:Math.copySign(${d.kS},velocity)+${d.kV}*velocity; }
  private void driveSpeeds(ChassisSpeeds speeds) {
    var wheels=kinematics.toWheelSpeeds(speeds);wheels.desaturate(${d.maxSpeed});
    voltage(ff(wheels.leftMetersPerSecond)+leftPID.calculate(velocity(left),wheels.leftMetersPerSecond),ff(wheels.rightMetersPerSecond)+rightPID.calculate(velocity(right),wheels.rightMetersPerSecond));
  }
  @Override public void periodic() {
    if(DriverStation.isDisabled()||Timer.getFPGATimestamp()-last>0.1)stop();
    odometry.update(heading(),distance(left),distance(right));field.setRobotPose(pose());
    SmartDashboard.putNumber("Drive/left meters",distance(left));SmartDashboard.putNumber("Drive/right meters",distance(right));SmartDashboard.putBoolean("Drive/auto configured",autoReady);
  }
}
`,
		"src/main/java/frc/robot/RobotContainer.java": `package frc.robot;
import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.smartdashboard.*;
import edu.wpi.first.math.MathUtil;
import edu.wpi.first.wpilibj2.command.*;
import edu.wpi.first.wpilibj2.command.button.Trigger;
import com.pathplanner.lib.auto.NamedCommands;
import com.pathplanner.lib.commands.PathPlannerAuto;
public final class RobotContainer {
  private final Drive drive=new Drive();
  private final GenericHID driver=new GenericHID(${c.driverPort}),operator=new GenericHID(${c.operatorPort});
  ${mechanisms.map((s) => `private final Mechanism mechanism_${s.id}=new Mechanism(${q$1(s.name)}${p.motors.filter((m) => m.subsystem === s.id).map((m) => ", " + motor(m)).join("")});`).join("\n  ")}
  private final SendableChooser<Command> chooser=new SendableChooser<>();
  public RobotContainer() {
    drive.setDefaultCommand(drive.runEnd(()->drive.arcade(${c.forwardSign}*MathUtil.applyDeadband(driver.getRawAxis(${c.forwardAxis}),${c.deadband}),${c.turnSign}*MathUtil.applyDeadband(driver.getRawAxis(${c.turnAxis}),${c.deadband})),drive::stop));
    ${p.commands.map((x) => `NamedCommands.registerCommand(${q$1(x.id)},action_${x.id}());`).join("\n    ")}
    ${p.bindings.map((b) => `new Trigger(()->DriverStation.isTeleopEnabled() && ${b.controller}.getRawButton(${b.button})).${b.behavior === "whileHeld" ? "whileTrue" : b.behavior === "onPress" ? "onTrue" : "toggleOnTrue"}(action_${b.command}());`).join("\n    ")}
    chooser.setDefaultOption("Do nothing",Commands.none());
    if(drive.autoReady()) try { chooser.addOption(${q$1(p.auto.name)},new PathPlannerAuto(${q$1(p.auto.name)}).withTimeout(15).finallyDo(interrupted->stopAll())); } catch(Exception e) { DriverStation.reportError("Auto failed to load: "+e.getMessage(),false); }
    SmartDashboard.putData("Auto chooser",chooser);
  }
  ${p.commands.map((x) => `private Command action_${x.id}() { return mechanism_${x.subsystem}.action(${x.output},${x.timeout}).withName(${q$1(x.name)}); }`).join("\n  ")}
  public Command autonomous() { return chooser.getSelected(); }
  public void stopAll() { drive.stop(); ${mechanisms.map((s) => `mechanism_${s.id}.stop();`).join(" ")} }
}
`
	};
}
//#endregion
//#region lib/gen-python.ts
function pythonSources(p) {
	return {
		"robot.py": `import commands2
import wpilib
from wpimath import applyDeadband
from commands2.button import Trigger
from pathplannerlib.auto import NamedCommands, PathPlannerAuto
from config import CONFIG
from hardware import MotorIO, Mechanism
from drive import Drive

class Robot(wpilib.TimedRobot):
    def robotInit(self):
        wpilib.DataLogManager.start()
        wpilib.DriverStation.startDataLog(wpilib.DataLogManager.getLog())
        self.drive = Drive()
        self.driver = wpilib.Joystick(CONFIG['controls']['driverPort'])
        self.operator = wpilib.Joystick(CONFIG['controls']['operatorPort'])
        self.mechanisms = {s['id']: Mechanism(s['name'], [MotorIO(m) for m in CONFIG['motors'] if m['subsystem'] == s['id']]) for s in CONFIG['subsystems'] if s['id'] != 'drive'}
        self.drive.setDefaultCommand(self.drive.runEnd(self.teleop_drive, self.drive.stop))
        for command in CONFIG['commands']:
            NamedCommands.registerCommand(command['id'], self.action(command['id']))
        self.triggers = []
        for binding in CONFIG['bindings']:
            controller = self.driver if binding['controller'] == 'driver' else self.operator
            trigger = Trigger(lambda controller=controller, button=binding['button']: wpilib.DriverStation.isTeleopEnabled() and controller.getRawButton(button))
            getattr(trigger, {'whileHeld': 'whileTrue', 'onPress': 'onTrue', 'toggle': 'toggleOnTrue'}[binding['behavior']])(self.action(binding['command']))
            self.triggers.append(trigger)
        self.chooser = wpilib.SendableChooser()
        self.chooser.setDefaultOption('Do nothing', commands2.cmd.none())
        if self.drive.auto_ready:
            try:
                auto = PathPlannerAuto(CONFIG['auto']['name']).withTimeout(15).finallyDo(lambda interrupted: self.stop_all())
                self.chooser.addOption(CONFIG['auto']['name'], auto)
            except Exception as error:
                wpilib.reportError('Autonomous failed to load: ' + str(error))
        wpilib.SmartDashboard.putData('Auto chooser', self.chooser)
        self.autonomous = None

    def action(self, command_id):
        c = next(c for c in CONFIG['commands'] if c['id'] == command_id)
        return self.mechanisms[c['subsystem']].action(c['output'], c['timeout']).withName(c['name'])

    def teleop_drive(self):
        c = CONFIG['controls']
        self.drive.arcade(c['forwardSign'] * applyDeadband(self.driver.getRawAxis(c['forwardAxis']), c['deadband']), c['turnSign'] * applyDeadband(self.driver.getRawAxis(c['turnAxis']), c['deadband']))

    def robotPeriodic(self):
        commands2.CommandScheduler.getInstance().run()

    def autonomousInit(self):
        self.stop_all()
        self.autonomous = self.chooser.getSelected()
        if self.autonomous is not None:
            self.autonomous.schedule()

    def teleopInit(self):
        if self.autonomous is not None:
            self.autonomous.cancel()
        self.stop_all()

    def disabledInit(self):
        commands2.CommandScheduler.getInstance().cancelAll()
        self.stop_all()

    def testInit(self):
        commands2.CommandScheduler.getInstance().cancelAll()
        self.stop_all()

    def stop_all(self):
        self.drive.stop()
        for mechanism in self.mechanisms.values():
            mechanism.stop()
`,
		"config.py": `# Generated configuration. Edit the project in RobotForge and re-export.\nimport json\nCONFIG = json.loads(${JSON.stringify(JSON.stringify(p))})\n`,
		"hardware.py": `import math
import commands2
import wpilib
import rev
from phoenix6.hardware import TalonFX
from phoenix6.configs import TalonFXConfiguration
from phoenix6.controls import VoltageOut
from phoenix6.signals import InvertedValue, NeutralModeValue

class MotorIO:
    def __init__(self, config):
        self.sign = config['sensorSign']
        self.limit = wpilib.DigitalInput(config['limit']) if config['limit'] >= 0 else None
        self.spark = config['type'] != 'TalonFX'
        self.configured = False
        if self.spark:
            self.motor = (rev.SparkFlex if config['type'] == 'SparkFlex' else rev.SparkMax)(config['can'], rev.SparkLowLevel.MotorType.kBrushless)
            settings = rev.SparkFlexConfig() if config['type'] == 'SparkFlex' else rev.SparkMaxConfig()
            settings.inverted(config['inverted']).setIdleMode(rev.SparkBaseConfig.IdleMode.kBrake).smartCurrentLimit(config['current'])
            for _ in range(3):
                self.configured = self.motor.configure(settings, rev.ResetMode.kResetSafeParameters, rev.PersistMode.kPersistParameters) == rev.REVLibError.kOk
                if self.configured:
                    break
            self.encoder = self.motor.getEncoder()
        else:
            self.motor = TalonFX(config['can'])
            settings = TalonFXConfiguration()
            settings.motor_output.inverted = InvertedValue.CLOCKWISE_POSITIVE if config['inverted'] else InvertedValue.COUNTER_CLOCKWISE_POSITIVE
            settings.motor_output.neutral_mode = NeutralModeValue.BRAKE
            settings.current_limits.stator_current_limit_enable = True
            settings.current_limits.stator_current_limit = config['current']
            for _ in range(3):
                self.configured = self.motor.configurator.apply(settings).is_ok()
                if self.configured:
                    break
        if not self.configured:
            wpilib.reportError('Motor configuration failed, output inhibited: CAN ' + str(config['can']))

    def position(self):
        return self.sign * (self.encoder.getPosition() if self.spark else self.motor.get_position().value_as_double)

    def velocity(self):
        return self.sign * (self.encoder.getVelocity() / 60.0 if self.spark else self.motor.get_velocity().value_as_double)

    def voltage(self, volts):
        if not self.configured or not wpilib.DriverStation.isEnabled() or not math.isfinite(volts):
            volts = 0.0
        if self.limit is not None and not self.limit.get() and volts > 0:
            volts = 0.0
        volts = max(-12.0, min(12.0, volts))
        if self.spark:
            self.motor.setVoltage(volts)
        else:
            self.motor.set_control(VoltageOut(volts))

    def stop(self):
        self.voltage(0)

class Mechanism(commands2.Subsystem):
    def __init__(self, name, motors):
        super().__init__()
        self.setName(name)
        self.motors = motors
        self.last = 0.0

    def set(self, output):
        self.last = wpilib.Timer.getFPGATimestamp()
        for motor in self.motors:
            motor.voltage(output * 12.0)

    def stop(self):
        for motor in self.motors:
            motor.stop()

    def action(self, output, timeout):
        return self.runEnd(lambda: self.set(output), self.stop).withTimeout(timeout)

    def periodic(self):
        if wpilib.DriverStation.isDisabled() or wpilib.Timer.getFPGATimestamp() - self.last > 0.1:
            self.stop()
`,
		"drive.py": `import math
import commands2
import wpilib
from wpimath.kinematics import DifferentialDriveKinematics, DifferentialDriveOdometry, DifferentialDriveWheelSpeeds
from wpimath.controller import PIDController
from phoenix6.hardware import Pigeon2
from pathplannerlib.auto import AutoBuilder
from pathplannerlib.config import RobotConfig
from pathplannerlib.controller import PPLTVController
from hardware import MotorIO
from config import CONFIG

class Drive(commands2.Subsystem):
    def __init__(self):
        super().__init__()
        self.d = CONFIG['drive']
        self.left = [MotorIO(m) for m in CONFIG['motors'] if m['role'] == 'left']
        self.right = [MotorIO(m) for m in CONFIG['motors'] if m['role'] == 'right']
        self.gyro = Pigeon2(self.d['gyroCan']) if self.d['gyro'] == 'Pigeon2' else wpilib.ADXRS450_Gyro()
        if self.d['gyro'] == 'ADXRS450' and wpilib.RobotBase.isReal():
            self.gyro.calibrate()
        self.meters_per_rotation = math.pi * self.d['wheelDiameter'] / self.d['gearing']
        self.kinematics = DifferentialDriveKinematics(self.d['trackWidth'])
        self.odometry = DifferentialDriveOdometry(self.heading(), self.distance(self.left), self.distance(self.right))
        self.left_pid = PIDController(self.d['kP'], 0, 0)
        self.right_pid = PIDController(self.d['kP'], 0, 0)
        self.field = wpilib.Field2d()
        self.last = 0.0
        self.auto_ready = False
        wpilib.SmartDashboard.putData('Robot pose', self.field)
        try:
            AutoBuilder.configure(self.pose, self.reset_pose, self.speeds, lambda speeds, ff: self.drive_speeds(speeds), PPLTVController(0.02), RobotConfig.fromGUISettings(), lambda: wpilib.DriverStation.getAlliance() == wpilib.DriverStation.Alliance.kRed, self)
            self.auto_ready = True
        except Exception as error:
            wpilib.reportError('Autonomous configuration failed: ' + str(error))

    def heading(self):
        return self.gyro.getRotation2d() if self.d['gyro'] == 'ADXRS450' else self.gyro.getRotation2d()

    def distance(self, motors):
        return sum(m.position() for m in motors) / max(1, len(motors)) * self.meters_per_rotation

    def velocity(self, motors):
        return sum(m.velocity() for m in motors) / max(1, len(motors)) * self.meters_per_rotation

    def pose(self):
        return self.odometry.getPose()

    def reset_pose(self, pose):
        self.odometry.resetPosition(self.heading(), self.distance(self.left), self.distance(self.right), pose)
        self.left_pid.reset()
        self.right_pid.reset()

    def speeds(self):
        return self.kinematics.toChassisSpeeds(DifferentialDriveWheelSpeeds(self.velocity(self.left), self.velocity(self.right)))

    def voltage(self, left, right):
        self.last = wpilib.Timer.getFPGATimestamp()
        if not all(m.configured for m in self.left + self.right):
            left = right = 0.0
        for motor in self.left:
            motor.voltage(left)
        for motor in self.right:
            motor.voltage(right)

    def stop(self):
        self.voltage(0, 0)
        self.left_pid.reset()
        self.right_pid.reset()

    def arcade(self, forward, turn):
        if not wpilib.DriverStation.isTeleopEnabled():
            self.stop()
            return
        left, right = forward - turn, forward + turn
        scale = max(1, abs(left), abs(right))
        cap = CONFIG['controls']['maxOutput'] * 12
        self.voltage(left / scale * cap, right / scale * cap)

    def feedforward(self, speed):
        return 0 if abs(speed) < 0.001 else math.copysign(self.d['kS'], speed) + self.d['kV'] * speed

    def drive_speeds(self, speeds):
        wheels = self.kinematics.toWheelSpeeds(speeds)
        wheels.desaturate(self.d['maxSpeed'])
        self.voltage(self.feedforward(wheels.left) + self.left_pid.calculate(self.velocity(self.left), wheels.left), self.feedforward(wheels.right) + self.right_pid.calculate(self.velocity(self.right), wheels.right))

    def periodic(self):
        if wpilib.DriverStation.isDisabled() or wpilib.Timer.getFPGATimestamp() - self.last > 0.1:
            self.stop()
        self.odometry.update(self.heading(), self.distance(self.left), self.distance(self.right))
        self.field.setRobotPose(self.pose())
        wpilib.SmartDashboard.putNumber('Drive/left meters', self.distance(self.left))
        wpilib.SmartDashboard.putNumber('Drive/right meters', self.distance(self.right))
        wpilib.SmartDashboard.putBoolean('Drive/auto configured', self.auto_ready)
`,
		"pyproject.toml": `[tool.robotpy]\nrobotpy_version = "${versions.robotpy}"\ncomponents = ["commands2"]\nrequires = ["robotpy-rev==${versions.robotpyRev}", "phoenix6==${versions.phoenix}", "robotpy-pathplannerlib==${versions.pathplanner}"]\n`
	};
}
//#endregion
//#region lib/gen-cpp.ts
const q = JSON.stringify;
function cppSources(p) {
	const d = p.drive, c = p.controls;
	const motor = (m) => `std::make_shared<MotorIO>(${q(m.type)},${m.can},${m.inverted},${m.sensorSign},${m.current},${m.limit})`;
	const side = (role) => p.motors.filter((m) => m.role === role).map(motor).join(",");
	const mechanisms = p.subsystems.filter((s) => s.id !== "drive");
	return { "src/main/cpp/Robot.cpp": `#include <algorithm>
#include <cmath>
#include <memory>
#include <optional>
#include <string>
#include <vector>
#include <frc/TimedRobot.h>
#include <frc/RobotBase.h>
#include <frc/DriverStation.h>
#include <frc/Errors.h>
#include <frc/Timer.h>
#include <frc/DataLogManager.h>
#include <frc/GenericHID.h>
#include <frc/DigitalInput.h>
#include <frc/ADXRS450_Gyro.h>
#include <frc/geometry/Pose2d.h>
#include <frc/kinematics/DifferentialDriveKinematics.h>
#include <frc/kinematics/DifferentialDriveOdometry.h>
#include <frc/controller/PIDController.h>
#include <frc/smartdashboard/SmartDashboard.h>
#include <frc/smartdashboard/Field2d.h>
#include <frc/smartdashboard/SendableChooser.h>
#include <frc2/command/SubsystemBase.h>
#include <frc2/command/CommandScheduler.h>
#include <frc2/command/Commands.h>
#include <frc2/command/button/Trigger.h>
#include <rev/SparkMax.h>
#include <rev/SparkFlex.h>
#include <rev/config/SparkMaxConfig.h>
#include <rev/config/SparkFlexConfig.h>
#include <ctre/phoenix6/TalonFX.hpp>
#include <ctre/phoenix6/Pigeon2.hpp>
#include <pathplanner/lib/auto/AutoBuilder.h>
#include <pathplanner/lib/auto/NamedCommands.h>
#include <pathplanner/lib/commands/PathPlannerAuto.h>
#include <pathplanner/lib/config/RobotConfig.h>
#include <pathplanner/lib/controllers/PPLTVController.h>
using namespace units::literals;

class MotorIO {
  std::unique_ptr<rev::spark::SparkBase> spark;
  std::unique_ptr<ctre::phoenix6::hardware::TalonFX> talon;
  std::unique_ptr<frc::DigitalInput> limit;
  double sign;
  bool configured=false;
public:
  MotorIO(std::string kind,int can,bool inverted,double encoderSign,int amps,int dio):sign(encoderSign) {
    if(dio>=0) limit=std::make_unique<frc::DigitalInput>(dio);
    if(kind=="TalonFX") {
      talon=std::make_unique<ctre::phoenix6::hardware::TalonFX>(can);
      ctre::phoenix6::configs::TalonFXConfiguration config;
      config.MotorOutput.Inverted=inverted?ctre::phoenix6::signals::InvertedValue::Clockwise_Positive:ctre::phoenix6::signals::InvertedValue::CounterClockwise_Positive;
      config.MotorOutput.NeutralMode=ctre::phoenix6::signals::NeutralModeValue::Brake;
      config.CurrentLimits.StatorCurrentLimitEnable=true;
      config.CurrentLimits.StatorCurrentLimit=units::ampere_t{static_cast<double>(amps)};
      for(int i=0;i<3&&!configured;i++) configured=talon->GetConfigurator().Apply(config).IsOK();
    } else {
      if(kind=="SparkFlex") {
        spark=std::make_unique<rev::spark::SparkFlex>(can,rev::spark::SparkLowLevel::MotorType::kBrushless);
        rev::spark::SparkFlexConfig config;config.Inverted(inverted).SetIdleMode(rev::spark::SparkBaseConfig::IdleMode::kBrake).SmartCurrentLimit(amps);
        for(int i=0;i<3&&!configured;i++) configured=spark->Configure(config,rev::ResetMode::kResetSafeParameters,rev::PersistMode::kPersistParameters)==rev::REVLibError::kOk;
      } else {
        spark=std::make_unique<rev::spark::SparkMax>(can,rev::spark::SparkLowLevel::MotorType::kBrushless);
        rev::spark::SparkMaxConfig config;config.Inverted(inverted).SetIdleMode(rev::spark::SparkBaseConfig::IdleMode::kBrake).SmartCurrentLimit(amps);
        for(int i=0;i<3&&!configured;i++) configured=spark->Configure(config,rev::ResetMode::kResetSafeParameters,rev::PersistMode::kPersistParameters)==rev::REVLibError::kOk;
      }
    }
    if(!configured) FRC_ReportError(frc::err::Error, "{}", "Motor configuration failed; output inhibited at CAN "+std::to_string(can));
  }
  bool Ready() { return configured; }
  double Position() { return sign*(spark?spark->GetEncoder().GetPosition():talon->GetPosition().GetValueAsDouble()); }
  double Velocity() { return sign*(spark?spark->GetEncoder().GetVelocity()/60.0:talon->GetVelocity().GetValueAsDouble()); }
  void Voltage(double value) {
    if(!configured||!frc::DriverStation::IsEnabled()||!std::isfinite(value))value=0;
    if(limit&&!limit->Get()&&value>0)value=0;
    auto volts=units::volt_t{std::clamp(value,-12.0,12.0)};
    if(spark)spark->SetVoltage(volts);else talon->SetVoltage(volts);
  }
  void Stop(){Voltage(0);}
};
using Motors=std::vector<std::shared_ptr<MotorIO>>;
class Mechanism:public frc2::SubsystemBase {
  Motors motors; double last=0;
public:
  Mechanism(std::string name,Motors configured):motors(std::move(configured)){SetName(name);}
  void Set(double output){last=frc::Timer::GetFPGATimestamp().value();for(auto&m:motors)m->Voltage(output*12);}
  void Stop(){for(auto&m:motors)m->Stop();}
  frc2::CommandPtr Action(double output,double timeout){return RunEnd([this,output]{Set(output);},[this]{Stop();}).WithTimeout(units::second_t{timeout});}
  void Periodic() override {if(frc::DriverStation::IsDisabled()||frc::Timer::GetFPGATimestamp().value()-last>0.1)Stop();}
};
class Drive:public frc2::SubsystemBase {
  Motors left{${side("left")}},right{${side("right")}};
  ${d.gyro === "Pigeon2" ? `ctre::phoenix6::hardware::Pigeon2 gyro{${d.gyroCan}};` : "frc::ADXRS450_Gyro gyro;"}
  double conversion=3.141592653589793*${d.wheelDiameter}/${d.gearing};
  frc::DifferentialDriveKinematics kinematics{units::meter_t{${d.trackWidth}}};
  frc::DifferentialDriveOdometry odometry{gyro.GetRotation2d(),units::meter_t{Distance(left)},units::meter_t{Distance(right)}};
  frc::PIDController leftPID{${d.kP},0,0},rightPID{${d.kP},0,0};
  frc::Field2d field;double last=0;
  double Distance(const Motors& motors){double sum=0;for(auto&m:motors)sum+=m->Position();return motors.empty()?0:sum/motors.size()*conversion;}
  double Velocity(const Motors& motors){double sum=0;for(auto&m:motors)sum+=m->Velocity();return motors.empty()?0:sum/motors.size()*conversion;}
  void Voltage(double l,double r){last=frc::Timer::GetFPGATimestamp().value();for(auto&m:left)if(!m->Ready())l=r=0;for(auto&m:right)if(!m->Ready())l=r=0;for(auto&m:left)m->Voltage(l);for(auto&m:right)m->Voltage(r);}
  double FF(double v){return std::abs(v)<0.001?0:std::copysign(${d.kS},v)+${d.kV}*v;}
public:
  bool autoReady=false;
  Drive(){
    ${d.gyro === "ADXRS450" ? "gyro.Calibrate();" : ""}
    frc::SmartDashboard::PutData("Robot pose",&field);
    try {pathplanner::AutoBuilder::configure([this]{return Pose();},[this](frc::Pose2d pose){ResetPose(pose);},[this]{return Speeds();},[this](auto speeds,auto feedforwards){DriveSpeeds(speeds);},std::make_shared<pathplanner::PPLTVController>(0.02_s),pathplanner::RobotConfig::fromGUISettings(),[]{return frc::DriverStation::GetAlliance()==frc::DriverStation::Alliance::kRed;},this);autoReady=true;}
    catch(const std::exception&e){FRC_ReportError(frc::err::Error, "{}", std::string("Autonomous configuration failed: ")+e.what());}
  }
  frc::Pose2d Pose(){return odometry.GetPose();}
  void ResetPose(frc::Pose2d pose){odometry.ResetPosition(gyro.GetRotation2d(),units::meter_t{Distance(left)},units::meter_t{Distance(right)},pose);leftPID.Reset();rightPID.Reset();}
  frc::ChassisSpeeds Speeds(){return kinematics.ToChassisSpeeds({units::meters_per_second_t{Velocity(left)},units::meters_per_second_t{Velocity(right)}});}
  void Stop(){Voltage(0,0);leftPID.Reset();rightPID.Reset();}
  void Arcade(double forward,double turn){if(!frc::DriverStation::IsTeleopEnabled()){Stop();return;}double l=forward-turn,r=forward+turn,scale=std::max({1.0,std::abs(l),std::abs(r)});Voltage(l/scale*12*${c.maxOutput},r/scale*12*${c.maxOutput});}
  void DriveSpeeds(frc::ChassisSpeeds speeds){auto wheels=kinematics.ToWheelSpeeds(speeds);wheels.Desaturate(units::meters_per_second_t{${d.maxSpeed}});Voltage(FF(wheels.left.value())+leftPID.Calculate(Velocity(left),wheels.left.value()),FF(wheels.right.value())+rightPID.Calculate(Velocity(right),wheels.right.value()));}
  void Periodic() override {if(frc::DriverStation::IsDisabled()||frc::Timer::GetFPGATimestamp().value()-last>0.1)Stop();odometry.Update(gyro.GetRotation2d(),units::meter_t{Distance(left)},units::meter_t{Distance(right)});field.SetRobotPose(Pose());frc::SmartDashboard::PutNumber("Drive/left meters",Distance(left));frc::SmartDashboard::PutNumber("Drive/right meters",Distance(right));frc::SmartDashboard::PutBoolean("Drive/auto configured",autoReady);}
};
class Robot:public frc::TimedRobot {
  Drive drive;
  frc::GenericHID driver{${c.driverPort}},operatorController{${c.operatorPort}};
  ${mechanisms.map((s) => `Mechanism mechanism_${s.id}{${q(s.name)},Motors{${p.motors.filter((m) => m.subsystem === s.id).map(motor).join(",")}}};`).join("\n  ")}
  frc::SendableChooser<frc2::Command*> chooser;
  frc2::CommandPtr none=frc2::cmd::None();
  std::optional<frc2::CommandPtr> autoCommand;
  frc2::Command* selected=nullptr;
  double Deadband(double value){return std::abs(value)<=${c.deadband}?0:std::copysign((std::abs(value)-${c.deadband})/(1-${c.deadband}),value);}
  ${p.commands.map((x) => `frc2::CommandPtr Action_${x.id}(){return mechanism_${x.subsystem}.Action(${x.output},${x.timeout}).WithName(${q(x.name)});}`).join("\n  ")}
  void StopAll(){drive.Stop();${mechanisms.map((s) => `mechanism_${s.id}.Stop();`).join("")}}
public:
  void RobotInit() override {
    frc::DataLogManager::Start();frc::DriverStation::StartDataLog(frc::DataLogManager::GetLog());
    drive.SetDefaultCommand(drive.RunEnd([this]{drive.Arcade(${c.forwardSign}*Deadband(driver.GetRawAxis(${c.forwardAxis})),${c.turnSign}*Deadband(driver.GetRawAxis(${c.turnAxis})));},[this]{drive.Stop();}));
    ${p.commands.map((x) => `pathplanner::NamedCommands::registerCommand(${q(x.id)},Action_${x.id}());`).join("\n    ")}
    ${p.bindings.map((b) => `frc2::Trigger([this]{return frc::DriverStation::IsTeleopEnabled()&&${b.controller === "driver" ? "driver" : "operatorController"}.GetRawButton(${b.button});}).${b.behavior === "whileHeld" ? "WhileTrue" : b.behavior === "onPress" ? "OnTrue" : "ToggleOnTrue"}(Action_${b.command}());`).join("\n    ")}
    chooser.SetDefaultOption("Do nothing",none.get());
    if(drive.autoReady)try{autoCommand.emplace(pathplanner::PathPlannerAuto(${q(p.auto.name)}).ToPtr().WithTimeout(15_s).FinallyDo([this](bool){StopAll();}));chooser.AddOption(${q(p.auto.name)},autoCommand->get());}catch(const std::exception&e){FRC_ReportError(frc::err::Error, "{}", std::string("Auto failed to load: ")+e.what());}
    frc::SmartDashboard::PutData("Auto chooser",&chooser);
  }
  void RobotPeriodic() override {frc2::CommandScheduler::GetInstance().Run();}
  void AutonomousInit() override {StopAll();selected=chooser.GetSelected();if(selected)frc2::CommandScheduler::GetInstance().Schedule(selected);}
  void TeleopInit() override {if(selected)selected->Cancel();StopAll();}
  void DisabledInit() override {frc2::CommandScheduler::GetInstance().CancelAll();StopAll();}
  void TestInit() override {frc2::CommandScheduler::GetInstance().CancelAll();StopAll();}
};
#ifndef RUNNING_FRC_TESTS
int main(){return frc::StartRobot<Robot>();}
#endif
` };
}
//#endregion
//#region lib/generator.ts
function bezierWaypoints(points) {
	return points.map((anchor, i) => {
		const before = points[Math.max(0, i - 1)], after = points[Math.min(points.length - 1, i + 1)];
		const dx = (after.x - before.x) / 6, dy = (after.y - before.y) / 6;
		return {
			anchor,
			prevControl: i ? {
				x: anchor.x - dx,
				y: anchor.y - dy
			} : null,
			nextControl: i < points.length - 1 ? {
				x: anchor.x + dx,
				y: anchor.y + dy
			} : null,
			isLocked: false,
			linkedName: null
		};
	});
}
function pathFiles(p) {
	const a = p.auto, d = p.drive, w = a.waypoints;
	const heading = Math.atan2(w[1].y - w[0].y, w[1].x - w[0].x) * 180 / Math.PI;
	const path = {
		version: "2025.0",
		waypoints: bezierWaypoints(w),
		rotationTargets: [],
		constraintZones: [],
		pointTowardsZones: [],
		eventMarkers: [],
		globalConstraints: {
			maxVelocity: a.maxSpeed,
			maxAcceleration: a.maxAcceleration,
			maxAngularVelocity: 360,
			maxAngularAcceleration: 540,
			nominalVoltage: 12,
			unlimited: false
		},
		goalEndState: {
			velocity: 0,
			rotation: 0
		},
		reversed: false,
		folder: null,
		idealStartingState: {
			velocity: 0,
			rotation: heading
		},
		useDefaultConstraints: false
	};
	const settings = {
		robotWidth: d.trackWidth + .2,
		robotLength: .9,
		holonomicMode: false,
		pathFolders: [],
		autoFolders: [],
		defaultMaxVel: a.maxSpeed,
		defaultMaxAccel: a.maxAcceleration,
		defaultMaxAngVel: 360,
		defaultMaxAngAccel: 540,
		defaultNominalVoltage: 12,
		robotMass: d.mass,
		robotMOI: d.moi,
		robotTrackwidth: d.trackWidth,
		driveWheelRadius: d.wheelDiameter / 2,
		driveGearing: d.gearing,
		maxDriveSpeed: d.maxSpeed,
		driveMotorType: p.motors.find((m) => m.role === "left")?.type === "TalonFX" ? "krakenX60" : p.motors.find((m) => m.role === "left")?.type === "SparkFlex" ? "vortex" : "NEO",
		driveCurrentLimit: Math.min(...p.motors.filter((m) => m.subsystem === "drive").map((m) => m.current)),
		wheelCOF: 1.2
	};
	const auto = {
		version: "2025.0",
		command: {
			type: "sequential",
			data: { commands: a.steps.map((s) => s.type === "path" ? {
				type: "path",
				data: { pathName: a.name }
			} : s.type === "command" ? {
				type: "named",
				data: { name: s.command }
			} : {
				type: "wait",
				data: { waitTime: s.seconds }
			}) }
		},
		resetOdom: true,
		folder: null,
		choreoAuto: false
	};
	return Object.fromEntries([
		[`paths/${a.name}.path`, path],
		[`autos/${a.name}.auto`, auto],
		["settings.json", settings]
	].map(([name, data]) => ["pathplanner/" + name, JSON.stringify(data, null, 2)]));
}
function generateSources(p) {
	try {
		return p.language === "Java" ? javaSources(p) : p.language === "Python" ? pythonSources(p) : cppSources(p);
	} catch {
		return { "Configuration.txt": "Resolve invalid configuration values in Preflight to preview generated source." };
	}
}
function readme(p) {
	return `# Team ${p.team}: ${p.name}\n\nGenerated by RobotForge for the 2026 FRC season.\n\n## Scope\nDifferential drive with encoder odometry, ADXRS450 or Pigeon 2 heading, open-loop mechanism commands, active-low forward DIO limits, command timeouts, driver mappings, and PathPlanner autonomous. This is generated source, not a certification of competition readiness. Swerve, vision fusion, advanced closed-loop mechanisms, and a drivetrain physics simulation are not included.\n\n## Build and run\n${p.language === "Python" ? `Install Python 3.12 and RobotPy ${versions.robotpy}. In this directory run:\n\n    python -m pip install robotpy==${versions.robotpy}\n    python -m robotpy sync\n    python -m robotpy sim\n    python -m robotpy deploy --team ${p.team}\n\nRobotPy deploys the deploy/ directory with the project.` : `Install the WPILib ${versions.wpilib} development environment and 2026 roboRIO toolchain. Open this folder in WPILib VS Code.\n\n    ${p.language === "Java" ? "./gradlew build" : "./gradlew build"}\n    ./gradlew simulate${p.language === "Java" ? "Java" : "Native"}\n    ./gradlew deploy\n\nOn Windows use gradlew.bat. On macOS/Linux, chmod +x gradlew if needed. The Gradle wrapper is included. Vendor metadata is pinned in vendordeps/.`}\n\n## Hardware assumptions\nSPARK MAX = brushless NEO; SPARK Flex = NEO Vortex; Talon FX = Kraken X60. All devices use the roboRIO CAN bus. The motor output inversion and encoder sign are independent; verify each so forward motion increases both side distances. Encoders are integrated motor-shaft encoders. Reduction is motor revolutions per wheel revolution. The ADXRS450 uses onboard SPI and must remain still while calibrating. Pigeon 2 must be mounted with its documented axes and positive counterclockwise heading.\n\n## Commission in order\n1. Verify all CAN IDs, firmware, wiring, current limits and DIO channels.\n2. Support the robot and start with the ${p.controls.maxOutput} teleop output cap. Verify motor directions, controller axes and encoder signs.\n3. Test disable, command timeout, release, interruption, limit switches and disconnect behavior.\n4. Measure wheel diameter, gear ratio, track width, mass, MOI and friction. Tune kS/kV/kP from measurements.\n5. Open deploy/pathplanner (Python) or src/main/deploy/pathplanner in PathPlanner 2026. Choose the correct game field. Confirm dimensions, blue-origin convention, alliance transforms, all path clearance and constraints. The canvas is a generic grid; no collision detection was performed.\n6. Build and simulate command flow. The included simulated sensor feedback is not a physical drivetrain model. Test all paths at reduced speed on the real robot.\n7. Select the autonomous routine in SmartDashboard/Elastic. Default is Do nothing. The generated routine is bounded to 15 seconds and all outputs stop on interruption and mode transitions.\n\nMechanism commands intentionally control duty cycle. An elevator, arm or precision shooter requires mentor-authored closed-loop control, sensor integration and appropriate bidirectional limits before use. A timed command does not establish a physical mechanism position.\n\n## Generated architecture\nMotorIO encapsulates vendor APIs; Drive owns all drive motors, gyro, odometry and velocity control. Each Mechanism owns its motors. Commands require their subsystem and always stop it on end. Dashboard exports robot pose, drive distances and readiness. A 100 ms output freshness watchdog and disabled checks stop stale outputs. Failed startup motor configuration inhibits output for that device.\n\n## Dependencies checked ${versions.checked}\nWPILib ${versions.wpilib}; RobotPy ${versions.robotpy}; REVLib ${p.language === "Python" ? versions.robotpyRev : versions.rev}; Phoenix 6 ${versions.phoenix}; PathPlannerLib ${versions.pathplanner}. Versions are deliberately pinned; review release notes and rebuild before upgrading.\n\nOfficial references: https://docs.wpilib.org/ ; https://pathplanner.dev/ ; https://docs.revrobotics.com/ ; https://v6.docs.ctr-electronics.com/\n\nrobotforge-project.json is the editable configuration backup. Import it into RobotForge to continue. Regeneration replaces generated source; retain custom robot edits separately in version control.\n`;
}
async function assembleProject(p, asset) {
	const errors = validate(p).filter((i) => i.level === "error");
	if (errors.length) throw Error(errors.map((i) => i.message).join("\n"));
	const files = {
		...generateSources(p),
		"README.md": readme(p),
		"robotforge-project.json": JSON.stringify(p, null, 2),
		".gitignore": ".gradle/\nbuild/\n__pycache__/\n.venv/\n"
	};
	const deploy = p.language === "Python" ? "deploy/" : "src/main/deploy/";
	for (const [name, data] of Object.entries(pathFiles(p))) files[deploy + name] = data;
	if (p.language !== "Python") {
		const text = new TextDecoder();
		const template = await asset("/templates/" + (p.language === "Java" ? "java" : "cpp") + ".gradle");
		files["build.gradle"] = text.decode(template).replaceAll("###GRADLERIOREPLACE###", versions.wpilib).replaceAll("###ROBOTCLASSREPLACE###", "frc.robot.Main").replaceAll("includeDesktopSupport = false", "includeDesktopSupport = true").replaceAll("deleteOldFiles = false", "deleteOldFiles = true");
		files["settings.gradle"] = `pluginManagement { repositories { mavenLocal(); gradlePluginPortal(); maven { url 'https://frcmaven.wpi.edu/artifactory/release/' } } }\nrootProject.name = 'RobotForgeRobot'\n`;
		files[".wpilib/wpilib_preferences.json"] = JSON.stringify({
			enableCppIntellisense: p.language === "C++",
			currentLanguage: p.language.toLowerCase() === "c++" ? "cpp" : "java",
			projectYear: "2026",
			teamNumber: p.team
		}, null, 2);
		const vendors = [
			"WPILibNewCommands",
			"PathplannerLib",
			"REVLib",
			"Phoenix6"
		];
		await Promise.all([...[
			"gradlew",
			"gradlew.bat",
			"gradle/wrapper/gradle-wrapper.jar",
			"gradle/wrapper/gradle-wrapper.properties"
		].map(async (f) => {
			files[f] = await asset("/templates/" + f);
		}), ...vendors.map(async (f) => {
			files["vendordeps/" + f + ".json"] = await asset("/vendor/" + f + ".json");
		})]);
	}
	return files;
}
//#endregion
//#region companion/server.mjs
const PORT = 5819;
const SITE = "https://robot-forge-frc.paul-seed121071.chatgpt.site";
const digest = (value) => createHash("sha256").update(value).digest("hex");
const fail = (message, status = 400) => {
	throw Object.assign(new Error(message), { status });
};
const targetFor = (team, connection) => connection === "usb" ? "172.22.11.2" : `roborio-${team}-FRC.local`;
function runProcess(command, args, { cwd, log, signal }) {
	return new Promise((resolve, reject) => {
		const child = spawn(command, args, {
			cwd,
			shell: false,
			windowsHide: true,
			detached: process.platform !== "win32",
			stdio: [
				"ignore",
				"pipe",
				"pipe"
			],
			env: {
				...process.env,
				PYTHONUNBUFFERED: "1",
				PIP_DISABLE_PIP_VERSION_CHECK: "1"
			}
		});
		let stopped = false;
		const stop = () => {
			stopped = true;
			if (!child.pid) return;
			if (process.platform === "win32") spawn("taskkill.exe", [
				"/pid",
				String(child.pid),
				"/T",
				"/F"
			], {
				windowsHide: true,
				stdio: "ignore"
			});
			else try {
				process.kill(-child.pid, "SIGKILL");
			} catch {}
		};
		signal?.addEventListener("abort", stop, { once: true });
		if (signal?.aborted) stop();
		child.stdout.on("data", (data) => log(data.toString()));
		child.stderr.on("data", (data) => log(data.toString()));
		child.once("error", (error) => {
			signal?.removeEventListener("abort", stop);
			reject(/* @__PURE__ */ new Error(`Could not start ${path.basename(command)}. Check the companion setup guide. ${error.message}`));
		});
		child.once("close", (code) => {
			signal?.removeEventListener("abort", stop);
			if (stopped) reject(/* @__PURE__ */ new Error("Build cancelled."));
			else if (code === 0) resolve();
			else reject(/* @__PURE__ */ new Error(`${path.basename(command)} exited with code ${code}. Read the build log above.`));
		});
	});
}
async function findJava() {
	const roots = [
		process.env.ROBOTFORGE_JAVA_HOME,
		process.env.WPILIB_JAVA_HOME,
		path.join(process.env.PUBLIC || "C:/Users/Public", "wpilib/2026/jdk"),
		path.join(os.homedir(), "wpilib/2026/jdk"),
		process.env.JAVA_HOME
	];
	for (const root of roots.filter(Boolean)) {
		const file = path.join(root, "bin", process.platform === "win32" ? "java.exe" : "java");
		try {
			await fs.access(file);
			return file;
		} catch {}
	}
	return "java";
}
function createCompanion({ assets, root = path.join(os.homedir(), ".robotforge"), run = runProcess, token = randomBytes(24).toString("hex"), origins = [SITE], port = PORT }) {
	const allowed = new Set(origins);
	let job = null, busy = false, lastStart = 0;
	const log = (value) => {
		if (job) job.log = (job.log + value.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, "")).slice(-8e4);
	};
	const publicJob = () => job ? {
		id: job.id,
		state: job.state,
		team: job.project.team,
		language: job.project.language,
		target: job.target,
		connection: job.connection,
		offline: job.offline,
		fingerprint: job.fingerprint,
		startedAt: job.startedAt,
		log: job.log,
		error: job.error || null
	} : null;
	const fingerprint = (project, connection, offline) => digest(JSON.stringify({
		project,
		connection,
		offline
	}));
	async function execute(stage) {
		const current = job;
		const controller = new AbortController();
		current.controller = controller;
		const timer = setTimeout(() => controller.abort(), 1200 * 1e3);
		const invoke = async (command, args, cwd = current.directory) => {
			if (controller.signal.aborted) throw Error("Build cancelled or timed out.");
			log(`\n> ${path.basename(command)} ${args.join(" ")}\n`);
			await run(command, args, {
				cwd,
				log,
				signal: controller.signal
			});
		};
		try {
			if (stage === "build") {
				await fs.mkdir(current.directory, { recursive: true });
				const files = await assembleProject(current.project, async (name) => {
					if (!(name in assets)) throw Error(`Missing bundled template ${name}`);
					return Buffer.from(assets[name], "base64");
				});
				if (files["build.gradle"]) files["build.gradle"] += `\n// Deploy only to the address reviewed in RobotForge.\ndeploy.targets.roborio.locations.clear()\ndeploy.targets.roborio.addAddress('${current.target}')\n${current.project.language === "Java" ? "tasks.register('robotForgePrepare') { doLast { configurations.roborioRelease.resolve() } }" : ""}\n`;
				current.manifest = {};
				for (const [name, contents] of Object.entries(files)) {
					const dest = path.join(current.directory, name);
					await fs.mkdir(path.dirname(dest), { recursive: true });
					await fs.writeFile(dest, contents);
					current.manifest[name] = digest(contents);
				}
			} else for (const [name, hash] of Object.entries(current.manifest)) if (digest(await fs.readFile(path.join(current.directory, name))) !== hash) throw Error("Generated project changed on disk. Build again before deploying.");
			if (current.project.language === "Python") {
				const venv = path.join(root, `python-${versions.robotpy}`);
				const python = path.join(venv, process.platform === "win32" ? "Scripts/python.exe" : "bin/python");
				if (stage === "build") {
					if (!current.offline) {
						await invoke(process.env.ROBOTFORGE_PYTHON || (process.platform === "win32" ? "py" : "python3.12"), [
							...process.platform === "win32" && !process.env.ROBOTFORGE_PYTHON ? ["-3.12"] : [],
							"-m",
							"venv",
							venv
						]);
						await invoke(python, [
							"-m",
							"pip",
							"install",
							`robotpy[commands2]==${versions.robotpy}`,
							`robotpy-rev==${versions.robotpyRev}`,
							`phoenix6==${versions.phoenix}`,
							`robotpy-pathplannerlib==${versions.pathplanner}`
						]);
						await invoke(python, [
							"-m",
							"robotpy",
							"sync",
							"--no-install",
							"--no-upgrade-project"
						]);
					}
					await invoke(python, [
						"-m",
						"compileall",
						"-q",
						"."
					]);
					await invoke(python, [
						"-m",
						"robotpy",
						"test",
						"--builtin"
					]);
				} else await invoke(python, [
					"-m",
					"robotpy",
					"deploy",
					"--builtin",
					"--robot",
					current.target
				]);
			} else {
				const java = await findJava();
				const args = [
					"-classpath",
					"gradle/wrapper/gradle-wrapper.jar",
					"org.gradle.wrapper.GradleWrapperMain",
					...stage === "deploy" ? ["deploy"] : current.project.language === "C++" ? ["frcUserProgramLinuxathenaReleaseExecutable"] : ["build", "robotForgePrepare"],
					"--console=plain",
					"--no-daemon",
					"-Ptoolchain-optional-desktop"
				];
				if (current.offline || stage === "deploy") args.push("--offline");
				await invoke(java, args);
			}
			if (controller.signal.aborted) throw Error("Operation timed out or was cancelled.");
			current.state = stage === "build" ? "ready" : "deployed";
			log(stage === "build" ? "\nBuild passed. Nothing has been sent to the robot. Review and confirm deployment in the app.\n" : "\nDeployment tool reported success. Check Driver Station and robot logs before enabling.\n");
		} catch (error) {
			current.state = controller.signal.aborted ? "cancelled" : "failed";
			current.error = error.message;
			log(`\n${error.message}\n`);
		} finally {
			clearTimeout(timer);
			busy = false;
		}
	}
	async function body(req) {
		if (!req.headers["content-type"]?.startsWith("application/json")) fail("JSON required.", 415);
		let text = "";
		for await (const chunk of req) {
			text += chunk;
			if (Buffer.byteLength(text) > 2e5) fail("Request too large.", 413);
		}
		try {
			return JSON.parse(text);
		} catch {
			fail("Invalid JSON.");
		}
	}
	const server = http.createServer(async (req, res) => {
		const send = (status, data) => {
			res.writeHead(status, {
				"Content-Type": "application/json",
				"Cache-Control": "no-store",
				"X-Content-Type-Options": "nosniff"
			});
			res.end(JSON.stringify(data));
		};
		try {
			if (req.headers.host !== `127.0.0.1:${server.address().port}`) fail("Invalid host.", 403);
			const origin = req.headers.origin;
			if (!allowed.has(origin)) fail("This site is not paired with this companion.", 403);
			res.setHeader("Access-Control-Allow-Origin", origin);
			res.setHeader("Vary", "Origin");
			if (req.method === "OPTIONS") {
				res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
				res.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
				res.setHeader("Access-Control-Allow-Private-Network", "true");
				res.writeHead(204);
				res.end();
				return;
			}
			const supplied = Buffer.from(req.headers.authorization || "");
			const expected = Buffer.from(`Bearer ${token}`);
			if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) fail("Pairing code is incorrect. Copy the code shown by your companion.", 401);
			if (req.method === "GET" && req.url === "/status") return send(200, {
				protocol: 1,
				version: "1.0.0",
				job: publicJob()
			});
			if (req.method !== "POST") fail("Not found.", 404);
			const data = await body(req);
			if (req.url === "/build") {
				if (busy) fail("Another operation is still running.", 409);
				if (Date.now() - lastStart < 1e3) fail("Please wait a moment before starting another build.", 429);
				const parsed = projectSchema.safeParse(data.project);
				if (!parsed.success) fail("Invalid robot configuration. Resolve the project errors first.");
				const project = parsed.data;
				const errors = validate(project).filter((issue) => issue.level === "error");
				if (errors.length) fail(errors.map((issue) => issue.message).join(" "));
				if (!["network", "usb"].includes(data.connection) || typeof data.offline !== "boolean") fail("Choose a valid connection and build mode.");
				const id = randomBytes(12).toString("hex");
				job = {
					id,
					project,
					connection: data.connection,
					offline: data.offline,
					target: targetFor(project.team, data.connection),
					fingerprint: fingerprint(project, data.connection, data.offline),
					state: "building",
					log: "",
					startedAt: (/* @__PURE__ */ new Date()).toISOString(),
					directory: path.join(root, "builds", id)
				};
				busy = true;
				lastStart = Date.now();
				execute("build");
				return send(202, { job: publicJob() });
			}
			if (!job || data.id !== job.id) fail("This build is no longer available. Build again.", 409);
			if (req.url === "/cancel") {
				if (job.state !== "building") fail("Only a build can be cancelled. Do not interrupt a robot upload.", 409);
				job.controller.abort();
				return send(202, { job: publicJob() });
			}
			if (req.url === "/deploy") {
				if (busy || job.state !== "ready") fail("A successful build is required before deployment.", 409);
				const parsed = projectSchema.safeParse(data.project);
				if (!parsed.success || fingerprint(parsed.data, data.connection, data.offline) !== job.fingerprint) fail("Configuration changed. Build again before deploying.", 409);
				if (data.confirmTeam !== String(job.project.team) || data.disabled !== true) fail("Confirm the team number and that the robot is disabled.");
				job.state = "deploying";
				busy = true;
				execute("deploy");
				return send(202, { job: publicJob() });
			}
			fail("Not found.", 404);
		} catch (error) {
			if (!res.headersSent) send(error.status || 500, { error: error.status ? error.message : "Companion error. Check its terminal and try again." });
		}
	});
	server.requestTimeout = 1e4;
	server.headersTimeout = 1e4;
	return {
		server,
		token,
		start: () => new Promise((resolve, reject) => {
			server.once("error", reject);
			server.listen(port, "127.0.0.1", resolve);
		}),
		stop: () => new Promise((resolve) => {
			if (job?.state === "building") job.controller.abort();
			server.close(resolve);
			server.closeIdleConnections();
		})
	};
}
//#endregion
//#region companion/main.mjs
const assets = JSON.parse(await fs.readFile(new URL("./assets.json", import.meta.url), "utf8"));
const origins = [SITE];
if (process.env.ROBOTFORGE_DEV_ORIGIN) {
	const url = new URL(process.env.ROBOTFORGE_DEV_ORIGIN);
	if (url.protocol !== "http:" || !["127.0.0.1", "localhost"].includes(url.hostname)) throw Error("Development origin must be a loopback HTTP URL.");
	origins.push(url.origin);
}
const companion = createCompanion({
	assets,
	origins
});
try {
	await companion.start();
} catch (error) {
	console.error(`Cannot start RobotForge Companion: ${error.message}. Close another running companion and retry.`);
	process.exit(1);
}
console.log(`\nRobotForge Companion 1.0.0\nListening on this computer only: 127.0.0.1:${PORT}\n\nOpen ${SITE}\nCode & export > Deploy to robot\n\nPairing code: ${companion.token}\n\nKeep this window open. The pairing code changes every time you restart.\nBuilds are saved in your home folder under .robotforge/builds.\nDo not close this window while deploying. Press Ctrl+C when finished.\n`);
//#endregion
export {};
