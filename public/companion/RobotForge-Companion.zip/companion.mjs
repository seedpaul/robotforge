import fs from "node:fs/promises";
import http from "node:http";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import path from "node:path";
import os from "node:os";
import { spawn } from "node:child_process";
//#region node_modules/zod/v3/helpers/util.js
var util;
(function(util) {
	util.assertEqual = (_) => {};
	function assertIs(_arg) {}
	util.assertIs = assertIs;
	function assertNever(_x) {
		throw new Error();
	}
	util.assertNever = assertNever;
	util.arrayToEnum = (items) => {
		const obj = {};
		for (const item of items) obj[item] = item;
		return obj;
	};
	util.getValidEnumValues = (obj) => {
		const validKeys = util.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
		const filtered = {};
		for (const k of validKeys) filtered[k] = obj[k];
		return util.objectValues(filtered);
	};
	util.objectValues = (obj) => {
		return util.objectKeys(obj).map(function(e) {
			return obj[e];
		});
	};
	util.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
		const keys = [];
		for (const key in object) if (Object.prototype.hasOwnProperty.call(object, key)) keys.push(key);
		return keys;
	};
	util.find = (arr, checker) => {
		for (const item of arr) if (checker(item)) return item;
	};
	util.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
	function joinValues(array, separator = " | ") {
		return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
	}
	util.joinValues = joinValues;
	util.jsonStringifyReplacer = (_, value) => {
		if (typeof value === "bigint") return value.toString();
		return value;
	};
})(util || (util = {}));
var objectUtil;
(function(objectUtil) {
	objectUtil.mergeShapes = (first, second) => {
		return {
			...first,
			...second
		};
	};
})(objectUtil || (objectUtil = {}));
const ZodParsedType = util.arrayToEnum([
	"string",
	"nan",
	"number",
	"integer",
	"float",
	"boolean",
	"date",
	"bigint",
	"symbol",
	"function",
	"undefined",
	"null",
	"array",
	"object",
	"unknown",
	"promise",
	"void",
	"never",
	"map",
	"set"
]);
const getParsedType = (data) => {
	switch (typeof data) {
		case "undefined": return ZodParsedType.undefined;
		case "string": return ZodParsedType.string;
		case "number": return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
		case "boolean": return ZodParsedType.boolean;
		case "function": return ZodParsedType.function;
		case "bigint": return ZodParsedType.bigint;
		case "symbol": return ZodParsedType.symbol;
		case "object":
			if (Array.isArray(data)) return ZodParsedType.array;
			if (data === null) return ZodParsedType.null;
			if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") return ZodParsedType.promise;
			if (typeof Map !== "undefined" && data instanceof Map) return ZodParsedType.map;
			if (typeof Set !== "undefined" && data instanceof Set) return ZodParsedType.set;
			if (typeof Date !== "undefined" && data instanceof Date) return ZodParsedType.date;
			return ZodParsedType.object;
		default: return ZodParsedType.unknown;
	}
};
//#endregion
//#region node_modules/zod/v3/ZodError.js
const ZodIssueCode = util.arrayToEnum([
	"invalid_type",
	"invalid_literal",
	"custom",
	"invalid_union",
	"invalid_union_discriminator",
	"invalid_enum_value",
	"unrecognized_keys",
	"invalid_arguments",
	"invalid_return_type",
	"invalid_date",
	"invalid_string",
	"too_small",
	"too_big",
	"invalid_intersection_types",
	"not_multiple_of",
	"not_finite"
]);
var ZodError = class ZodError extends Error {
	get errors() {
		return this.issues;
	}
	constructor(issues) {
		super();
		this.issues = [];
		this.addIssue = (sub) => {
			this.issues = [...this.issues, sub];
		};
		this.addIssues = (subs = []) => {
			this.issues = [...this.issues, ...subs];
		};
		const actualProto = new.target.prototype;
		if (Object.setPrototypeOf) Object.setPrototypeOf(this, actualProto);
		else this.__proto__ = actualProto;
		this.name = "ZodError";
		this.issues = issues;
	}
	format(_mapper) {
		const mapper = _mapper || function(issue) {
			return issue.message;
		};
		const fieldErrors = { _errors: [] };
		const processError = (error) => {
			for (const issue of error.issues) if (issue.code === "invalid_union") issue.unionErrors.map(processError);
			else if (issue.code === "invalid_return_type") processError(issue.returnTypeError);
			else if (issue.code === "invalid_arguments") processError(issue.argumentsError);
			else if (issue.path.length === 0) fieldErrors._errors.push(mapper(issue));
			else {
				let curr = fieldErrors;
				let i = 0;
				while (i < issue.path.length) {
					const el = issue.path[i];
					if (!(i === issue.path.length - 1)) curr[el] = curr[el] || { _errors: [] };
					else {
						curr[el] = curr[el] || { _errors: [] };
						curr[el]._errors.push(mapper(issue));
					}
					curr = curr[el];
					i++;
				}
			}
		};
		processError(this);
		return fieldErrors;
	}
	static assert(value) {
		if (!(value instanceof ZodError)) throw new Error(`Not a ZodError: ${value}`);
	}
	toString() {
		return this.message;
	}
	get message() {
		return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
	}
	get isEmpty() {
		return this.issues.length === 0;
	}
	flatten(mapper = (issue) => issue.message) {
		const fieldErrors = {};
		const formErrors = [];
		for (const sub of this.issues) if (sub.path.length > 0) {
			const firstEl = sub.path[0];
			fieldErrors[firstEl] = fieldErrors[firstEl] || [];
			fieldErrors[firstEl].push(mapper(sub));
		} else formErrors.push(mapper(sub));
		return {
			formErrors,
			fieldErrors
		};
	}
	get formErrors() {
		return this.flatten();
	}
};
ZodError.create = (issues) => {
	return new ZodError(issues);
};
//#endregion
//#region node_modules/zod/v3/locales/en.js
const errorMap = (issue, _ctx) => {
	let message;
	switch (issue.code) {
		case ZodIssueCode.invalid_type:
			if (issue.received === ZodParsedType.undefined) message = "Required";
			else message = `Expected ${issue.expected}, received ${issue.received}`;
			break;
		case ZodIssueCode.invalid_literal:
			message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
			break;
		case ZodIssueCode.unrecognized_keys:
			message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
			break;
		case ZodIssueCode.invalid_union:
			message = `Invalid input`;
			break;
		case ZodIssueCode.invalid_union_discriminator:
			message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
			break;
		case ZodIssueCode.invalid_enum_value:
			message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
			break;
		case ZodIssueCode.invalid_arguments:
			message = `Invalid function arguments`;
			break;
		case ZodIssueCode.invalid_return_type:
			message = `Invalid function return type`;
			break;
		case ZodIssueCode.invalid_date:
			message = `Invalid date`;
			break;
		case ZodIssueCode.invalid_string:
			if (typeof issue.validation === "object") if ("includes" in issue.validation) {
				message = `Invalid input: must include "${issue.validation.includes}"`;
				if (typeof issue.validation.position === "number") message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
			} else if ("startsWith" in issue.validation) message = `Invalid input: must start with "${issue.validation.startsWith}"`;
			else if ("endsWith" in issue.validation) message = `Invalid input: must end with "${issue.validation.endsWith}"`;
			else util.assertNever(issue.validation);
			else if (issue.validation !== "regex") message = `Invalid ${issue.validation}`;
			else message = "Invalid";
			break;
		case ZodIssueCode.too_small:
			if (issue.type === "array") message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
			else if (issue.type === "string") message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
			else if (issue.type === "number") message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
			else if (issue.type === "bigint") message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
			else if (issue.type === "date") message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
			else message = "Invalid input";
			break;
		case ZodIssueCode.too_big:
			if (issue.type === "array") message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
			else if (issue.type === "string") message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
			else if (issue.type === "number") message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
			else if (issue.type === "bigint") message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
			else if (issue.type === "date") message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
			else message = "Invalid input";
			break;
		case ZodIssueCode.custom:
			message = `Invalid input`;
			break;
		case ZodIssueCode.invalid_intersection_types:
			message = `Intersection results could not be merged`;
			break;
		case ZodIssueCode.not_multiple_of:
			message = `Number must be a multiple of ${issue.multipleOf}`;
			break;
		case ZodIssueCode.not_finite:
			message = "Number must be finite";
			break;
		default:
			message = _ctx.defaultError;
			util.assertNever(issue);
	}
	return { message };
};
//#endregion
//#region node_modules/zod/v3/errors.js
let overrideErrorMap = errorMap;
function getErrorMap() {
	return overrideErrorMap;
}
//#endregion
//#region node_modules/zod/v3/helpers/parseUtil.js
const makeIssue = (params) => {
	const { data, path, errorMaps, issueData } = params;
	const fullPath = [...path, ...issueData.path || []];
	const fullIssue = {
		...issueData,
		path: fullPath
	};
	if (issueData.message !== void 0) return {
		...issueData,
		path: fullPath,
		message: issueData.message
	};
	let errorMessage = "";
	const maps = errorMaps.filter((m) => !!m).slice().reverse();
	for (const map of maps) errorMessage = map(fullIssue, {
		data,
		defaultError: errorMessage
	}).message;
	return {
		...issueData,
		path: fullPath,
		message: errorMessage
	};
};
function addIssueToContext(ctx, issueData) {
	const overrideMap = getErrorMap();
	const issue = makeIssue({
		issueData,
		data: ctx.data,
		path: ctx.path,
		errorMaps: [
			ctx.common.contextualErrorMap,
			ctx.schemaErrorMap,
			overrideMap,
			overrideMap === errorMap ? void 0 : errorMap
		].filter((x) => !!x)
	});
	ctx.common.issues.push(issue);
}
var ParseStatus = class ParseStatus {
	constructor() {
		this.value = "valid";
	}
	dirty() {
		if (this.value === "valid") this.value = "dirty";
	}
	abort() {
		if (this.value !== "aborted") this.value = "aborted";
	}
	static mergeArray(status, results) {
		const arrayValue = [];
		for (const s of results) {
			if (s.status === "aborted") return INVALID;
			if (s.status === "dirty") status.dirty();
			arrayValue.push(s.value);
		}
		return {
			status: status.value,
			value: arrayValue
		};
	}
	static async mergeObjectAsync(status, pairs) {
		const syncPairs = [];
		for (const pair of pairs) {
			const key = await pair.key;
			const value = await pair.value;
			syncPairs.push({
				key,
				value
			});
		}
		return ParseStatus.mergeObjectSync(status, syncPairs);
	}
	static mergeObjectSync(status, pairs) {
		const finalObject = {};
		for (const pair of pairs) {
			const { key, value } = pair;
			if (key.status === "aborted") return INVALID;
			if (value.status === "aborted") return INVALID;
			if (key.status === "dirty") status.dirty();
			if (value.status === "dirty") status.dirty();
			if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) finalObject[key.value] = value.value;
		}
		return {
			status: status.value,
			value: finalObject
		};
	}
};
const INVALID = Object.freeze({ status: "aborted" });
const DIRTY = (value) => ({
	status: "dirty",
	value
});
const OK = (value) => ({
	status: "valid",
	value
});
const isAborted = (x) => x.status === "aborted";
const isDirty = (x) => x.status === "dirty";
const isValid = (x) => x.status === "valid";
const isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;
//#endregion
//#region node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil) {
	errorUtil.errToObj = (message) => typeof message === "string" ? { message } : message || {};
	errorUtil.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));
//#endregion
//#region node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
	constructor(parent, value, path, key) {
		this._cachedPath = [];
		this.parent = parent;
		this.data = value;
		this._path = path;
		this._key = key;
	}
	get path() {
		if (!this._cachedPath.length) if (Array.isArray(this._key)) this._cachedPath.push(...this._path, ...this._key);
		else this._cachedPath.push(...this._path, this._key);
		return this._cachedPath;
	}
};
const handleResult = (ctx, result) => {
	if (isValid(result)) return {
		success: true,
		data: result.value
	};
	else {
		if (!ctx.common.issues.length) throw new Error("Validation failed but no issues detected.");
		return {
			success: false,
			get error() {
				if (this._error) return this._error;
				const error = new ZodError(ctx.common.issues);
				this._error = error;
				return this._error;
			}
		};
	}
};
function processCreateParams(params) {
	if (!params) return {};
	const { errorMap, invalid_type_error, required_error, description } = params;
	if (errorMap && (invalid_type_error || required_error)) throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
	if (errorMap) return {
		errorMap,
		description
	};
	const customMap = (iss, ctx) => {
		const { message } = params;
		if (iss.code === "invalid_enum_value") return { message: message ?? ctx.defaultError };
		if (typeof ctx.data === "undefined") return { message: message ?? required_error ?? ctx.defaultError };
		if (iss.code !== "invalid_type") return { message: ctx.defaultError };
		return { message: message ?? invalid_type_error ?? ctx.defaultError };
	};
	return {
		errorMap: customMap,
		description
	};
}
var ZodType = class {
	get description() {
		return this._def.description;
	}
	_getType(input) {
		return getParsedType(input.data);
	}
	_getOrReturnCtx(input, ctx) {
		return ctx || {
			common: input.parent.common,
			data: input.data,
			parsedType: getParsedType(input.data),
			schemaErrorMap: this._def.errorMap,
			path: input.path,
			parent: input.parent
		};
	}
	_processInputParams(input) {
		return {
			status: new ParseStatus(),
			ctx: {
				common: input.parent.common,
				data: input.data,
				parsedType: getParsedType(input.data),
				schemaErrorMap: this._def.errorMap,
				path: input.path,
				parent: input.parent
			}
		};
	}
	_parseSync(input) {
		const result = this._parse(input);
		if (isAsync(result)) throw new Error("Synchronous parse encountered promise.");
		return result;
	}
	_parseAsync(input) {
		const result = this._parse(input);
		return Promise.resolve(result);
	}
	parse(data, params) {
		const result = this.safeParse(data, params);
		if (result.success) return result.data;
		throw result.error;
	}
	safeParse(data, params) {
		const ctx = {
			common: {
				issues: [],
				async: params?.async ?? false,
				contextualErrorMap: params?.errorMap
			},
			path: params?.path || [],
			schemaErrorMap: this._def.errorMap,
			parent: null,
			data,
			parsedType: getParsedType(data)
		};
		return handleResult(ctx, this._parseSync({
			data,
			path: ctx.path,
			parent: ctx
		}));
	}
	"~validate"(data) {
		const ctx = {
			common: {
				issues: [],
				async: !!this["~standard"].async
			},
			path: [],
			schemaErrorMap: this._def.errorMap,
			parent: null,
			data,
			parsedType: getParsedType(data)
		};
		if (!this["~standard"].async) try {
			const result = this._parseSync({
				data,
				path: [],
				parent: ctx
			});
			return isValid(result) ? { value: result.value } : { issues: ctx.common.issues };
		} catch (err) {
			if (err?.message?.toLowerCase()?.includes("encountered")) this["~standard"].async = true;
			ctx.common = {
				issues: [],
				async: true
			};
		}
		return this._parseAsync({
			data,
			path: [],
			parent: ctx
		}).then((result) => isValid(result) ? { value: result.value } : { issues: ctx.common.issues });
	}
	async parseAsync(data, params) {
		const result = await this.safeParseAsync(data, params);
		if (result.success) return result.data;
		throw result.error;
	}
	async safeParseAsync(data, params) {
		const ctx = {
			common: {
				issues: [],
				contextualErrorMap: params?.errorMap,
				async: true
			},
			path: params?.path || [],
			schemaErrorMap: this._def.errorMap,
			parent: null,
			data,
			parsedType: getParsedType(data)
		};
		const maybeAsyncResult = this._parse({
			data,
			path: ctx.path,
			parent: ctx
		});
		return handleResult(ctx, await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult)));
	}
	refine(check, message) {
		const getIssueProperties = (val) => {
			if (typeof message === "string" || typeof message === "undefined") return { message };
			else if (typeof message === "function") return message(val);
			else return message;
		};
		return this._refinement((val, ctx) => {
			const result = check(val);
			const setError = () => ctx.addIssue({
				code: ZodIssueCode.custom,
				...getIssueProperties(val)
			});
			if (typeof Promise !== "undefined" && result instanceof Promise) return result.then((data) => {
				if (!data) {
					setError();
					return false;
				} else return true;
			});
			if (!result) {
				setError();
				return false;
			} else return true;
		});
	}
	refinement(check, refinementData) {
		return this._refinement((val, ctx) => {
			if (!check(val)) {
				ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
				return false;
			} else return true;
		});
	}
	_refinement(refinement) {
		return new ZodEffects({
			schema: this,
			typeName: ZodFirstPartyTypeKind.ZodEffects,
			effect: {
				type: "refinement",
				refinement
			}
		});
	}
	superRefine(refinement) {
		return this._refinement(refinement);
	}
	constructor(def) {
		/** Alias of safeParseAsync */
		this.spa = this.safeParseAsync;
		this._def = def;
		this.parse = this.parse.bind(this);
		this.safeParse = this.safeParse.bind(this);
		this.parseAsync = this.parseAsync.bind(this);
		this.safeParseAsync = this.safeParseAsync.bind(this);
		this.spa = this.spa.bind(this);
		this.refine = this.refine.bind(this);
		this.refinement = this.refinement.bind(this);
		this.superRefine = this.superRefine.bind(this);
		this.optional = this.optional.bind(this);
		this.nullable = this.nullable.bind(this);
		this.nullish = this.nullish.bind(this);
		this.array = this.array.bind(this);
		this.promise = this.promise.bind(this);
		this.or = this.or.bind(this);
		this.and = this.and.bind(this);
		this.transform = this.transform.bind(this);
		this.brand = this.brand.bind(this);
		this.default = this.default.bind(this);
		this.catch = this.catch.bind(this);
		this.describe = this.describe.bind(this);
		this.pipe = this.pipe.bind(this);
		this.readonly = this.readonly.bind(this);
		this.isNullable = this.isNullable.bind(this);
		this.isOptional = this.isOptional.bind(this);
		this["~standard"] = {
			version: 1,
			vendor: "zod",
			validate: (data) => this["~validate"](data)
		};
	}
	optional() {
		return ZodOptional.create(this, this._def);
	}
	nullable() {
		return ZodNullable.create(this, this._def);
	}
	nullish() {
		return this.nullable().optional();
	}
	array() {
		return ZodArray.create(this);
	}
	promise() {
		return ZodPromise.create(this, this._def);
	}
	or(option) {
		return ZodUnion.create([this, option], this._def);
	}
	and(incoming) {
		return ZodIntersection.create(this, incoming, this._def);
	}
	transform(transform) {
		return new ZodEffects({
			...processCreateParams(this._def),
			schema: this,
			typeName: ZodFirstPartyTypeKind.ZodEffects,
			effect: {
				type: "transform",
				transform
			}
		});
	}
	default(def) {
		const defaultValueFunc = typeof def === "function" ? def : () => def;
		return new ZodDefault({
			...processCreateParams(this._def),
			innerType: this,
			defaultValue: defaultValueFunc,
			typeName: ZodFirstPartyTypeKind.ZodDefault
		});
	}
	brand() {
		return new ZodBranded({
			typeName: ZodFirstPartyTypeKind.ZodBranded,
			type: this,
			...processCreateParams(this._def)
		});
	}
	catch(def) {
		const catchValueFunc = typeof def === "function" ? def : () => def;
		return new ZodCatch({
			...processCreateParams(this._def),
			innerType: this,
			catchValue: catchValueFunc,
			typeName: ZodFirstPartyTypeKind.ZodCatch
		});
	}
	describe(description) {
		const This = this.constructor;
		return new This({
			...this._def,
			description
		});
	}
	pipe(target) {
		return ZodPipeline.create(this, target);
	}
	readonly() {
		return ZodReadonly.create(this);
	}
	isOptional() {
		return this.safeParse(void 0).success;
	}
	isNullable() {
		return this.safeParse(null).success;
	}
};
const cuidRegex = /^c[^\s-]{8,}$/i;
const cuid2Regex = /^[0-9a-z]+$/;
const ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
const uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
const nanoidRegex = /^[a-z0-9_-]{21}$/i;
const jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
const durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
const emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
const _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
let emojiRegex;
const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
const ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
const ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
const ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
const base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
const base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
const dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
const dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
	let secondsRegexSource = `[0-5]\\d`;
	if (args.precision) secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
	else if (args.precision == null) secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
	const secondsQuantifier = args.precision ? "+" : "?";
	return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
	return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
	let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
	const opts = [];
	opts.push(args.local ? `Z?` : `Z`);
	if (args.offset) opts.push(`([+-]\\d{2}:?\\d{2})`);
	regex = `${regex}(${opts.join("|")})`;
	return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
	if ((version === "v4" || !version) && ipv4Regex.test(ip)) return true;
	if ((version === "v6" || !version) && ipv6Regex.test(ip)) return true;
	return false;
}
function isValidJWT(jwt, alg) {
	if (!jwtRegex.test(jwt)) return false;
	try {
		const [header] = jwt.split(".");
		if (!header) return false;
		const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
		const decoded = JSON.parse(atob(base64));
		if (typeof decoded !== "object" || decoded === null) return false;
		if ("typ" in decoded && decoded?.typ !== "JWT") return false;
		if (!decoded.alg) return false;
		if (alg && decoded.alg !== alg) return false;
		return true;
	} catch {
		return false;
	}
}
function isValidCidr(ip, version) {
	if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) return true;
	if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) return true;
	return false;
}
var ZodString = class ZodString extends ZodType {
	_parse(input) {
		if (this._def.coerce) input.data = String(input.data);
		if (this._getType(input) !== ZodParsedType.string) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.string,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const status = new ParseStatus();
		let ctx = void 0;
		for (const check of this._def.checks) if (check.kind === "min") {
			if (input.data.length < check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: check.value,
					type: "string",
					inclusive: true,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (input.data.length > check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: check.value,
					type: "string",
					inclusive: true,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "length") {
			const tooBig = input.data.length > check.value;
			const tooSmall = input.data.length < check.value;
			if (tooBig || tooSmall) {
				ctx = this._getOrReturnCtx(input, ctx);
				if (tooBig) addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: check.value,
					type: "string",
					inclusive: true,
					exact: true,
					message: check.message
				});
				else if (tooSmall) addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: check.value,
					type: "string",
					inclusive: true,
					exact: true,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "email") {
			if (!emailRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "email",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "emoji") {
			if (!emojiRegex) emojiRegex = new RegExp(_emojiRegex, "u");
			if (!emojiRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "emoji",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "uuid") {
			if (!uuidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "uuid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "nanoid") {
			if (!nanoidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "nanoid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "cuid") {
			if (!cuidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "cuid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "cuid2") {
			if (!cuid2Regex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "cuid2",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "ulid") {
			if (!ulidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "ulid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "url") try {
			new URL(input.data);
		} catch {
			ctx = this._getOrReturnCtx(input, ctx);
			addIssueToContext(ctx, {
				validation: "url",
				code: ZodIssueCode.invalid_string,
				message: check.message
			});
			status.dirty();
		}
		else if (check.kind === "regex") {
			check.regex.lastIndex = 0;
			if (!check.regex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "regex",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "trim") input.data = input.data.trim();
		else if (check.kind === "includes") {
			if (!input.data.includes(check.value, check.position)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: {
						includes: check.value,
						position: check.position
					},
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "toLowerCase") input.data = input.data.toLowerCase();
		else if (check.kind === "toUpperCase") input.data = input.data.toUpperCase();
		else if (check.kind === "startsWith") {
			if (!input.data.startsWith(check.value)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: { startsWith: check.value },
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "endsWith") {
			if (!input.data.endsWith(check.value)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: { endsWith: check.value },
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "datetime") {
			if (!datetimeRegex(check).test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: "datetime",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "date") {
			if (!dateRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: "date",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "time") {
			if (!timeRegex(check).test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: "time",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "duration") {
			if (!durationRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "duration",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "ip") {
			if (!isValidIP(input.data, check.version)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "ip",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "jwt") {
			if (!isValidJWT(input.data, check.alg)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "jwt",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "cidr") {
			if (!isValidCidr(input.data, check.version)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "cidr",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "base64") {
			if (!base64Regex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "base64",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "base64url") {
			if (!base64urlRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "base64url",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: input.data
		};
	}
	_regex(regex, validation, message) {
		return this.refinement((data) => regex.test(data), {
			validation,
			code: ZodIssueCode.invalid_string,
			...errorUtil.errToObj(message)
		});
	}
	_addCheck(check) {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	email(message) {
		return this._addCheck({
			kind: "email",
			...errorUtil.errToObj(message)
		});
	}
	url(message) {
		return this._addCheck({
			kind: "url",
			...errorUtil.errToObj(message)
		});
	}
	emoji(message) {
		return this._addCheck({
			kind: "emoji",
			...errorUtil.errToObj(message)
		});
	}
	uuid(message) {
		return this._addCheck({
			kind: "uuid",
			...errorUtil.errToObj(message)
		});
	}
	nanoid(message) {
		return this._addCheck({
			kind: "nanoid",
			...errorUtil.errToObj(message)
		});
	}
	cuid(message) {
		return this._addCheck({
			kind: "cuid",
			...errorUtil.errToObj(message)
		});
	}
	cuid2(message) {
		return this._addCheck({
			kind: "cuid2",
			...errorUtil.errToObj(message)
		});
	}
	ulid(message) {
		return this._addCheck({
			kind: "ulid",
			...errorUtil.errToObj(message)
		});
	}
	base64(message) {
		return this._addCheck({
			kind: "base64",
			...errorUtil.errToObj(message)
		});
	}
	base64url(message) {
		return this._addCheck({
			kind: "base64url",
			...errorUtil.errToObj(message)
		});
	}
	jwt(options) {
		return this._addCheck({
			kind: "jwt",
			...errorUtil.errToObj(options)
		});
	}
	ip(options) {
		return this._addCheck({
			kind: "ip",
			...errorUtil.errToObj(options)
		});
	}
	cidr(options) {
		return this._addCheck({
			kind: "cidr",
			...errorUtil.errToObj(options)
		});
	}
	datetime(options) {
		if (typeof options === "string") return this._addCheck({
			kind: "datetime",
			precision: null,
			offset: false,
			local: false,
			message: options
		});
		return this._addCheck({
			kind: "datetime",
			precision: typeof options?.precision === "undefined" ? null : options?.precision,
			offset: options?.offset ?? false,
			local: options?.local ?? false,
			...errorUtil.errToObj(options?.message)
		});
	}
	date(message) {
		return this._addCheck({
			kind: "date",
			message
		});
	}
	time(options) {
		if (typeof options === "string") return this._addCheck({
			kind: "time",
			precision: null,
			message: options
		});
		return this._addCheck({
			kind: "time",
			precision: typeof options?.precision === "undefined" ? null : options?.precision,
			...errorUtil.errToObj(options?.message)
		});
	}
	duration(message) {
		return this._addCheck({
			kind: "duration",
			...errorUtil.errToObj(message)
		});
	}
	regex(regex, message) {
		return this._addCheck({
			kind: "regex",
			regex,
			...errorUtil.errToObj(message)
		});
	}
	includes(value, options) {
		return this._addCheck({
			kind: "includes",
			value,
			position: options?.position,
			...errorUtil.errToObj(options?.message)
		});
	}
	startsWith(value, message) {
		return this._addCheck({
			kind: "startsWith",
			value,
			...errorUtil.errToObj(message)
		});
	}
	endsWith(value, message) {
		return this._addCheck({
			kind: "endsWith",
			value,
			...errorUtil.errToObj(message)
		});
	}
	min(minLength, message) {
		return this._addCheck({
			kind: "min",
			value: minLength,
			...errorUtil.errToObj(message)
		});
	}
	max(maxLength, message) {
		return this._addCheck({
			kind: "max",
			value: maxLength,
			...errorUtil.errToObj(message)
		});
	}
	length(len, message) {
		return this._addCheck({
			kind: "length",
			value: len,
			...errorUtil.errToObj(message)
		});
	}
	/**
	* Equivalent to `.min(1)`
	*/
	nonempty(message) {
		return this.min(1, errorUtil.errToObj(message));
	}
	trim() {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, { kind: "trim" }]
		});
	}
	toLowerCase() {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, { kind: "toLowerCase" }]
		});
	}
	toUpperCase() {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, { kind: "toUpperCase" }]
		});
	}
	get isDatetime() {
		return !!this._def.checks.find((ch) => ch.kind === "datetime");
	}
	get isDate() {
		return !!this._def.checks.find((ch) => ch.kind === "date");
	}
	get isTime() {
		return !!this._def.checks.find((ch) => ch.kind === "time");
	}
	get isDuration() {
		return !!this._def.checks.find((ch) => ch.kind === "duration");
	}
	get isEmail() {
		return !!this._def.checks.find((ch) => ch.kind === "email");
	}
	get isURL() {
		return !!this._def.checks.find((ch) => ch.kind === "url");
	}
	get isEmoji() {
		return !!this._def.checks.find((ch) => ch.kind === "emoji");
	}
	get isUUID() {
		return !!this._def.checks.find((ch) => ch.kind === "uuid");
	}
	get isNANOID() {
		return !!this._def.checks.find((ch) => ch.kind === "nanoid");
	}
	get isCUID() {
		return !!this._def.checks.find((ch) => ch.kind === "cuid");
	}
	get isCUID2() {
		return !!this._def.checks.find((ch) => ch.kind === "cuid2");
	}
	get isULID() {
		return !!this._def.checks.find((ch) => ch.kind === "ulid");
	}
	get isIP() {
		return !!this._def.checks.find((ch) => ch.kind === "ip");
	}
	get isCIDR() {
		return !!this._def.checks.find((ch) => ch.kind === "cidr");
	}
	get isBase64() {
		return !!this._def.checks.find((ch) => ch.kind === "base64");
	}
	get isBase64url() {
		return !!this._def.checks.find((ch) => ch.kind === "base64url");
	}
	get minLength() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min;
	}
	get maxLength() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max;
	}
};
ZodString.create = (params) => {
	return new ZodString({
		checks: [],
		typeName: ZodFirstPartyTypeKind.ZodString,
		coerce: params?.coerce ?? false,
		...processCreateParams(params)
	});
};
function floatSafeRemainder(val, step) {
	const valDecCount = (val.toString().split(".")[1] || "").length;
	const stepDecCount = (step.toString().split(".")[1] || "").length;
	const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
	return Number.parseInt(val.toFixed(decCount).replace(".", "")) % Number.parseInt(step.toFixed(decCount).replace(".", "")) / 10 ** decCount;
}
var ZodNumber = class ZodNumber extends ZodType {
	constructor() {
		super(...arguments);
		this.min = this.gte;
		this.max = this.lte;
		this.step = this.multipleOf;
	}
	_parse(input) {
		if (this._def.coerce) input.data = Number(input.data);
		if (this._getType(input) !== ZodParsedType.number) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.number,
				received: ctx.parsedType
			});
			return INVALID;
		}
		let ctx = void 0;
		const status = new ParseStatus();
		for (const check of this._def.checks) if (check.kind === "int") {
			if (!util.isInteger(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_type,
					expected: "integer",
					received: "float",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "min") {
			if (check.inclusive ? input.data < check.value : input.data <= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: check.value,
					type: "number",
					inclusive: check.inclusive,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (check.inclusive ? input.data > check.value : input.data >= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: check.value,
					type: "number",
					inclusive: check.inclusive,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "multipleOf") {
			if (floatSafeRemainder(input.data, check.value) !== 0) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.not_multiple_of,
					multipleOf: check.value,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "finite") {
			if (!Number.isFinite(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.not_finite,
					message: check.message
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: input.data
		};
	}
	gte(value, message) {
		return this.setLimit("min", value, true, errorUtil.toString(message));
	}
	gt(value, message) {
		return this.setLimit("min", value, false, errorUtil.toString(message));
	}
	lte(value, message) {
		return this.setLimit("max", value, true, errorUtil.toString(message));
	}
	lt(value, message) {
		return this.setLimit("max", value, false, errorUtil.toString(message));
	}
	setLimit(kind, value, inclusive, message) {
		return new ZodNumber({
			...this._def,
			checks: [...this._def.checks, {
				kind,
				value,
				inclusive,
				message: errorUtil.toString(message)
			}]
		});
	}
	_addCheck(check) {
		return new ZodNumber({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	int(message) {
		return this._addCheck({
			kind: "int",
			message: errorUtil.toString(message)
		});
	}
	positive(message) {
		return this._addCheck({
			kind: "min",
			value: 0,
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	negative(message) {
		return this._addCheck({
			kind: "max",
			value: 0,
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	nonpositive(message) {
		return this._addCheck({
			kind: "max",
			value: 0,
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	nonnegative(message) {
		return this._addCheck({
			kind: "min",
			value: 0,
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	multipleOf(value, message) {
		return this._addCheck({
			kind: "multipleOf",
			value,
			message: errorUtil.toString(message)
		});
	}
	finite(message) {
		return this._addCheck({
			kind: "finite",
			message: errorUtil.toString(message)
		});
	}
	safe(message) {
		return this._addCheck({
			kind: "min",
			inclusive: true,
			value: Number.MIN_SAFE_INTEGER,
			message: errorUtil.toString(message)
		})._addCheck({
			kind: "max",
			inclusive: true,
			value: Number.MAX_SAFE_INTEGER,
			message: errorUtil.toString(message)
		});
	}
	get minValue() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min;
	}
	get maxValue() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max;
	}
	get isInt() {
		return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
	}
	get isFinite() {
		let max = null;
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") return true;
		else if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		} else if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return Number.isFinite(min) && Number.isFinite(max);
	}
};
ZodNumber.create = (params) => {
	return new ZodNumber({
		checks: [],
		typeName: ZodFirstPartyTypeKind.ZodNumber,
		coerce: params?.coerce || false,
		...processCreateParams(params)
	});
};
var ZodBigInt = class ZodBigInt extends ZodType {
	constructor() {
		super(...arguments);
		this.min = this.gte;
		this.max = this.lte;
	}
	_parse(input) {
		if (this._def.coerce) try {
			input.data = BigInt(input.data);
		} catch {
			return this._getInvalidInput(input);
		}
		if (this._getType(input) !== ZodParsedType.bigint) return this._getInvalidInput(input);
		let ctx = void 0;
		const status = new ParseStatus();
		for (const check of this._def.checks) if (check.kind === "min") {
			if (check.inclusive ? input.data < check.value : input.data <= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					type: "bigint",
					minimum: check.value,
					inclusive: check.inclusive,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (check.inclusive ? input.data > check.value : input.data >= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					type: "bigint",
					maximum: check.value,
					inclusive: check.inclusive,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "multipleOf") {
			if (input.data % check.value !== BigInt(0)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.not_multiple_of,
					multipleOf: check.value,
					message: check.message
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: input.data
		};
	}
	_getInvalidInput(input) {
		const ctx = this._getOrReturnCtx(input);
		addIssueToContext(ctx, {
			code: ZodIssueCode.invalid_type,
			expected: ZodParsedType.bigint,
			received: ctx.parsedType
		});
		return INVALID;
	}
	gte(value, message) {
		return this.setLimit("min", value, true, errorUtil.toString(message));
	}
	gt(value, message) {
		return this.setLimit("min", value, false, errorUtil.toString(message));
	}
	lte(value, message) {
		return this.setLimit("max", value, true, errorUtil.toString(message));
	}
	lt(value, message) {
		return this.setLimit("max", value, false, errorUtil.toString(message));
	}
	setLimit(kind, value, inclusive, message) {
		return new ZodBigInt({
			...this._def,
			checks: [...this._def.checks, {
				kind,
				value,
				inclusive,
				message: errorUtil.toString(message)
			}]
		});
	}
	_addCheck(check) {
		return new ZodBigInt({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	positive(message) {
		return this._addCheck({
			kind: "min",
			value: BigInt(0),
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	negative(message) {
		return this._addCheck({
			kind: "max",
			value: BigInt(0),
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	nonpositive(message) {
		return this._addCheck({
			kind: "max",
			value: BigInt(0),
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	nonnegative(message) {
		return this._addCheck({
			kind: "min",
			value: BigInt(0),
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	multipleOf(value, message) {
		return this._addCheck({
			kind: "multipleOf",
			value,
			message: errorUtil.toString(message)
		});
	}
	get minValue() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min;
	}
	get maxValue() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max;
	}
};
ZodBigInt.create = (params) => {
	return new ZodBigInt({
		checks: [],
		typeName: ZodFirstPartyTypeKind.ZodBigInt,
		coerce: params?.coerce ?? false,
		...processCreateParams(params)
	});
};
var ZodBoolean = class extends ZodType {
	_parse(input) {
		if (this._def.coerce) input.data = Boolean(input.data);
		if (this._getType(input) !== ZodParsedType.boolean) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.boolean,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodBoolean.create = (params) => {
	return new ZodBoolean({
		typeName: ZodFirstPartyTypeKind.ZodBoolean,
		coerce: params?.coerce || false,
		...processCreateParams(params)
	});
};
var ZodDate = class ZodDate extends ZodType {
	_parse(input) {
		if (this._def.coerce) input.data = new Date(input.data);
		if (this._getType(input) !== ZodParsedType.date) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.date,
				received: ctx.parsedType
			});
			return INVALID;
		}
		if (Number.isNaN(input.data.getTime())) {
			addIssueToContext(this._getOrReturnCtx(input), { code: ZodIssueCode.invalid_date });
			return INVALID;
		}
		const status = new ParseStatus();
		let ctx = void 0;
		for (const check of this._def.checks) if (check.kind === "min") {
			if (input.data.getTime() < check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					message: check.message,
					inclusive: true,
					exact: false,
					minimum: check.value,
					type: "date"
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (input.data.getTime() > check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					message: check.message,
					inclusive: true,
					exact: false,
					maximum: check.value,
					type: "date"
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: new Date(input.data.getTime())
		};
	}
	_addCheck(check) {
		return new ZodDate({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	min(minDate, message) {
		return this._addCheck({
			kind: "min",
			value: minDate.getTime(),
			message: errorUtil.toString(message)
		});
	}
	max(maxDate, message) {
		return this._addCheck({
			kind: "max",
			value: maxDate.getTime(),
			message: errorUtil.toString(message)
		});
	}
	get minDate() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min != null ? new Date(min) : null;
	}
	get maxDate() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max != null ? new Date(max) : null;
	}
};
ZodDate.create = (params) => {
	return new ZodDate({
		checks: [],
		coerce: params?.coerce || false,
		typeName: ZodFirstPartyTypeKind.ZodDate,
		...processCreateParams(params)
	});
};
var ZodSymbol = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.symbol) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.symbol,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodSymbol.create = (params) => {
	return new ZodSymbol({
		typeName: ZodFirstPartyTypeKind.ZodSymbol,
		...processCreateParams(params)
	});
};
var ZodUndefined = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.undefined) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.undefined,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodUndefined.create = (params) => {
	return new ZodUndefined({
		typeName: ZodFirstPartyTypeKind.ZodUndefined,
		...processCreateParams(params)
	});
};
var ZodNull = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.null) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.null,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodNull.create = (params) => {
	return new ZodNull({
		typeName: ZodFirstPartyTypeKind.ZodNull,
		...processCreateParams(params)
	});
};
var ZodAny = class extends ZodType {
	constructor() {
		super(...arguments);
		this._any = true;
	}
	_parse(input) {
		return OK(input.data);
	}
};
ZodAny.create = (params) => {
	return new ZodAny({
		typeName: ZodFirstPartyTypeKind.ZodAny,
		...processCreateParams(params)
	});
};
var ZodUnknown = class extends ZodType {
	constructor() {
		super(...arguments);
		this._unknown = true;
	}
	_parse(input) {
		return OK(input.data);
	}
};
ZodUnknown.create = (params) => {
	return new ZodUnknown({
		typeName: ZodFirstPartyTypeKind.ZodUnknown,
		...processCreateParams(params)
	});
};
var ZodNever = class extends ZodType {
	_parse(input) {
		const ctx = this._getOrReturnCtx(input);
		addIssueToContext(ctx, {
			code: ZodIssueCode.invalid_type,
			expected: ZodParsedType.never,
			received: ctx.parsedType
		});
		return INVALID;
	}
};
ZodNever.create = (params) => {
	return new ZodNever({
		typeName: ZodFirstPartyTypeKind.ZodNever,
		...processCreateParams(params)
	});
};
var ZodVoid = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.undefined) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.void,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodVoid.create = (params) => {
	return new ZodVoid({
		typeName: ZodFirstPartyTypeKind.ZodVoid,
		...processCreateParams(params)
	});
};
var ZodArray = class ZodArray extends ZodType {
	_parse(input) {
		const { ctx, status } = this._processInputParams(input);
		const def = this._def;
		if (ctx.parsedType !== ZodParsedType.array) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.array,
				received: ctx.parsedType
			});
			return INVALID;
		}
		if (def.exactLength !== null) {
			const tooBig = ctx.data.length > def.exactLength.value;
			const tooSmall = ctx.data.length < def.exactLength.value;
			if (tooBig || tooSmall) {
				addIssueToContext(ctx, {
					code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
					minimum: tooSmall ? def.exactLength.value : void 0,
					maximum: tooBig ? def.exactLength.value : void 0,
					type: "array",
					inclusive: true,
					exact: true,
					message: def.exactLength.message
				});
				status.dirty();
			}
		}
		if (def.minLength !== null) {
			if (ctx.data.length < def.minLength.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: def.minLength.value,
					type: "array",
					inclusive: true,
					exact: false,
					message: def.minLength.message
				});
				status.dirty();
			}
		}
		if (def.maxLength !== null) {
			if (ctx.data.length > def.maxLength.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: def.maxLength.value,
					type: "array",
					inclusive: true,
					exact: false,
					message: def.maxLength.message
				});
				status.dirty();
			}
		}
		if (ctx.common.async) return Promise.all([...ctx.data].map((item, i) => {
			return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
		})).then((result) => {
			return ParseStatus.mergeArray(status, result);
		});
		const result = [...ctx.data].map((item, i) => {
			return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
		});
		return ParseStatus.mergeArray(status, result);
	}
	get element() {
		return this._def.type;
	}
	min(minLength, message) {
		return new ZodArray({
			...this._def,
			minLength: {
				value: minLength,
				message: errorUtil.toString(message)
			}
		});
	}
	max(maxLength, message) {
		return new ZodArray({
			...this._def,
			maxLength: {
				value: maxLength,
				message: errorUtil.toString(message)
			}
		});
	}
	length(len, message) {
		return new ZodArray({
			...this._def,
			exactLength: {
				value: len,
				message: errorUtil.toString(message)
			}
		});
	}
	nonempty(message) {
		return this.min(1, message);
	}
};
ZodArray.create = (schema, params) => {
	return new ZodArray({
		type: schema,
		minLength: null,
		maxLength: null,
		exactLength: null,
		typeName: ZodFirstPartyTypeKind.ZodArray,
		...processCreateParams(params)
	});
};
function deepPartialify(schema) {
	if (schema instanceof ZodObject) {
		const newShape = {};
		for (const key in schema.shape) {
			const fieldSchema = schema.shape[key];
			newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
		}
		return new ZodObject({
			...schema._def,
			shape: () => newShape
		});
	} else if (schema instanceof ZodArray) return new ZodArray({
		...schema._def,
		type: deepPartialify(schema.element)
	});
	else if (schema instanceof ZodOptional) return ZodOptional.create(deepPartialify(schema.unwrap()));
	else if (schema instanceof ZodNullable) return ZodNullable.create(deepPartialify(schema.unwrap()));
	else if (schema instanceof ZodTuple) return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
	else return schema;
}
var ZodObject = class ZodObject extends ZodType {
	constructor() {
		super(...arguments);
		this._cached = null;
		/**
		* @deprecated In most cases, this is no longer needed - unknown properties are now silently stripped.
		* If you want to pass through unknown properties, use `.passthrough()` instead.
		*/
		this.nonstrict = this.passthrough;
		/**
		* @deprecated Use `.extend` instead
		*  */
		this.augment = this.extend;
	}
	_getCached() {
		if (this._cached !== null) return this._cached;
		const shape = this._def.shape();
		const keys = util.objectKeys(shape);
		this._cached = {
			shape,
			keys
		};
		return this._cached;
	}
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.object) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.object,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const { status, ctx } = this._processInputParams(input);
		const { shape, keys: shapeKeys } = this._getCached();
		const extraKeys = [];
		if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
			for (const key in ctx.data) if (!shapeKeys.includes(key)) extraKeys.push(key);
		}
		const pairs = [];
		for (const key of shapeKeys) {
			const keyValidator = shape[key];
			const value = ctx.data[key];
			pairs.push({
				key: {
					status: "valid",
					value: key
				},
				value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
				alwaysSet: key in ctx.data
			});
		}
		if (this._def.catchall instanceof ZodNever) {
			const unknownKeys = this._def.unknownKeys;
			if (unknownKeys === "passthrough") for (const key of extraKeys) pairs.push({
				key: {
					status: "valid",
					value: key
				},
				value: {
					status: "valid",
					value: ctx.data[key]
				}
			});
			else if (unknownKeys === "strict") {
				if (extraKeys.length > 0) {
					addIssueToContext(ctx, {
						code: ZodIssueCode.unrecognized_keys,
						keys: extraKeys
					});
					status.dirty();
				}
			} else if (unknownKeys === "strip") {} else throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
		} else {
			const catchall = this._def.catchall;
			for (const key of extraKeys) {
				const value = ctx.data[key];
				pairs.push({
					key: {
						status: "valid",
						value: key
					},
					value: catchall._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
					alwaysSet: key in ctx.data
				});
			}
		}
		if (ctx.common.async) return Promise.resolve().then(async () => {
			const syncPairs = [];
			for (const pair of pairs) {
				const key = await pair.key;
				const value = await pair.value;
				syncPairs.push({
					key,
					value,
					alwaysSet: pair.alwaysSet
				});
			}
			return syncPairs;
		}).then((syncPairs) => {
			return ParseStatus.mergeObjectSync(status, syncPairs);
		});
		else return ParseStatus.mergeObjectSync(status, pairs);
	}
	get shape() {
		return this._def.shape();
	}
	strict(message) {
		errorUtil.errToObj;
		return new ZodObject({
			...this._def,
			unknownKeys: "strict",
			...message !== void 0 ? { errorMap: (issue, ctx) => {
				const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
				if (issue.code === "unrecognized_keys") return { message: errorUtil.errToObj(message).message ?? defaultError };
				return { message: defaultError };
			} } : {}
		});
	}
	strip() {
		return new ZodObject({
			...this._def,
			unknownKeys: "strip"
		});
	}
	passthrough() {
		return new ZodObject({
			...this._def,
			unknownKeys: "passthrough"
		});
	}
	extend(augmentation) {
		return new ZodObject({
			...this._def,
			shape: () => ({
				...this._def.shape(),
				...augmentation
			})
		});
	}
	/**
	* Prior to zod@1.0.12 there was a bug in the
	* inferred type of merged objects. Please
	* upgrade if you are experiencing issues.
	*/
	merge(merging) {
		return new ZodObject({
			unknownKeys: merging._def.unknownKeys,
			catchall: merging._def.catchall,
			shape: () => ({
				...this._def.shape(),
				...merging._def.shape()
			}),
			typeName: ZodFirstPartyTypeKind.ZodObject
		});
	}
	setKey(key, schema) {
		return this.augment({ [key]: schema });
	}
	catchall(index) {
		return new ZodObject({
			...this._def,
			catchall: index
		});
	}
	pick(mask) {
		const shape = {};
		for (const key of util.objectKeys(mask)) if (mask[key] && this.shape[key]) shape[key] = this.shape[key];
		return new ZodObject({
			...this._def,
			shape: () => shape
		});
	}
	omit(mask) {
		const shape = {};
		for (const key of util.objectKeys(this.shape)) if (!mask[key]) shape[key] = this.shape[key];
		return new ZodObject({
			...this._def,
			shape: () => shape
		});
	}
	/**
	* @deprecated
	*/
	deepPartial() {
		return deepPartialify(this);
	}
	partial(mask) {
		const newShape = {};
		for (const key of util.objectKeys(this.shape)) {
			const fieldSchema = this.shape[key];
			if (mask && !mask[key]) newShape[key] = fieldSchema;
			else newShape[key] = fieldSchema.optional();
		}
		return new ZodObject({
			...this._def,
			shape: () => newShape
		});
	}
	required(mask) {
		const newShape = {};
		for (const key of util.objectKeys(this.shape)) if (mask && !mask[key]) newShape[key] = this.shape[key];
		else {
			let newField = this.shape[key];
			while (newField instanceof ZodOptional) newField = newField._def.innerType;
			newShape[key] = newField;
		}
		return new ZodObject({
			...this._def,
			shape: () => newShape
		});
	}
	keyof() {
		return createZodEnum(util.objectKeys(this.shape));
	}
};
ZodObject.create = (shape, params) => {
	return new ZodObject({
		shape: () => shape,
		unknownKeys: "strip",
		catchall: ZodNever.create(),
		typeName: ZodFirstPartyTypeKind.ZodObject,
		...processCreateParams(params)
	});
};
ZodObject.strictCreate = (shape, params) => {
	return new ZodObject({
		shape: () => shape,
		unknownKeys: "strict",
		catchall: ZodNever.create(),
		typeName: ZodFirstPartyTypeKind.ZodObject,
		...processCreateParams(params)
	});
};
ZodObject.lazycreate = (shape, params) => {
	return new ZodObject({
		shape,
		unknownKeys: "strip",
		catchall: ZodNever.create(),
		typeName: ZodFirstPartyTypeKind.ZodObject,
		...processCreateParams(params)
	});
};
var ZodUnion = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		const options = this._def.options;
		function handleResults(results) {
			for (const result of results) if (result.result.status === "valid") return result.result;
			for (const result of results) if (result.result.status === "dirty") {
				ctx.common.issues.push(...result.ctx.common.issues);
				return result.result;
			}
			const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_union,
				unionErrors
			});
			return INVALID;
		}
		if (ctx.common.async) return Promise.all(options.map(async (option) => {
			const childCtx = {
				...ctx,
				common: {
					...ctx.common,
					issues: []
				},
				parent: null
			};
			return {
				result: await option._parseAsync({
					data: ctx.data,
					path: ctx.path,
					parent: childCtx
				}),
				ctx: childCtx
			};
		})).then(handleResults);
		else {
			let dirty = void 0;
			const issues = [];
			for (const option of options) {
				const childCtx = {
					...ctx,
					common: {
						...ctx.common,
						issues: []
					},
					parent: null
				};
				const result = option._parseSync({
					data: ctx.data,
					path: ctx.path,
					parent: childCtx
				});
				if (result.status === "valid") return result;
				else if (result.status === "dirty" && !dirty) dirty = {
					result,
					ctx: childCtx
				};
				if (childCtx.common.issues.length) issues.push(childCtx.common.issues);
			}
			if (dirty) {
				ctx.common.issues.push(...dirty.ctx.common.issues);
				return dirty.result;
			}
			const unionErrors = issues.map((issues) => new ZodError(issues));
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_union,
				unionErrors
			});
			return INVALID;
		}
	}
	get options() {
		return this._def.options;
	}
};
ZodUnion.create = (types, params) => {
	return new ZodUnion({
		options: types,
		typeName: ZodFirstPartyTypeKind.ZodUnion,
		...processCreateParams(params)
	});
};
const getDiscriminator = (type) => {
	if (type instanceof ZodLazy) return getDiscriminator(type.schema);
	else if (type instanceof ZodEffects) return getDiscriminator(type.innerType());
	else if (type instanceof ZodLiteral) return [type.value];
	else if (type instanceof ZodEnum) return type.options;
	else if (type instanceof ZodNativeEnum) return util.objectValues(type.enum);
	else if (type instanceof ZodDefault) return getDiscriminator(type._def.innerType);
	else if (type instanceof ZodUndefined) return [void 0];
	else if (type instanceof ZodNull) return [null];
	else if (type instanceof ZodOptional) return [void 0, ...getDiscriminator(type.unwrap())];
	else if (type instanceof ZodNullable) return [null, ...getDiscriminator(type.unwrap())];
	else if (type instanceof ZodBranded) return getDiscriminator(type.unwrap());
	else if (type instanceof ZodReadonly) return getDiscriminator(type.unwrap());
	else if (type instanceof ZodCatch) return getDiscriminator(type._def.innerType);
	else return [];
};
var ZodDiscriminatedUnion = class ZodDiscriminatedUnion extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.object) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.object,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const discriminator = this.discriminator;
		const discriminatorValue = ctx.data[discriminator];
		const option = this.optionsMap.get(discriminatorValue);
		if (!option) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_union_discriminator,
				options: Array.from(this.optionsMap.keys()),
				path: [discriminator]
			});
			return INVALID;
		}
		if (ctx.common.async) return option._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		});
		else return option._parseSync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		});
	}
	get discriminator() {
		return this._def.discriminator;
	}
	get options() {
		return this._def.options;
	}
	get optionsMap() {
		return this._def.optionsMap;
	}
	/**
	* The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
	* However, it only allows a union of objects, all of which need to share a discriminator property. This property must
	* have a different value for each object in the union.
	* @param discriminator the name of the discriminator property
	* @param types an array of object schemas
	* @param params
	*/
	static create(discriminator, options, params) {
		const optionsMap = /* @__PURE__ */ new Map();
		for (const type of options) {
			const discriminatorValues = getDiscriminator(type.shape[discriminator]);
			if (!discriminatorValues.length) throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
			for (const value of discriminatorValues) {
				if (optionsMap.has(value)) throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
				optionsMap.set(value, type);
			}
		}
		return new ZodDiscriminatedUnion({
			typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
			discriminator,
			options,
			optionsMap,
			...processCreateParams(params)
		});
	}
};
function mergeValues(a, b) {
	const aType = getParsedType(a);
	const bType = getParsedType(b);
	if (a === b) return {
		valid: true,
		data: a
	};
	else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
		const bKeys = util.objectKeys(b);
		const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
		const newObj = {
			...a,
			...b
		};
		for (const key of sharedKeys) {
			const sharedValue = mergeValues(a[key], b[key]);
			if (!sharedValue.valid) return { valid: false };
			newObj[key] = sharedValue.data;
		}
		return {
			valid: true,
			data: newObj
		};
	} else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
		if (a.length !== b.length) return { valid: false };
		const newArray = [];
		for (let index = 0; index < a.length; index++) {
			const itemA = a[index];
			const itemB = b[index];
			const sharedValue = mergeValues(itemA, itemB);
			if (!sharedValue.valid) return { valid: false };
			newArray.push(sharedValue.data);
		}
		return {
			valid: true,
			data: newArray
		};
	} else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) return {
		valid: true,
		data: a
	};
	else return { valid: false };
}
var ZodIntersection = class extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		const handleParsed = (parsedLeft, parsedRight) => {
			if (isAborted(parsedLeft) || isAborted(parsedRight)) return INVALID;
			const merged = mergeValues(parsedLeft.value, parsedRight.value);
			if (!merged.valid) {
				addIssueToContext(ctx, { code: ZodIssueCode.invalid_intersection_types });
				return INVALID;
			}
			if (isDirty(parsedLeft) || isDirty(parsedRight)) status.dirty();
			return {
				status: status.value,
				value: merged.data
			};
		};
		if (ctx.common.async) return Promise.all([this._def.left._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}), this._def.right._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		})]).then(([left, right]) => handleParsed(left, right));
		else return handleParsed(this._def.left._parseSync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}), this._def.right._parseSync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}));
	}
};
ZodIntersection.create = (left, right, params) => {
	return new ZodIntersection({
		left,
		right,
		typeName: ZodFirstPartyTypeKind.ZodIntersection,
		...processCreateParams(params)
	});
};
var ZodTuple = class ZodTuple extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.array) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.array,
				received: ctx.parsedType
			});
			return INVALID;
		}
		if (ctx.data.length < this._def.items.length) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.too_small,
				minimum: this._def.items.length,
				inclusive: true,
				exact: false,
				type: "array"
			});
			return INVALID;
		}
		if (!this._def.rest && ctx.data.length > this._def.items.length) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.too_big,
				maximum: this._def.items.length,
				inclusive: true,
				exact: false,
				type: "array"
			});
			status.dirty();
		}
		const items = [...ctx.data].map((item, itemIndex) => {
			const schema = this._def.items[itemIndex] || this._def.rest;
			if (!schema) return null;
			return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
		}).filter((x) => !!x);
		if (ctx.common.async) return Promise.all(items).then((results) => {
			return ParseStatus.mergeArray(status, results);
		});
		else return ParseStatus.mergeArray(status, items);
	}
	get items() {
		return this._def.items;
	}
	rest(rest) {
		return new ZodTuple({
			...this._def,
			rest
		});
	}
};
ZodTuple.create = (schemas, params) => {
	if (!Array.isArray(schemas)) throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
	return new ZodTuple({
		items: schemas,
		typeName: ZodFirstPartyTypeKind.ZodTuple,
		rest: null,
		...processCreateParams(params)
	});
};
var ZodRecord = class ZodRecord extends ZodType {
	get keySchema() {
		return this._def.keyType;
	}
	get valueSchema() {
		return this._def.valueType;
	}
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.object) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.object,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const pairs = [];
		const keyType = this._def.keyType;
		const valueType = this._def.valueType;
		for (const key in ctx.data) pairs.push({
			key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
			value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
			alwaysSet: key in ctx.data
		});
		if (ctx.common.async) return ParseStatus.mergeObjectAsync(status, pairs);
		else return ParseStatus.mergeObjectSync(status, pairs);
	}
	get element() {
		return this._def.valueType;
	}
	static create(first, second, third) {
		if (second instanceof ZodType) return new ZodRecord({
			keyType: first,
			valueType: second,
			typeName: ZodFirstPartyTypeKind.ZodRecord,
			...processCreateParams(third)
		});
		return new ZodRecord({
			keyType: ZodString.create(),
			valueType: first,
			typeName: ZodFirstPartyTypeKind.ZodRecord,
			...processCreateParams(second)
		});
	}
};
var ZodMap = class extends ZodType {
	get keySchema() {
		return this._def.keyType;
	}
	get valueSchema() {
		return this._def.valueType;
	}
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.map) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.map,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const keyType = this._def.keyType;
		const valueType = this._def.valueType;
		const pairs = [...ctx.data.entries()].map(([key, value], index) => {
			return {
				key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
				value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
			};
		});
		if (ctx.common.async) {
			const finalMap = /* @__PURE__ */ new Map();
			return Promise.resolve().then(async () => {
				for (const pair of pairs) {
					const key = await pair.key;
					const value = await pair.value;
					if (key.status === "aborted" || value.status === "aborted") return INVALID;
					if (key.status === "dirty" || value.status === "dirty") status.dirty();
					finalMap.set(key.value, value.value);
				}
				return {
					status: status.value,
					value: finalMap
				};
			});
		} else {
			const finalMap = /* @__PURE__ */ new Map();
			for (const pair of pairs) {
				const key = pair.key;
				const value = pair.value;
				if (key.status === "aborted" || value.status === "aborted") return INVALID;
				if (key.status === "dirty" || value.status === "dirty") status.dirty();
				finalMap.set(key.value, value.value);
			}
			return {
				status: status.value,
				value: finalMap
			};
		}
	}
};
ZodMap.create = (keyType, valueType, params) => {
	return new ZodMap({
		valueType,
		keyType,
		typeName: ZodFirstPartyTypeKind.ZodMap,
		...processCreateParams(params)
	});
};
var ZodSet = class ZodSet extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.set) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.set,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const def = this._def;
		if (def.minSize !== null) {
			if (ctx.data.size < def.minSize.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: def.minSize.value,
					type: "set",
					inclusive: true,
					exact: false,
					message: def.minSize.message
				});
				status.dirty();
			}
		}
		if (def.maxSize !== null) {
			if (ctx.data.size > def.maxSize.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: def.maxSize.value,
					type: "set",
					inclusive: true,
					exact: false,
					message: def.maxSize.message
				});
				status.dirty();
			}
		}
		const valueType = this._def.valueType;
		function finalizeSet(elements) {
			const parsedSet = /* @__PURE__ */ new Set();
			for (const element of elements) {
				if (element.status === "aborted") return INVALID;
				if (element.status === "dirty") status.dirty();
				parsedSet.add(element.value);
			}
			return {
				status: status.value,
				value: parsedSet
			};
		}
		const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
		if (ctx.common.async) return Promise.all(elements).then((elements) => finalizeSet(elements));
		else return finalizeSet(elements);
	}
	min(minSize, message) {
		return new ZodSet({
			...this._def,
			minSize: {
				value: minSize,
				message: errorUtil.toString(message)
			}
		});
	}
	max(maxSize, message) {
		return new ZodSet({
			...this._def,
			maxSize: {
				value: maxSize,
				message: errorUtil.toString(message)
			}
		});
	}
	size(size, message) {
		return this.min(size, message).max(size, message);
	}
	nonempty(message) {
		return this.min(1, message);
	}
};
ZodSet.create = (valueType, params) => {
	return new ZodSet({
		valueType,
		minSize: null,
		maxSize: null,
		typeName: ZodFirstPartyTypeKind.ZodSet,
		...processCreateParams(params)
	});
};
var ZodFunction = class ZodFunction extends ZodType {
	constructor() {
		super(...arguments);
		this.validate = this.implement;
	}
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.function) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.function,
				received: ctx.parsedType
			});
			return INVALID;
		}
		function makeArgsIssue(args, error) {
			return makeIssue({
				data: args,
				path: ctx.path,
				errorMaps: [
					ctx.common.contextualErrorMap,
					ctx.schemaErrorMap,
					getErrorMap(),
					errorMap
				].filter((x) => !!x),
				issueData: {
					code: ZodIssueCode.invalid_arguments,
					argumentsError: error
				}
			});
		}
		function makeReturnsIssue(returns, error) {
			return makeIssue({
				data: returns,
				path: ctx.path,
				errorMaps: [
					ctx.common.contextualErrorMap,
					ctx.schemaErrorMap,
					getErrorMap(),
					errorMap
				].filter((x) => !!x),
				issueData: {
					code: ZodIssueCode.invalid_return_type,
					returnTypeError: error
				}
			});
		}
		const params = { errorMap: ctx.common.contextualErrorMap };
		const fn = ctx.data;
		if (this._def.returns instanceof ZodPromise) {
			const me = this;
			return OK(async function(...args) {
				const error = new ZodError([]);
				const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
					error.addIssue(makeArgsIssue(args, e));
					throw error;
				});
				const result = await Reflect.apply(fn, this, parsedArgs);
				return await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
					error.addIssue(makeReturnsIssue(result, e));
					throw error;
				});
			});
		} else {
			const me = this;
			return OK(function(...args) {
				const parsedArgs = me._def.args.safeParse(args, params);
				if (!parsedArgs.success) throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
				const result = Reflect.apply(fn, this, parsedArgs.data);
				const parsedReturns = me._def.returns.safeParse(result, params);
				if (!parsedReturns.success) throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
				return parsedReturns.data;
			});
		}
	}
	parameters() {
		return this._def.args;
	}
	returnType() {
		return this._def.returns;
	}
	args(...items) {
		return new ZodFunction({
			...this._def,
			args: ZodTuple.create(items).rest(ZodUnknown.create())
		});
	}
	returns(returnType) {
		return new ZodFunction({
			...this._def,
			returns: returnType
		});
	}
	implement(func) {
		return this.parse(func);
	}
	strictImplement(func) {
		return this.parse(func);
	}
	static create(args, returns, params) {
		return new ZodFunction({
			args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
			returns: returns || ZodUnknown.create(),
			typeName: ZodFirstPartyTypeKind.ZodFunction,
			...processCreateParams(params)
		});
	}
};
var ZodLazy = class extends ZodType {
	get schema() {
		return this._def.getter();
	}
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		return this._def.getter()._parse({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		});
	}
};
ZodLazy.create = (getter, params) => {
	return new ZodLazy({
		getter,
		typeName: ZodFirstPartyTypeKind.ZodLazy,
		...processCreateParams(params)
	});
};
var ZodLiteral = class extends ZodType {
	_parse(input) {
		if (input.data !== this._def.value) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				received: ctx.data,
				code: ZodIssueCode.invalid_literal,
				expected: this._def.value
			});
			return INVALID;
		}
		return {
			status: "valid",
			value: input.data
		};
	}
	get value() {
		return this._def.value;
	}
};
ZodLiteral.create = (value, params) => {
	return new ZodLiteral({
		value,
		typeName: ZodFirstPartyTypeKind.ZodLiteral,
		...processCreateParams(params)
	});
};
function createZodEnum(values, params) {
	return new ZodEnum({
		values,
		typeName: ZodFirstPartyTypeKind.ZodEnum,
		...processCreateParams(params)
	});
}
var ZodEnum = class ZodEnum extends ZodType {
	_parse(input) {
		if (typeof input.data !== "string") {
			const ctx = this._getOrReturnCtx(input);
			const expectedValues = this._def.values;
			addIssueToContext(ctx, {
				expected: util.joinValues(expectedValues),
				received: ctx.parsedType,
				code: ZodIssueCode.invalid_type
			});
			return INVALID;
		}
		if (!this._cache) this._cache = new Set(this._def.values);
		if (!this._cache.has(input.data)) {
			const ctx = this._getOrReturnCtx(input);
			const expectedValues = this._def.values;
			addIssueToContext(ctx, {
				received: ctx.data,
				code: ZodIssueCode.invalid_enum_value,
				options: expectedValues
			});
			return INVALID;
		}
		return OK(input.data);
	}
	get options() {
		return this._def.values;
	}
	get enum() {
		const enumValues = {};
		for (const val of this._def.values) enumValues[val] = val;
		return enumValues;
	}
	get Values() {
		const enumValues = {};
		for (const val of this._def.values) enumValues[val] = val;
		return enumValues;
	}
	get Enum() {
		const enumValues = {};
		for (const val of this._def.values) enumValues[val] = val;
		return enumValues;
	}
	extract(values, newDef = this._def) {
		return ZodEnum.create(values, {
			...this._def,
			...newDef
		});
	}
	exclude(values, newDef = this._def) {
		return ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
			...this._def,
			...newDef
		});
	}
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
	_parse(input) {
		const nativeEnumValues = util.getValidEnumValues(this._def.values);
		const ctx = this._getOrReturnCtx(input);
		if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
			const expectedValues = util.objectValues(nativeEnumValues);
			addIssueToContext(ctx, {
				expected: util.joinValues(expectedValues),
				received: ctx.parsedType,
				code: ZodIssueCode.invalid_type
			});
			return INVALID;
		}
		if (!this._cache) this._cache = new Set(util.getValidEnumValues(this._def.values));
		if (!this._cache.has(input.data)) {
			const expectedValues = util.objectValues(nativeEnumValues);
			addIssueToContext(ctx, {
				received: ctx.data,
				code: ZodIssueCode.invalid_enum_value,
				options: expectedValues
			});
			return INVALID;
		}
		return OK(input.data);
	}
	get enum() {
		return this._def.values;
	}
};
ZodNativeEnum.create = (values, params) => {
	return new ZodNativeEnum({
		values,
		typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
		...processCreateParams(params)
	});
};
var ZodPromise = class extends ZodType {
	unwrap() {
		return this._def.type;
	}
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.promise,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK((ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data)).then((data) => {
			return this._def.type.parseAsync(data, {
				path: ctx.path,
				errorMap: ctx.common.contextualErrorMap
			});
		}));
	}
};
ZodPromise.create = (schema, params) => {
	return new ZodPromise({
		type: schema,
		typeName: ZodFirstPartyTypeKind.ZodPromise,
		...processCreateParams(params)
	});
};
var ZodEffects = class extends ZodType {
	innerType() {
		return this._def.schema;
	}
	sourceType() {
		return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
	}
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		const effect = this._def.effect || null;
		const checkCtx = {
			addIssue: (arg) => {
				addIssueToContext(ctx, arg);
				if (arg.fatal) status.abort();
				else status.dirty();
			},
			get path() {
				return ctx.path;
			}
		};
		checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
		if (effect.type === "preprocess") {
			const processed = effect.transform(ctx.data, checkCtx);
			if (ctx.common.async) return Promise.resolve(processed).then(async (processed) => {
				if (status.value === "aborted") return INVALID;
				const result = await this._def.schema._parseAsync({
					data: processed,
					path: ctx.path,
					parent: ctx
				});
				if (result.status === "aborted") return INVALID;
				if (result.status === "dirty") return DIRTY(result.value);
				if (status.value === "dirty") return DIRTY(result.value);
				return result;
			});
			else {
				if (status.value === "aborted") return INVALID;
				const result = this._def.schema._parseSync({
					data: processed,
					path: ctx.path,
					parent: ctx
				});
				if (result.status === "aborted") return INVALID;
				if (result.status === "dirty") return DIRTY(result.value);
				if (status.value === "dirty") return DIRTY(result.value);
				return result;
			}
		}
		if (effect.type === "refinement") {
			const executeRefinement = (acc) => {
				const result = effect.refinement(acc, checkCtx);
				if (ctx.common.async) return Promise.resolve(result);
				if (result instanceof Promise) throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
				return acc;
			};
			if (ctx.common.async === false) {
				const inner = this._def.schema._parseSync({
					data: ctx.data,
					path: ctx.path,
					parent: ctx
				});
				if (inner.status === "aborted") return INVALID;
				if (inner.status === "dirty") status.dirty();
				executeRefinement(inner.value);
				return {
					status: status.value,
					value: inner.value
				};
			} else return this._def.schema._parseAsync({
				data: ctx.data,
				path: ctx.path,
				parent: ctx
			}).then((inner) => {
				if (inner.status === "aborted") return INVALID;
				if (inner.status === "dirty") status.dirty();
				return executeRefinement(inner.value).then(() => {
					return {
						status: status.value,
						value: inner.value
					};
				});
			});
		}
		if (effect.type === "transform") if (ctx.common.async === false) {
			const base = this._def.schema._parseSync({
				data: ctx.data,
				path: ctx.path,
				parent: ctx
			});
			if (!isValid(base)) return INVALID;
			const result = effect.transform(base.value, checkCtx);
			if (result instanceof Promise) throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
			return {
				status: status.value,
				value: result
			};
		} else return this._def.schema._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}).then((base) => {
			if (!isValid(base)) return INVALID;
			return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
				status: status.value,
				value: result
			}));
		});
		util.assertNever(effect);
	}
};
ZodEffects.create = (schema, effect, params) => {
	return new ZodEffects({
		schema,
		typeName: ZodFirstPartyTypeKind.ZodEffects,
		effect,
		...processCreateParams(params)
	});
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
	return new ZodEffects({
		schema,
		effect: {
			type: "preprocess",
			transform: preprocess
		},
		typeName: ZodFirstPartyTypeKind.ZodEffects,
		...processCreateParams(params)
	});
};
var ZodOptional = class extends ZodType {
	_parse(input) {
		if (this._getType(input) === ZodParsedType.undefined) return OK(void 0);
		return this._def.innerType._parse(input);
	}
	unwrap() {
		return this._def.innerType;
	}
};
ZodOptional.create = (type, params) => {
	return new ZodOptional({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodOptional,
		...processCreateParams(params)
	});
};
var ZodNullable = class extends ZodType {
	_parse(input) {
		if (this._getType(input) === ZodParsedType.null) return OK(null);
		return this._def.innerType._parse(input);
	}
	unwrap() {
		return this._def.innerType;
	}
};
ZodNullable.create = (type, params) => {
	return new ZodNullable({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodNullable,
		...processCreateParams(params)
	});
};
var ZodDefault = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		let data = ctx.data;
		if (ctx.parsedType === ZodParsedType.undefined) data = this._def.defaultValue();
		return this._def.innerType._parse({
			data,
			path: ctx.path,
			parent: ctx
		});
	}
	removeDefault() {
		return this._def.innerType;
	}
};
ZodDefault.create = (type, params) => {
	return new ZodDefault({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodDefault,
		defaultValue: typeof params.default === "function" ? params.default : () => params.default,
		...processCreateParams(params)
	});
};
var ZodCatch = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		const newCtx = {
			...ctx,
			common: {
				...ctx.common,
				issues: []
			}
		};
		const result = this._def.innerType._parse({
			data: newCtx.data,
			path: newCtx.path,
			parent: { ...newCtx }
		});
		if (isAsync(result)) return result.then((result) => {
			return {
				status: "valid",
				value: result.status === "valid" ? result.value : this._def.catchValue({
					get error() {
						return new ZodError(newCtx.common.issues);
					},
					input: newCtx.data
				})
			};
		});
		else return {
			status: "valid",
			value: result.status === "valid" ? result.value : this._def.catchValue({
				get error() {
					return new ZodError(newCtx.common.issues);
				},
				input: newCtx.data
			})
		};
	}
	removeCatch() {
		return this._def.innerType;
	}
};
ZodCatch.create = (type, params) => {
	return new ZodCatch({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodCatch,
		catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
		...processCreateParams(params)
	});
};
var ZodNaN = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.nan) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.nan,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return {
			status: "valid",
			value: input.data
		};
	}
};
ZodNaN.create = (params) => {
	return new ZodNaN({
		typeName: ZodFirstPartyTypeKind.ZodNaN,
		...processCreateParams(params)
	});
};
var ZodBranded = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		const data = ctx.data;
		return this._def.type._parse({
			data,
			path: ctx.path,
			parent: ctx
		});
	}
	unwrap() {
		return this._def.type;
	}
};
var ZodPipeline = class ZodPipeline extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.common.async) {
			const handleAsync = async () => {
				const inResult = await this._def.in._parseAsync({
					data: ctx.data,
					path: ctx.path,
					parent: ctx
				});
				if (inResult.status === "aborted") return INVALID;
				if (inResult.status === "dirty") {
					status.dirty();
					return DIRTY(inResult.value);
				} else return this._def.out._parseAsync({
					data: inResult.value,
					path: ctx.path,
					parent: ctx
				});
			};
			return handleAsync();
		} else {
			const inResult = this._def.in._parseSync({
				data: ctx.data,
				path: ctx.path,
				parent: ctx
			});
			if (inResult.status === "aborted") return INVALID;
			if (inResult.status === "dirty") {
				status.dirty();
				return {
					status: "dirty",
					value: inResult.value
				};
			} else return this._def.out._parseSync({
				data: inResult.value,
				path: ctx.path,
				parent: ctx
			});
		}
	}
	static create(a, b) {
		return new ZodPipeline({
			in: a,
			out: b,
			typeName: ZodFirstPartyTypeKind.ZodPipeline
		});
	}
};
var ZodReadonly = class extends ZodType {
	_parse(input) {
		const result = this._def.innerType._parse(input);
		const freeze = (data) => {
			if (isValid(data)) data.value = Object.freeze(data.value);
			return data;
		};
		return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
	}
	unwrap() {
		return this._def.innerType;
	}
};
ZodReadonly.create = (type, params) => {
	return new ZodReadonly({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodReadonly,
		...processCreateParams(params)
	});
};
ZodObject.lazycreate;
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind) {
	ZodFirstPartyTypeKind["ZodString"] = "ZodString";
	ZodFirstPartyTypeKind["ZodNumber"] = "ZodNumber";
	ZodFirstPartyTypeKind["ZodNaN"] = "ZodNaN";
	ZodFirstPartyTypeKind["ZodBigInt"] = "ZodBigInt";
	ZodFirstPartyTypeKind["ZodBoolean"] = "ZodBoolean";
	ZodFirstPartyTypeKind["ZodDate"] = "ZodDate";
	ZodFirstPartyTypeKind["ZodSymbol"] = "ZodSymbol";
	ZodFirstPartyTypeKind["ZodUndefined"] = "ZodUndefined";
	ZodFirstPartyTypeKind["ZodNull"] = "ZodNull";
	ZodFirstPartyTypeKind["ZodAny"] = "ZodAny";
	ZodFirstPartyTypeKind["ZodUnknown"] = "ZodUnknown";
	ZodFirstPartyTypeKind["ZodNever"] = "ZodNever";
	ZodFirstPartyTypeKind["ZodVoid"] = "ZodVoid";
	ZodFirstPartyTypeKind["ZodArray"] = "ZodArray";
	ZodFirstPartyTypeKind["ZodObject"] = "ZodObject";
	ZodFirstPartyTypeKind["ZodUnion"] = "ZodUnion";
	ZodFirstPartyTypeKind["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
	ZodFirstPartyTypeKind["ZodIntersection"] = "ZodIntersection";
	ZodFirstPartyTypeKind["ZodTuple"] = "ZodTuple";
	ZodFirstPartyTypeKind["ZodRecord"] = "ZodRecord";
	ZodFirstPartyTypeKind["ZodMap"] = "ZodMap";
	ZodFirstPartyTypeKind["ZodSet"] = "ZodSet";
	ZodFirstPartyTypeKind["ZodFunction"] = "ZodFunction";
	ZodFirstPartyTypeKind["ZodLazy"] = "ZodLazy";
	ZodFirstPartyTypeKind["ZodLiteral"] = "ZodLiteral";
	ZodFirstPartyTypeKind["ZodEnum"] = "ZodEnum";
	ZodFirstPartyTypeKind["ZodEffects"] = "ZodEffects";
	ZodFirstPartyTypeKind["ZodNativeEnum"] = "ZodNativeEnum";
	ZodFirstPartyTypeKind["ZodOptional"] = "ZodOptional";
	ZodFirstPartyTypeKind["ZodNullable"] = "ZodNullable";
	ZodFirstPartyTypeKind["ZodDefault"] = "ZodDefault";
	ZodFirstPartyTypeKind["ZodCatch"] = "ZodCatch";
	ZodFirstPartyTypeKind["ZodPromise"] = "ZodPromise";
	ZodFirstPartyTypeKind["ZodBranded"] = "ZodBranded";
	ZodFirstPartyTypeKind["ZodPipeline"] = "ZodPipeline";
	ZodFirstPartyTypeKind["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
const stringType = ZodString.create;
const numberType = ZodNumber.create;
ZodNaN.create;
ZodBigInt.create;
const booleanType = ZodBoolean.create;
ZodDate.create;
ZodSymbol.create;
ZodUndefined.create;
const nullType = ZodNull.create;
ZodAny.create;
ZodUnknown.create;
ZodNever.create;
ZodVoid.create;
const arrayType = ZodArray.create;
const objectType = ZodObject.create;
ZodObject.strictCreate;
const unionType = ZodUnion.create;
const discriminatedUnionType = ZodDiscriminatedUnion.create;
ZodIntersection.create;
ZodTuple.create;
const recordType = ZodRecord.create;
ZodMap.create;
ZodSet.create;
ZodFunction.create;
ZodLazy.create;
const literalType = ZodLiteral.create;
const enumType = ZodEnum.create;
ZodNativeEnum.create;
ZodPromise.create;
ZodEffects.create;
ZodOptional.create;
ZodNullable.create;
ZodEffects.createWithPreprocess;
ZodPipeline.create;
//#endregion
//#region lib/routines.ts
const identifier = stringType().regex(/^[A-Za-z][A-Za-z0-9_]{0,39}$/);
const routineStepSchema = discriminatedUnionType("type", [
	objectType({
		id: identifier,
		type: literalType("action"),
		command: identifier
	}).strict(),
	objectType({
		id: identifier,
		type: literalType("wait"),
		seconds: numberType().finite().min(.05).max(15)
	}).strict(),
	objectType({
		id: identifier,
		type: enumType([
			"parallel",
			"race",
			"deadline"
		]),
		commands: arrayType(identifier).max(8)
	}).strict()
]);
const routineSchema = objectType({
	id: identifier,
	name: stringType().min(1).max(40),
	timeout: numberType().finite().min(.05).max(15),
	steps: arrayType(routineStepSchema).max(16)
}).strict();
function stepCommands(step) {
	return step.type === "wait" ? [] : step.type === "action" ? [step.command] : step.commands;
}
function routineRequirements(p, r) {
	return [...new Set(r.steps.flatMap(stepCommands).map((id) => p.commands.find((c) => c.id === id)?.subsystem).filter((id) => !!id))];
}
function availableActions(p) {
	return [...p.commands.map((c) => ({
		value: c.id,
		label: c.name
	})), ...(p.routines || []).map((r) => ({
		value: r.id,
		label: r.name + " · routine"
	}))];
}
function validateRoutines(p) {
	const issues = [];
	const error = (message) => issues.push({
		level: "error",
		area: "Logic builder",
		message
	});
	const ids = new Set(p.commands.map((c) => c.id));
	for (const r of p.routines || []) {
		if (ids.has(r.id)) error(`${r.name}: each command and routine needs a unique identifier.`);
		ids.add(r.id);
		if (!r.steps.length) error(`${r.name}: add at least one block.`);
		if (new Set(r.steps.map((s) => s.id)).size !== r.steps.length) error(`${r.name}: duplicate block identifiers.`);
		r.steps.forEach((step, i) => {
			const where = `${r.name}, block ${i + 1}`;
			const commands = stepCommands(step);
			commands.forEach((id) => {
				if (!p.commands.some((c) => c.id === id)) error(`${where}: an action is missing. Routines use individual commands, not other routines.`);
			});
			if (step.type !== "action" && step.type !== "wait") {
				if (commands.length < 2) error(`${where}: a together block needs at least two actions.`);
				const owners = /* @__PURE__ */ new Set();
				for (const id of commands) {
					const c = p.commands.find((c) => c.id === id);
					if (!c) continue;
					if (owners.has(c.subsystem)) error(`${where}: ${p.subsystems.find((s) => s.id === c.subsystem)?.name || c.subsystem} cannot run two actions at once. Move one to the next block.`);
					owners.add(c.subsystem);
				}
			}
		});
		if (routineDuration(p, r) > r.timeout) issues.push({
			level: "warning",
			area: "Logic builder",
			message: `${r.name}: the ${r.timeout}s routine limit can stop later blocks early. Sensors may finish actions sooner.`
		});
	}
	return issues;
}
function routineDuration(p, r) {
	return r.steps.reduce((total, s) => {
		if (s.type === "wait") return total + s.seconds;
		const times = stepCommands(s).map((id) => p.commands.find((c) => c.id === id)?.timeout || 0);
		return total + (s.type === "parallel" ? Math.max(0, ...times) : s.type === "race" ? Math.min(...times, 15) : times[0] || 0);
	}, 0);
}
function stepSummary(p, s) {
	if (s.type === "wait") return `Wait ${s.seconds} seconds`;
	const names = stepCommands(s).map((id) => p.commands.find((c) => c.id === id)?.name || "Missing action");
	if (s.type === "action") return names[0];
	return `${names.join(" + ")} (${s.type === "parallel" ? "finish all" : s.type === "race" ? "finish first" : "first action leads"})`;
}
/** The editor and exported project share these exact factories. Each reference creates a fresh command. */
function routineSource(r, language) {
	const call = (id) => language === "Java" ? `action_${id}()` : language === "C++" ? `Action_${id}()` : `self.action(${JSON.stringify(id)})`;
	const expression = (s) => {
		if (s.type === "action") return call(s.command);
		if (s.type === "wait") return language === "Java" ? `Commands.waitSeconds(${s.seconds})` : language === "C++" ? `frc2::cmd::Wait(units::second_t{${s.seconds}})` : `commands2.cmd.waitSeconds(${s.seconds})`;
		const name = s.type === "parallel" ? "parallel" : s.type === "race" ? "race" : "deadline";
		return (language === "Java" ? `Commands.${name}` : language === "C++" ? `frc2::cmd::${name[0].toUpperCase() + name.slice(1)}` : `commands2.cmd.${name}`) + `(${s.commands.map(call).join(", ")})`;
	};
	const expressions = r.steps.map(expression);
	const name = JSON.stringify(r.name);
	if (language === "Java") return `private Command action_${r.id}() {\n  return Commands.sequence(\n    ${expressions.join(",\n    ")}\n  ).withTimeout(${r.timeout}).withName(${name});\n}`;
	if (language === "C++") return `frc2::CommandPtr Action_${r.id}() {\n  return frc2::cmd::Sequence(\n    ${expressions.join(",\n    ")}\n  ).WithTimeout(units::second_t{${r.timeout}}).WithName(${name});\n}`;
	return `def routine_${r.id}(self):\n    return commands2.cmd.sequence(\n        ${expressions.join(",\n        ")}\n    ).withTimeout(${r.timeout}).withName(${name})`;
}
function logicGuide(p) {
	return "# Robot behavior map\n\nEdit the project in RobotForge and regenerate to keep the visual plan and source aligned. Source edits are not imported back into the visual builder.\n\n## Commands\n\n" + p.commands.map((c) => `- **${c.name}**: ${p.subsystems.find((s) => s.id === c.subsystem)?.name}; output ${c.output}; maximum ${c.timeout}s${c.untilDevice ? "; stop sensor " + (p.devices || []).find((d) => d.id === c.untilDevice)?.name : ""}.`).join("\n") + "\n\n## Routines\n\n" + (p.routines || []).map((r) => `### ${r.name}\nMaximum ${r.timeout}s. Owns: ${routineRequirements(p, r).map((id) => p.subsystems.find((s) => s.id === id)?.name).join(", ") || "no mechanisms"}.\n\n` + r.steps.map((s, i) => `${i + 1}. ${stepSummary(p, s)}`).join("\n")).join("\n\n") + "\n\n## Button assignments\n\n" + p.bindings.map((b) => `- ${b.controller} button ${b.button}: ${availableActions(p).find((a) => a.value === b.command)?.label} (${b.behavior}).`).join("\n") + "\n\nA routine reserves every subsystem used anywhere in it for its full duration, including waits. Another command using one of those subsystems can interrupt the routine. Together blocks cannot share a subsystem. Each action stops its output on end or interruption; a routine timeout cancels its current block. While-held bindings finish at the timeout and need a release and another press to restart. An invalid sensor reading stops its action; it does not automatically cancel later blocks. This plan is not a physics simulation.\n";
}
//#endregion
//#region lib/hardware-catalog.ts
const ctre = "https://v6.docs.ctr-electronics.com/en/stable/docs/hardware-reference/";
const rev = "https://docs.revrobotics.com/";
const wpi = "https://docs.wpilib.org/en/stable/docs/controls-overviews/control-system-hardware.html";
const entries = [];
function add(brand, id, name, category, adapter, connection, description, docs, vendor) {
	entries.push({
		brand,
		id,
		name,
		category,
		adapter,
		connection,
		description,
		docs,
		vendor
	});
}
add("CTRE", "cancoder", "CANcoder", "Encoders", "cancoder", "CAN", "Absolute position in rotations; direction and zero offset. Phoenix 6 firmware.", ctre + "cancoder.html");
add("CTRE", "canrange", "CANrange", "Distance", "canrange", "CAN", "Distance in meters, with status and measurement health.", ctre + "canrange.html");
add("CTRE", "candi", "CANdi", "Sensors", "candi", "CAN", "S1/S2 closed state and quadrature position. Configure input electrical mode in Phoenix Tuner.", ctre + "candi.html");
add("CTRE", "candle", "CANdle", "Lighting", "candle", "CAN", "Solid RGB status color. Requires Phoenix 6 compatible firmware; LED indexes include the 8 onboard LEDs.", ctre + "candle.html");
add("CTRE", "pigeon2", "Pigeon 2", "Gyros", "pigeon", "CAN", "Yaw telemetry. Select the drivetrain heading sensor separately to use it for odometry.", ctre + "pigeon2.html");
add("CTRE", "canivore", "CANivore", "CAN networks", "canbus", "USB / CAN FD", "Named CTRE CAN bus. Add once, then select this bus on Phoenix 6 devices. No CAN ID.", "https://v6.docs.ctr-electronics.com/en/stable/docs/canivore/canivore-intro.html");
add("CTRE", "pigeon1", "Pigeon IMU (original)", "Gyros", "pigeonLegacy", "CAN", "Direct-CAN yaw telemetry using Phoenix 5. Talon-hosted ribbon connection is not generated.", "https://docs.ctre-phoenix.com/en/stable/ch11_BringUpPigeon.html", "phoenix5");
add("CTRE", "cancoder5", "CANCoder (Phoenix 5 firmware)", "Encoders", "custom", "CAN", "Legacy CANCoder was removed from the 2026 Phoenix 5 API. Upgrade compatible firmware and choose the Phoenix 6 CANcoder profile. Export is blocked for this legacy profile.", "https://docs.ctre-phoenix.com/en/stable/ch12a_BringUpCANCoder.html", "phoenix5");
add("CTRE", "srxmag", "SRX Magnetic Encoder", "Encoders", "duty", "DIO", "Absolute duty-cycle output connected directly to roboRIO DIO with the correct breakout. One rotation = 1.", "https://docs.ctre-phoenix.com/en/stable/ch14_MCSensor.html");
add("CTRE", "pdp", "Power Distribution Panel", "Power", "pdp", "CAN", "WPILib voltage, total current, temperature, and channel currents.", wpi);
add("CTRE", "pcm", "Pneumatics Control Module", "Pneumatics", "pcm", "CAN", "Closed-loop compressor enable and pressure-switch telemetry. Add valves separately.", wpi);
add("CTRE", "vrm", "Voltage Regulator Module", "Power", "passive", "Power", "Wiring inventory only. Regulates power; has no CAN address or robot-code API.", wpi);
add("REV Robotics", "pdh", "Power Distribution Hub", "Power", "pdh", "CAN", "WPILib voltage, total current, temperature, and all 24 channel currents.", rev + "ion-control/pdh");
add("REV Robotics", "ph", "Pneumatic Hub", "Pneumatics", "ph", "CAN", "Closed-loop compressor enable and pressure-switch telemetry. Add valves separately.", rev + "ion-control/ph");
add("REV Robotics", "servoHub", "Servo Hub", "Servos", "servoHub", "CAN", "All six servo channels; select a command channel and pulse bounds. Other channels stay disabled.", rev + "ion-control/servo-hub");
add("REV Robotics", "throughbore", "Through Bore Encoder (absolute)", "Encoders", "duty", "DIO", "Absolute duty-cycle position, direction, and zero offset at the roboRIO.", rev + "rev-crossover-products/sensors/tbe");
add("REV Robotics", "throughboreQuad", "Through Bore Encoder (incremental)", "Encoders", "quadrature", "DIO × 2", "Quadrature distance and rate. Set measured distance per decoded count.", rev + "rev-crossover-products/sensors/tbe");
add("REV Robotics", "maglimit", "Magnetic Limit Switch", "Sensors", "digital", "DIO", "Active-low switch state, readable by commands.", rev + "rev-crossover-products/sensors/magnetic-limit-switch");
add("REV Robotics", "touch", "Touch Sensor", "Sensors", "digital", "DIO", "Active-low contact input connected to roboRIO DIO.", rev + "rev-crossover-products/sensors/touch");
add("REV Robotics", "pot", "Potentiometer", "Sensors", "analog", "Analog", "Voltage scaled into mechanism units. Set scale and offset from calibration.", rev + "rev-crossover-products/sensors/potentiometer");
add("REV Robotics", "colorv3", "Color Sensor V3", "Sensors", "color", "I2C", "RGB, infrared and proximity telemetry through REVLib.", rev + "rev-crossover-products/sensors/color-sensor");
add("REV Robotics", "distance2m", "2m Distance Sensor", "Distance", "custom", "I2C", "Requires a separate REV 2m driver. No verified 2026 adapter is bundled; adding this device blocks export until removed.", rev + "rev-crossover-products/sensors/2m-distance/application-examples");
add("REV Robotics", "blinkin", "Blinkin LED Driver", "Lighting", "blinkin", "PWM", "Send the pattern value from REV’s pattern chart (−1 to +1).", rev + "rev-crossover-products/blinkin");
add("REV Robotics", "digitalled", "Digital LED Indicator", "Lighting", "digitalOut", "DIO", "Boolean light output controlled by commands.", rev + "rev-crossover-products");
for (const [id, name, description] of [
	[
		"mpm",
		"Mini Power Module",
		"Fused passive power distribution."
	],
	[
		"rpm",
		"Radio Power Module",
		"Radio power and wiring."
	],
	[
		"spm",
		"Servo Power Module",
		"Pass-through servo power; configure the servo’s roboRIO PWM port separately."
	],
	[
		"poe",
		"PoE Injector / power cable",
		"Power and network wiring."
	],
	[
		"breakout",
		"Sensor breakout / joiner board",
		"Pass-through connector; configure the attached sensor separately."
	]
]) add("REV Robotics", id, name, "Power", "passive", "Power", description + " No robot-code API.", rev + "ion-control");
add("REV Robotics", "servo", "Smart Robot Servo (PWM mode)", "Servos", "servo", "PWM", "Position command (0–1), configurable pulse limits, and disabled output on command end.", rev + "rev-crossover-products/servo");
add("Playing With Fusion", "pwftof", "Time of Flight", "Distance", "tof", "CAN", "Range in meters and valid-reading telemetry.", "https://www.playingwithfusion.com/docs/1205%26catid%3D9012", "pwf");
add("Kauai Labs / Studica", "navx", "navX MXP / navX2 / Micro", "Gyros", "navx", "SPI / USB / I2C", "Heading telemetry via the current Studica navX library. Choose drivetrain navX separately for odometry.", "https://github.com/Studica-Robotics/NavX/", "navx");
for (const model of [
	"2",
	"2+",
	"3",
	"3G",
	"3A",
	"4"
]) add("Limelight", "limelight" + model.replace("+", "plus"), "Limelight " + model, "Vision", "limelight", "NetworkTables", "Target validity, tx/ty, area, latency, and blue-origin pose. Heartbeat freshness checked. Camera calibration and pose fusion are separate.", "https://docs.limelightvision.io/docs/docs-limelight/apis/complete-networktables-api");
add("The Thrifty Bot", "thriftyAbs", "Thrifty Absolute Encoder (analog)", "Encoders", "analogEncoder", "Analog", "Ratiometric analog absolute position in rotations. Match the output mode to the physical encoder.", "https://docs.thethriftybot.com/absolute-encoder");
add("The Thrifty Bot", "thrifty10", "10-Pin Encoder (absolute output)", "Encoders", "duty", "DIO", "Duty-cycle absolute signal via a suitable breakout; verify pinout.", "https://docs.thethriftybot.com/10-pin-encoder");
add("The Thrifty Bot", "thriftyHall", "Hall Effect Sensor", "Sensors", "digital", "DIO", "Active-low magnetic limit input.", "https://docs.thethriftybot.com/");
for (const [id, name] of [
	["laserCAN", "LaserCAN"],
	["mitocandria", "MitoCANdria"],
	["thriftyCANEncoder", "Thrifty Through Bore CAN Encoder"]
]) add("The Thrifty Bot", id, name, "CAN devices", "custom", "CAN", "Requires a dedicated vendor adapter; this device is documented but not yet generated. Adding it blocks export.", "https://docs.thethriftybot.com/");
add("AndyMark", "ammag", "AM Mag / Hall sensor", "Sensors", "digital", "DIO", "Digital magnetic detection through WPILib. Verify wiring and polarity for the exact part.", "https://www.andymark.com/");
add("AndyMark", "lamprey", "Lamprey absolute encoder (PWM output)", "Encoders", "duty", "DIO", "Duty-cycle absolute position. Match output mode and verify the part’s electrical specifications.", "https://www.andymark.com/");
add("AndyMark", "beam", "Beam-break / limit switch", "Sensors", "digital", "DIO", "Digital active-low object detection.", "https://www.andymark.com/");
for (const brand of [
	"AndyMark",
	"VEXpro",
	"WCP",
	"Swerve Drive Specialties"
]) add(brand, brand.replace(/\W/g, "") + "mechanical", "Gearbox / module / mechanical assembly", "Mechanics", "passive", "Mechanical", "Inventory and setup notes only. Configure its motors and encoders individually. Swerve control and geometry are not generated by the differential-drive editor.", brand === "WCP" ? "https://docs.wcproducts.com/" : brand === "Swerve Drive Specialties" ? "https://www.swervedrivespecialties.com/" : brand === "VEXpro" ? "https://www.vexrobotics.com/pro" : "https://www.andymark.com/");
add("VEXpro", "versaplanetary", "VersaPlanetary encoder (quadrature)", "Encoders", "quadrature", "DIO × 2", "WPILib quadrature feedback. Configure distance per decoded count.", "https://www.vexrobotics.com/pro");
add("WCP", "wcpLimit", "Limit / proximity switch (digital)", "Sensors", "digital", "DIO", "Digital state through roboRIO DIO. Verify voltage and active level.", "https://docs.wcproducts.com/");
for (const [id, name, adapter, connection] of [
	[
		"dio",
		"Digital switch / beam break",
		"digital",
		"DIO"
	],
	[
		"duty",
		"Absolute duty-cycle encoder",
		"duty",
		"DIO"
	],
	[
		"quad",
		"Quadrature encoder",
		"quadrature",
		"DIO × 2"
	],
	[
		"analog",
		"Analog sensor / pressure transducer",
		"analog",
		"Analog"
	],
	[
		"ultrasonic",
		"Ultrasonic (ping / echo)",
		"ultrasonic",
		"DIO × 2"
	],
	[
		"servoPWM",
		"PWM servo",
		"servo",
		"PWM"
	]
]) add("Standard WPILib", id, name, "General I/O", adapter, connection, "Generic electrical interface. Verify wiring, calibration, and operating range for your exact part.", wpi);
for (const [id, name, adapter] of [
	[
		"singleRev",
		"Single solenoid on REV PH",
		"solenoidRev"
	],
	[
		"doubleRev",
		"Double solenoid on REV PH",
		"doubleRev"
	],
	[
		"singleCtre",
		"Single solenoid on CTRE PCM",
		"solenoidCtre"
	],
	[
		"doubleCtre",
		"Double solenoid on CTRE PCM",
		"doubleCtre"
	]
]) add("Standard WPILib", id, name, "Pneumatics", adapter, "Module channel", "Uses a configured hub/module. Single: positive = on. Double: positive = forward, negative = reverse, zero = off.", wpi);
const hardwareCatalog = entries;
const productById = (id) => hardwareCatalog.find((p) => p.id === id);
const isActuator = (a) => [
	"candle",
	"servoHub",
	"servo",
	"blinkin",
	"digitalOut",
	"solenoidRev",
	"solenoidCtre",
	"doubleRev",
	"doubleCtre"
].includes(a);
const isSensor = (a) => [
	"cancoder",
	"canrange",
	"candi",
	"pigeon",
	"pigeonLegacy",
	"encoderLegacy",
	"navx",
	"digital",
	"duty",
	"quadrature",
	"analog",
	"analogEncoder",
	"ultrasonic",
	"color",
	"tof",
	"limelight"
].includes(a);
const n = numberType().finite();
const busName = stringType().regex(/^[A-Za-z0-9_-]{1,40}$/);
const deviceSchema = objectType({
	id: stringType().regex(/^[A-Za-z][A-Za-z0-9_]{0,39}$/),
	product: stringType().max(60),
	name: stringType().min(1).max(60),
	subsystem: stringType().max(40),
	bus: busName,
	address: n.int().min(0).max(62),
	channel: n.int().min(0).max(25),
	channelB: n.int().min(0).max(25),
	module: stringType().max(40),
	inverted: booleanType(),
	offset: n.min(-1e4).max(1e4),
	scale: n.min(1e-7).max(1e4),
	count: n.int().min(1).max(400),
	table: stringType().regex(/^[A-Za-z][A-Za-z0-9_-]{0,49}$/),
	interface: enumType([
		"onboard",
		"mxp",
		"usb1",
		"usb2"
	]),
	compressor: booleanType(),
	red: n.int().min(0).max(255),
	green: n.int().min(0).max(255),
	blue: n.int().min(0).max(255),
	pulseMin: n.int().min(500).max(2500),
	pulseMax: n.int().min(500).max(2500),
	notes: stringType().max(500)
}).strict();
//#endregion
//#region lib/hardware-validation.ts
function validateHardware(p) {
	const issues = [];
	const error = (message) => issues.push({
		level: "error",
		area: "Hardware",
		message
	});
	const used = /* @__PURE__ */ new Map();
	const claim = (key, name) => {
		if (used.has(key)) error(`${key} is shared by ${used.get(key)} and ${name}.`);
		else used.set(key, name);
	};
	if (new Set(p.motors.filter((m) => m.subsystem === "drive").map((m) => m.motorKind || "default")).size > 1) error("All drive motors must use the same physical motor model.");
	const devices = p.devices || [];
	const buses = new Set(["rio"]);
	for (const d of devices.filter((d) => productById(d.product)?.adapter === "canbus")) {
		if (buses.has(d.bus)) error(`CANivore bus names must be unique and cannot be rio (${d.name}).`);
		buses.add(d.bus);
	}
	const can = (bus, id, name, ctre = false) => {
		if (!buses.has(bus)) error(`${name}: add CANivore “${bus}” first.`);
		if (bus !== "rio" && !ctre) error(`${name} must use roboRIO CAN; its API does not support CANivore.`);
		claim(`CAN ${bus}:${id}`, name);
	};
	for (const m of p.motors) {
		if (m.type.startsWith("PWM")) {
			if (m.can > 19) error(`${m.name}: PWM channel must be 0–19.`);
			claim(`PWM ${m.can}`, m.name);
		} else can(m.bus || "rio", m.can, m.name, ["TalonFX", "TalonFXS"].includes(m.type));
		if (m.limit >= 0) claim(`DIO ${m.limit}`, m.name + " forward limit");
		if (!(m.type === "TalonFX" ? ["default", "falcon"] : m.type === "TalonFXS" ? [
			"default",
			"minion",
			"neo",
			"brushed"
		] : m.type === "ThriftyNova" ? [
			"default",
			"neo",
			"minion",
			"brushed"
		] : m.type.startsWith("Spark") ? ["default", "brushed"] : ["default"]).includes(m.motorKind || "default")) error(m.name + ": choose a motor model supported by this controller.");
		if (m.subsystem === "drive" && m.motorKind === "brushed") error(m.name + ": integrated drivetrain feedback requires a brushless motor.");
		if (m.type === "ThriftyNova" && p.language !== "Java") error(`${m.name}: ThriftyLib provides a Java adapter only. Select Java or another controller.`);
		if (m.subsystem === "drive" && ![
			"SparkMax",
			"SparkFlex",
			"TalonFX"
		].includes(m.type)) error(`${m.name}: this controller is supported for mechanism commands; drivetrain odometry currently requires SPARK MAX, Flex, or Talon FX.`);
	}
	if (p.drive.gyro === "Pigeon2") can(p.drive.gyroBus || "rio", p.drive.gyroCan, "Drive Pigeon 2", true);
	if (p.drive.gyro === "NavX") claim(`navx ${p.drive.navxInterface || "mxp"}`, "Drive navX");
	for (const d of devices) {
		const product = productById(d.product);
		if (!product) {
			error(`${d.name}: unknown hardware product.`);
			continue;
		}
		const a = product.adapter;
		if (!p.subsystems.some((s) => s.id === d.subsystem)) error(`${d.name}: choose an existing subsystem.`);
		if (a === "custom") error(`${d.name}: a verified ${p.language} adapter is not available. Remove this device before export; see its integration guide.`);
		if (product.connection === "CAN") can(d.bus, d.address, d.name, [
			"cancoder",
			"canrange",
			"candi",
			"candle",
			"pigeon"
		].includes(a));
		if (a === "navx") claim(`navx ${d.interface}`, d.name);
		if ([
			"digital",
			"digitalOut",
			"duty",
			"quadrature",
			"ultrasonic"
		].includes(a)) {
			claim(`DIO ${d.channel}`, d.name);
			if (d.channel > 25) error(`${d.name}: invalid DIO channel.`);
		}
		if (["quadrature", "ultrasonic"].includes(a)) claim(`DIO ${d.channelB}`, d.name);
		if (["analog", "analogEncoder"].includes(a)) {
			claim(`Analog ${d.channel}`, d.name);
			if (d.channel > 7) error(`${d.name}: analog channel must be 0–7.`);
		}
		if (["servo", "blinkin"].includes(a)) {
			claim(`PWM ${d.channel}`, d.name);
			if (d.channel > 19) error(`${d.name}: PWM channel must be 0–19.`);
		}
		if (a === "servoHub" && d.channel > 5) error(`${d.name}: Servo Hub channel must be 0–5.`);
		if (["servo", "servoHub"].includes(a) && d.pulseMin >= d.pulseMax) error(`${d.name}: minimum pulse must be below maximum pulse.`);
		if (a === "candle" && d.count > 400) error(`${d.name}: CANdle supports LED indexes 0–399.`);
		if (a === "color") {
			if (!["onboard", "mxp"].includes(d.interface)) error(`${d.name}: choose an I2C port.`);
			claim(`I2C ${d.interface}:0x52`, d.name);
		}
		if (a === "limelight") claim(`NetworkTables ${d.table}`, d.name);
		if ([
			"solenoidRev",
			"solenoidCtre",
			"doubleRev",
			"doubleCtre"
		].includes(a)) {
			const hub = devices.find((h) => h.id === d.module);
			const expected = a.endsWith("Rev") ? "ph" : "pcm";
			if (!hub || productById(hub.product)?.adapter !== expected) error(`${d.name}: select the matching ${expected === "ph" ? "REV Pneumatic Hub" : "CTRE PCM"} in this project.`);
			const max = expected === "ph" ? 15 : 7;
			(a.startsWith("double") ? [d.channel, d.channelB] : [d.channel]).forEach((ch) => {
				if (ch > max) error(`${d.name}: valve channel must be 0–${max}.`);
				claim(`Valve ${d.module}:${ch}`, d.name);
			});
		}
	}
	if (new Set(devices.map((d) => d.id)).size !== devices.length) error("Duplicate hardware identifiers.");
	for (const c of p.commands) {
		if (c.device) {
			const d = devices.find((d) => d.id === c.device);
			if (!d || !isActuator(productById(d.product)?.adapter || "passive")) error(`${c.name}: choose an output device.`);
			else {
				if (d.subsystem !== c.subsystem) error(`${c.name}: output device must belong to the command’s subsystem.`);
				if (["servo", "servoHub"].includes(productById(d.product).adapter) && c.output < 0) error(`${c.name}: servo position must be between 0 and 1.`);
			}
		}
		if (c.untilDevice) {
			const d = devices.find((d) => d.id === c.untilDevice);
			if (!d || !isSensor(productById(d.product)?.adapter || "passive")) error(`${c.name}: choose a valid stop sensor.`);
		}
	}
	return issues;
}
//#endregion
//#region lib/bundled-libraries.json
var vendors = {
	"rev": {
		"manifest": {
			"fileName": "REVLib.json",
			"name": "REVLib",
			"version": "2026.0.5",
			"frcYear": "2026",
			"uuid": "3f48eb8c-50fe-43a6-9cb7-44c86353c4cb",
			"mavenUrls": ["https://maven.revrobotics.com/"],
			"jsonUrl": "https://software-metadata.revrobotics.com/REVLib-2026.json",
			"javaDependencies": [{
				"groupId": "com.revrobotics.frc",
				"artifactId": "REVLib-java",
				"version": "2026.0.5"
			}],
			"jniDependencies": [
				{
					"groupId": "com.revrobotics.frc",
					"artifactId": "REVLib-driver",
					"version": "2026.0.5",
					"skipInvalidPlatforms": true,
					"isJar": false,
					"validPlatforms": [
						"windowsx86-64",
						"linuxarm64",
						"linuxx86-64",
						"linuxathena",
						"linuxarm32",
						"osxuniversal"
					]
				},
				{
					"groupId": "com.revrobotics.frc",
					"artifactId": "RevLibBackendDriver",
					"version": "2026.0.5",
					"skipInvalidPlatforms": true,
					"isJar": false,
					"validPlatforms": [
						"windowsx86-64",
						"linuxarm64",
						"linuxx86-64",
						"linuxathena",
						"linuxarm32",
						"osxuniversal"
					]
				},
				{
					"groupId": "com.revrobotics.frc",
					"artifactId": "RevLibWpiBackendDriver",
					"version": "2026.0.5",
					"skipInvalidPlatforms": true,
					"isJar": false,
					"validPlatforms": [
						"windowsx86-64",
						"linuxarm64",
						"linuxx86-64",
						"linuxathena",
						"linuxarm32",
						"osxuniversal"
					]
				}
			],
			"cppDependencies": [
				{
					"groupId": "com.revrobotics.frc",
					"artifactId": "REVLib-cpp",
					"version": "2026.0.5",
					"libName": "REVLib",
					"headerClassifier": "headers",
					"sharedLibrary": false,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxarm64",
						"linuxx86-64",
						"linuxathena",
						"linuxarm32",
						"osxuniversal"
					]
				},
				{
					"groupId": "com.revrobotics.frc",
					"artifactId": "REVLib-driver",
					"version": "2026.0.5",
					"libName": "REVLibDriver",
					"headerClassifier": "headers",
					"sharedLibrary": false,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxarm64",
						"linuxx86-64",
						"linuxathena",
						"linuxarm32",
						"osxuniversal"
					]
				},
				{
					"groupId": "com.revrobotics.frc",
					"artifactId": "RevLibBackendDriver",
					"version": "2026.0.5",
					"libName": "BackendDriver",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxarm64",
						"linuxx86-64",
						"linuxathena",
						"linuxarm32",
						"osxuniversal"
					]
				},
				{
					"groupId": "com.revrobotics.frc",
					"artifactId": "RevLibWpiBackendDriver",
					"version": "2026.0.5",
					"libName": "REVLibWpi",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxarm64",
						"linuxx86-64",
						"linuxathena",
						"linuxarm32",
						"osxuniversal"
					]
				}
			]
		},
		"python": "2026.0.4"
	},
	"ctre": {
		"manifest": {
			"fileName": "Phoenix6-frc2026-latest.json",
			"name": "CTRE-Phoenix (v6)",
			"version": "26.3.0",
			"frcYear": "2026",
			"uuid": "e995de00-2c64-4df5-8831-c1441420ff19",
			"mavenUrls": ["https://maven.ctr-electronics.com/release/"],
			"jsonUrl": "https://maven.ctr-electronics.com/release/com/ctre/phoenix6/latest/Phoenix6-frc2026-latest.json",
			"conflictsWith": [{
				"uuid": "e7900d8d-826f-4dca-a1ff-182f658e98af",
				"errorMessage": "Users can not have both the replay and regular Phoenix 6 vendordeps in their robot program.",
				"offlineFileName": "Phoenix6-replay-frc2026-latest.json"
			}],
			"javaDependencies": [{
				"groupId": "com.ctre.phoenix6",
				"artifactId": "wpiapi-java",
				"version": "26.3.0"
			}],
			"jniDependencies": [
				{
					"groupId": "com.ctre.phoenix6",
					"artifactId": "api-cpp",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"linuxathena"
					],
					"simMode": "hwsim"
				},
				{
					"groupId": "com.ctre.phoenix6",
					"artifactId": "tools",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"linuxathena"
					],
					"simMode": "hwsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "api-cpp-sim",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "tools-sim",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simTalonSRX",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simVictorSPX",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simPigeonIMU",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProTalonFX",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProTalonFXS",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProCANcoder",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProPigeon2",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProCANrange",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProCANdi",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProCANdle",
					"version": "26.3.0",
					"isJar": false,
					"skipInvalidPlatforms": true,
					"validPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				}
			],
			"cppDependencies": [
				{
					"groupId": "com.ctre.phoenix6",
					"artifactId": "wpiapi-cpp",
					"version": "26.3.0",
					"libName": "CTRE_Phoenix6_WPI",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"linuxathena"
					],
					"simMode": "hwsim"
				},
				{
					"groupId": "com.ctre.phoenix6",
					"artifactId": "tools",
					"version": "26.3.0",
					"libName": "CTRE_PhoenixTools",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"linuxathena"
					],
					"simMode": "hwsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "wpiapi-cpp-sim",
					"version": "26.3.0",
					"libName": "CTRE_Phoenix6_WPISim",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "tools-sim",
					"version": "26.3.0",
					"libName": "CTRE_PhoenixTools_Sim",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simTalonSRX",
					"version": "26.3.0",
					"libName": "CTRE_SimTalonSRX",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simVictorSPX",
					"version": "26.3.0",
					"libName": "CTRE_SimVictorSPX",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simPigeonIMU",
					"version": "26.3.0",
					"libName": "CTRE_SimPigeonIMU",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProTalonFX",
					"version": "26.3.0",
					"libName": "CTRE_SimProTalonFX",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProTalonFXS",
					"version": "26.3.0",
					"libName": "CTRE_SimProTalonFXS",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProCANcoder",
					"version": "26.3.0",
					"libName": "CTRE_SimProCANcoder",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProPigeon2",
					"version": "26.3.0",
					"libName": "CTRE_SimProPigeon2",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProCANrange",
					"version": "26.3.0",
					"libName": "CTRE_SimProCANrange",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProCANdi",
					"version": "26.3.0",
					"libName": "CTRE_SimProCANdi",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix6.sim",
					"artifactId": "simProCANdle",
					"version": "26.3.0",
					"libName": "CTRE_SimProCANdle",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				}
			]
		},
		"python": "26.3.0"
	},
	"pathplanner": {
		"manifest": {
			"fileName": "PathplannerLib.json",
			"name": "PathplannerLib",
			"version": "2026.1.2",
			"uuid": "1b42324f-17c6-4875-8e77-1c312bc8c786",
			"frcYear": "2026",
			"mavenUrls": ["https://3015rangerrobotics.github.io/pathplannerlib/repo"],
			"jsonUrl": "https://3015rangerrobotics.github.io/pathplannerlib/PathplannerLib.json",
			"javaDependencies": [{
				"groupId": "com.pathplanner.lib",
				"artifactId": "PathplannerLib-java",
				"version": "2026.1.2"
			}],
			"jniDependencies": [],
			"cppDependencies": [{
				"groupId": "com.pathplanner.lib",
				"artifactId": "PathplannerLib-cpp",
				"version": "2026.1.2",
				"libName": "PathplannerLib",
				"headerClassifier": "headers",
				"sharedLibrary": false,
				"skipInvalidPlatforms": true,
				"binaryPlatforms": [
					"windowsx86-64",
					"linuxx86-64",
					"osxuniversal",
					"linuxathena",
					"linuxarm32",
					"linuxarm64"
				]
			}]
		},
		"python": "2026.1.2"
	},
	"pwf": {
		"manifest": {
			"fileName": "playingwithfusion2026.json",
			"name": "PlayingWithFusion",
			"version": "2026.5.08",
			"uuid": "14b8ad04-24df-11ea-978f-2e728ce88125",
			"frcYear": "2026",
			"jsonUrl": "https://www.playingwithfusion.com/frc/playingwithfusion2026.json",
			"mavenUrls": ["https://www.playingwithfusion.com/frc/maven/"],
			"javaDependencies": [{
				"groupId": "com.playingwithfusion.frc",
				"artifactId": "PlayingWithFusion-java",
				"version": "2026.5.08"
			}],
			"jniDependencies": [{
				"groupId": "com.playingwithfusion.frc",
				"artifactId": "PlayingWithFusion-driver",
				"version": "2026.5.08",
				"skipInvalidPlatforms": true,
				"isJar": false,
				"validPlatforms": [
					"windowsx86-64",
					"linuxarm64",
					"linuxx86-64",
					"linuxathena",
					"linuxarm32",
					"osxuniversal"
				]
			}],
			"cppDependencies": [{
				"groupId": "com.playingwithfusion.frc",
				"artifactId": "PlayingWithFusion-cpp",
				"version": "2026.5.08",
				"libName": "PlayingWithFusion",
				"headerClassifier": "headers",
				"sharedLibrary": false,
				"skipInvalidPlatforms": true,
				"binaryPlatforms": [
					"windowsx86-64",
					"linuxarm64",
					"linuxx86-64",
					"linuxathena",
					"linuxarm32",
					"osxuniversal"
				]
			}, {
				"groupId": "com.playingwithfusion.frc",
				"artifactId": "PlayingWithFusion-driver",
				"version": "2026.5.08",
				"libName": "PlayingWithFusionDriver",
				"headerClassifier": "headers",
				"sharedLibrary": true,
				"skipInvalidPlatforms": true,
				"binaryPlatforms": [
					"windowsx86-64",
					"linuxarm64",
					"linuxx86-64",
					"linuxathena",
					"linuxarm32",
					"osxuniversal"
				]
			}]
		},
		"python": "2026.2.13.1"
	},
	"navx": {
		"manifest": {
			"fileName": "Studica.json",
			"name": "Studica",
			"version": "2026.0.0",
			"frcYear": "2026",
			"uuid": "cb311d09-36e9-4143-a032-55bb2b94443b",
			"mavenUrls": ["https://dev.studica.com/maven/release/2026/"],
			"jsonUrl": "https://dev.studica.com/maven/release/2026/json/Studica-2026.0.0.json",
			"javaDependencies": [{
				"groupId": "com.studica.frc",
				"artifactId": "Studica-java",
				"version": "2026.0.0"
			}],
			"jniDependencies": [{
				"groupId": "com.studica.frc",
				"artifactId": "Studica-driver",
				"version": "2026.0.0",
				"skipInvalidPlatforms": true,
				"isJar": false,
				"validPlatforms": [
					"windowsx86-64",
					"linuxarm64",
					"linuxx86-64",
					"linuxathena",
					"linuxarm32",
					"osxuniversal"
				]
			}],
			"cppDependencies": [{
				"groupId": "com.studica.frc",
				"artifactId": "Studica-cpp",
				"version": "2026.0.0",
				"libName": "Studica",
				"headerClassifier": "headers",
				"sharedLibrary": false,
				"skipInvalidPlatforms": true,
				"binaryPlatforms": [
					"windowsx86-64",
					"linuxarm64",
					"linuxx86-64",
					"linuxathena",
					"linuxarm32",
					"osxuniversal"
				]
			}, {
				"groupId": "com.studica.frc",
				"artifactId": "Studica-driver",
				"version": "2026.0.0",
				"libName": "StudicaDriver",
				"headerClassifier": "headers",
				"sharedLibrary": false,
				"skipInvalidPlatforms": true,
				"binaryPlatforms": [
					"windowsx86-64",
					"linuxarm64",
					"linuxx86-64",
					"linuxathena",
					"linuxarm32",
					"osxuniversal"
				]
			}]
		},
		"python": "2026.0.1.2"
	},
	"photonvision": {
		"manifest": {
			"fileName": "photonlib.json",
			"name": "photonlib",
			"version": "v2026.3.4",
			"uuid": "515fe07e-bfc6-11fa-b3de-0242ac130004",
			"frcYear": "2026",
			"mavenUrls": ["https://maven.photonvision.org/repository/internal", "https://maven.photonvision.org/repository/snapshots"],
			"jsonUrl": "https://maven.photonvision.org/repository/internal/org/photonvision/photonlib-json/1.0/photonlib-json-1.0.json",
			"jniDependencies": [{
				"groupId": "org.photonvision",
				"artifactId": "photontargeting-cpp",
				"version": "v2026.3.4",
				"skipInvalidPlatforms": true,
				"isJar": false,
				"validPlatforms": [
					"windowsx86-64",
					"linuxathena",
					"linuxx86-64",
					"osxuniversal"
				]
			}],
			"cppDependencies": [{
				"groupId": "org.photonvision",
				"artifactId": "photonlib-cpp",
				"version": "v2026.3.4",
				"libName": "photonlib",
				"headerClassifier": "headers",
				"sharedLibrary": true,
				"skipInvalidPlatforms": true,
				"binaryPlatforms": [
					"windowsx86-64",
					"linuxathena",
					"linuxx86-64",
					"osxuniversal"
				]
			}, {
				"groupId": "org.photonvision",
				"artifactId": "photontargeting-cpp",
				"version": "v2026.3.4",
				"libName": "photontargeting",
				"headerClassifier": "headers",
				"sharedLibrary": true,
				"skipInvalidPlatforms": true,
				"binaryPlatforms": [
					"windowsx86-64",
					"linuxathena",
					"linuxx86-64",
					"osxuniversal"
				]
			}],
			"javaDependencies": [{
				"groupId": "org.photonvision",
				"artifactId": "photonlib-java",
				"version": "v2026.3.4"
			}, {
				"groupId": "org.photonvision",
				"artifactId": "photontargeting-java",
				"version": "v2026.3.4"
			}]
		},
		"python": "2026.3.4"
	},
	"phoenix5": {
		"manifest": {
			"fileName": "Phoenix5-frc2026-latest.json",
			"name": "CTRE-Phoenix (v5)",
			"version": "5.36.0",
			"frcYear": "2026",
			"uuid": "ab676553-b602-441f-a38d-f1296eff6537",
			"mavenUrls": ["https://maven.ctr-electronics.com/release/"],
			"jsonUrl": "https://maven.ctr-electronics.com/release/com/ctre/phoenix/Phoenix5-frc2026-latest.json",
			"requires": [{
				"uuid": "e995de00-2c64-4df5-8831-c1441420ff19",
				"errorMessage": "Phoenix 5 requires low-level libraries from Phoenix 6.  Please add the Phoenix 6 vendordep before adding Phoenix 5.",
				"offlineFileName": "Phoenix6-frc2026-latest.json",
				"onlineUrl": "https://maven.ctr-electronics.com/release/com/ctre/phoenix6/latest/Phoenix6-frc2026-latest.json"
			}],
			"conflictsWith": [{
				"uuid": "e7900d8d-826f-4dca-a1ff-182f658e98af",
				"errorMessage": "Users must use the Phoenix 5 replay vendordep when using the Phoenix 6 replay vendordep.",
				"offlineFileName": "Phoenix6-replay-frc2026-latest.json"
			}, {
				"uuid": "fbc886a4-2cec-40c0-9835-71086a8cc3df",
				"errorMessage": "Users cannot have both the replay and regular Phoenix 5 vendordeps in their robot program.",
				"offlineFileName": "Phoenix5-replay-frc2026-latest.json"
			}],
			"javaDependencies": [{
				"groupId": "com.ctre.phoenix",
				"artifactId": "api-java",
				"version": "5.36.0"
			}, {
				"groupId": "com.ctre.phoenix",
				"artifactId": "wpiapi-java",
				"version": "5.36.0"
			}],
			"jniDependencies": [{
				"groupId": "com.ctre.phoenix",
				"artifactId": "cci",
				"version": "5.36.0",
				"isJar": false,
				"skipInvalidPlatforms": true,
				"validPlatforms": [
					"windowsx86-64",
					"linuxx86-64",
					"linuxarm64",
					"linuxathena"
				],
				"simMode": "hwsim"
			}, {
				"groupId": "com.ctre.phoenix.sim",
				"artifactId": "cci-sim",
				"version": "5.36.0",
				"isJar": false,
				"skipInvalidPlatforms": true,
				"validPlatforms": [
					"windowsx86-64",
					"linuxx86-64",
					"linuxarm64",
					"osxuniversal"
				],
				"simMode": "swsim"
			}],
			"cppDependencies": [
				{
					"groupId": "com.ctre.phoenix",
					"artifactId": "wpiapi-cpp",
					"version": "5.36.0",
					"libName": "CTRE_Phoenix_WPI",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"linuxathena"
					],
					"simMode": "hwsim"
				},
				{
					"groupId": "com.ctre.phoenix",
					"artifactId": "api-cpp",
					"version": "5.36.0",
					"libName": "CTRE_Phoenix",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"linuxathena"
					],
					"simMode": "hwsim"
				},
				{
					"groupId": "com.ctre.phoenix",
					"artifactId": "cci",
					"version": "5.36.0",
					"libName": "CTRE_PhoenixCCI",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"linuxathena"
					],
					"simMode": "hwsim"
				},
				{
					"groupId": "com.ctre.phoenix.sim",
					"artifactId": "wpiapi-cpp-sim",
					"version": "5.36.0",
					"libName": "CTRE_Phoenix_WPISim",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix.sim",
					"artifactId": "api-cpp-sim",
					"version": "5.36.0",
					"libName": "CTRE_PhoenixSim",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				},
				{
					"groupId": "com.ctre.phoenix.sim",
					"artifactId": "cci-sim",
					"version": "5.36.0",
					"libName": "CTRE_PhoenixCCISim",
					"headerClassifier": "headers",
					"sharedLibrary": true,
					"skipInvalidPlatforms": true,
					"binaryPlatforms": [
						"windowsx86-64",
						"linuxx86-64",
						"linuxarm64",
						"osxuniversal"
					],
					"simMode": "swsim"
				}
			]
		},
		"python": "2026.1.0.1"
	},
	"thrifty": {
		"manifest": {
			"fileName": "ThriftyLib-2026.json",
			"name": "ThriftyLib",
			"version": "2026.1.2",
			"frcYear": "2026",
			"uuid": "60b2694b-9e6e-4026-81ee-6f167946f4b0",
			"mavenUrls": ["https://docs.home.thethriftybot.com"],
			"jsonUrl": "https://docs.home.thethriftybot.com/ThriftyLib-2026.json",
			"javaDependencies": [{
				"groupId": "com.thethriftybot.frc",
				"artifactId": "ThriftyLib-java",
				"version": "2026.1.2"
			}],
			"jniDependencies": [],
			"cppDependencies": []
		},
		"python": null
	}
};
var bundled_libraries_default = {
	season: 2026,
	checkedAt: "2026-09-28T19:49:39.889Z",
	wpilib: "2026.2.1",
	robotpy: "2026.2.2",
	vendors
};
//#endregion
//#region lib/libraries.ts
const SEASON = 2026;
const stableVersion = /^v?\d+(?:\.\d+){1,3}$/;
const version = stringType().max(40).regex(stableVersion);
const vendorIds = [
	"rev",
	"ctre",
	"pathplanner",
	"pwf",
	"navx",
	"photonvision",
	"phoenix5",
	"thrifty"
];
const vendorId = enumType(vendorIds);
const vendorRegistry = {
	phoenix5: {
		name: "CTRE Phoenix 5",
		description: "Talon SRX, Victor SPX, original Pigeon, legacy CANCoder",
		file: "Phoenix5.json",
		uuid: "ab676553-b602-441f-a38d-f1296eff6537",
		feed: "https://maven.ctr-electronics.com/release/com/ctre/phoenix/Phoenix5-frc2026-latest.json",
		prefix: "Phoenix5-",
		group: "com.ctre",
		repositories: ["https://maven.ctr-electronics.com/release/"],
		python: "robotpy-ctre",
		docs: "https://docs.ctre-phoenix.com/",
		required: false
	},
	thrifty: {
		name: "ThriftyLib",
		description: "Thrifty Nova motor controller — Java only",
		file: "ThriftyLib.json",
		uuid: "60b2694b-9e6e-4026-81ee-6f167946f4b0",
		feed: "https://docs.home.thethriftybot.com/ThriftyLib-2026.json",
		prefix: "ThriftyLib-",
		group: "com.thethriftybot.frc",
		repositories: ["https://docs.home.thethriftybot.com"],
		python: "",
		docs: "https://docs.thethriftybot.com/",
		required: false
	},
	rev: {
		name: "REVLib",
		description: "SPARK MAX, SPARK Flex, and REV sensors",
		file: "REVLib.json",
		uuid: "3f48eb8c-50fe-43a6-9cb7-44c86353c4cb",
		feed: "https://software-metadata.revrobotics.com/REVLib-2026.json",
		prefix: "REVLib-",
		group: "com.revrobotics.frc",
		repositories: ["https://maven.revrobotics.com/"],
		python: "robotpy-rev",
		docs: "https://docs.revrobotics.com/revlib",
		required: true
	},
	ctre: {
		name: "CTRE Phoenix 6",
		description: "Talon FX, CANcoder, and Pigeon 2",
		file: "Phoenix6.json",
		uuid: "e995de00-2c64-4df5-8831-c1441420ff19",
		feed: "https://maven.ctr-electronics.com/release/com/ctre/phoenix6/latest/Phoenix6-frc2026-latest.json",
		prefix: "Phoenix6-",
		group: "com.ctre",
		repositories: ["https://maven.ctr-electronics.com/release/"],
		python: "phoenix6",
		docs: "https://v6.docs.ctr-electronics.com/",
		required: true
	},
	pathplanner: {
		name: "PathPlanner",
		description: "Autonomous paths and robot-side following",
		file: "PathplannerLib.json",
		uuid: "1b42324f-17c6-4875-8e77-1c312bc8c786",
		feed: "https://3015rangerrobotics.github.io/pathplannerlib/PathplannerLib.json",
		prefix: "PathplannerLib-",
		group: "com.pathplanner.lib",
		repositories: ["https://3015rangerrobotics.github.io/pathplannerlib/repo"],
		python: "robotpy-pathplannerlib",
		docs: "https://pathplanner.dev/",
		required: true
	},
	pwf: {
		name: "Playing With Fusion",
		description: "Time of Flight sensors, Venom, and PWF devices",
		file: "PlayingWithFusion.json",
		uuid: "14b8ad04-24df-11ea-978f-2e728ce88125",
		feed: "https://www.playingwithfusion.com/frc/playingwithfusion2026.json",
		prefix: "PlayingWithFusion-",
		group: "com.playingwithfusion.frc",
		repositories: ["https://www.playingwithfusion.com/frc/maven/"],
		python: "robotpy-playingwithfusion",
		docs: "https://www.playingwithfusion.com/static/frc.php",
		required: false
	},
	navx: {
		name: "Studica navX",
		description: "NavX MXP and Micro navigation sensors",
		file: "Studica.json",
		uuid: "cb311d09-36e9-4143-a032-55bb2b94443b",
		feed: "",
		prefix: "Studica-",
		group: "com.studica.frc",
		repositories: ["https://dev.studica.com/maven/release/2026/"],
		python: "robotpy-navx",
		docs: "https://github.com/Studica-Robotics/NavX/",
		required: false
	},
	photonvision: {
		name: "PhotonVision",
		description: "Camera results, AprilTags, and vision measurements",
		file: "photonlib.json",
		uuid: "515fe07e-bfc6-11fa-b3de-0242ac130004",
		feed: "",
		prefix: "photonlib-",
		group: "org.photonvision",
		repositories: ["https://maven.photonvision.org/repository/internal", "https://maven.photonvision.org/repository/snapshots"],
		python: "photonlibpy",
		docs: "https://docs.photonvision.org/",
		required: false
	}
};
const atom = stringType().regex(/^[A-Za-z0-9_.+-]+$/).max(120);
const dependency = objectType({
	groupId: atom,
	artifactId: atom,
	version,
	libName: atom.optional(),
	headerClassifier: atom.optional(),
	sourcesClassifier: atom.optional(),
	sharedLibrary: booleanType().optional(),
	skipInvalidPlatforms: booleanType().optional(),
	isJar: booleanType().optional(),
	validPlatforms: arrayType(atom).max(30).optional(),
	binaryPlatforms: arrayType(atom).max(30).optional(),
	simMode: atom.optional()
}).strict();
const manifestSchema = objectType({
	fileName: stringType().regex(/^[A-Za-z0-9_.-]+\.json$/),
	name: stringType().min(1).max(100),
	version,
	frcYear: unionType([literalType("2026"), literalType(2026)]),
	uuid: stringType().uuid(),
	mavenUrls: arrayType(stringType().url()).max(6),
	jsonUrl: stringType().max(500),
	requires: arrayType(objectType({
		uuid: stringType().uuid(),
		errorMessage: stringType().max(500),
		offlineFileName: stringType().regex(/^[A-Za-z0-9_.-]+\.json$/),
		onlineUrl: stringType().url()
	}).strict()).max(5).optional(),
	conflictsWith: arrayType(objectType({
		uuid: stringType().uuid(),
		errorMessage: stringType().max(500),
		offlineFileName: stringType().regex(/^[A-Za-z0-9_.-]+\.json$/)
	}).strict()).max(10).optional(),
	javaDependencies: arrayType(dependency).max(30),
	jniDependencies: arrayType(dependency).max(50),
	cppDependencies: arrayType(dependency).max(50)
}).strict();
const libraryLockSchema = objectType({
	season: literalType(2026),
	legacyPhoenix6: version.default("26.1.3"),
	checkedAt: stringType().max(50),
	wpilib: version,
	robotpy: version,
	vendors: objectType({
		phoenix5: objectType({
			manifest: manifestSchema,
			python: version
		}).default(vendors.phoenix5),
		thrifty: objectType({
			manifest: manifestSchema,
			python: nullType()
		}).default(vendors.thrifty),
		rev: objectType({
			manifest: manifestSchema,
			python: version
		}),
		ctre: objectType({
			manifest: manifestSchema,
			python: version
		}),
		pathplanner: objectType({
			manifest: manifestSchema,
			python: version
		}),
		pwf: objectType({
			manifest: manifestSchema,
			python: version
		}),
		navx: objectType({
			manifest: manifestSchema,
			python: version
		}),
		photonvision: objectType({
			manifest: manifestSchema,
			python: version
		})
	}).strict()
}).strict();
const librarySettingsSchema = objectType({
	mode: enumType(["automatic", "frozen"]),
	extras: arrayType(vendorId).max(5),
	lock: libraryLockSchema,
	previous: libraryLockSchema.optional()
}).strict();
function compareVersions(a, b) {
	const av = a.replace(/^v/, "").split(".").map(Number), bv = b.replace(/^v/, "").split(".").map(Number);
	for (let i = 0; i < Math.max(av.length, bv.length); i++) if ((av[i] || 0) !== (bv[i] || 0)) return (av[i] || 0) - (bv[i] || 0);
	return 0;
}
function isSeasonVersion(value, short = false) {
	return stableVersion.test(value) && Number(value.replace(/^v/, "").split(".")[0]) === (short ? 26 : 2026);
}
function isVendorVersion(id, value) {
	return id === "phoenix5" ? stableVersion.test(value) && value.startsWith("5.") : isSeasonVersion(value, id === "ctre");
}
function validateManifest(id, data) {
	const m = manifestSchema.parse(data), def = vendorRegistry[id];
	if (m.uuid !== def.uuid || !isVendorVersion(id, m.version)) throw Error(`${def.name}: wrong library, season, or prerelease.`);
	const metadataUrl = new URL(m.jsonUrl);
	const publisherHosts = [...def.repositories.map((repo) => new URL(repo).hostname), ...def.feed ? [new URL(def.feed).hostname] : []];
	if (metadataUrl.protocol !== "https:" || metadataUrl.username || metadataUrl.password || !publisherHosts.includes(metadataUrl.hostname)) throw Error(`${def.name}: unrecognized metadata URL.`);
	for (const req of m.requires || []) if (id !== "phoenix5" || req.uuid !== vendorRegistry.ctre.uuid || req.onlineUrl !== vendorRegistry.ctre.feed) throw Error("Unrecognized transitive vendor dependency.");
	for (const repo of m.mavenUrls) if (!def.repositories.some((base) => repo === base || repo === base.replace(/\/$/, ""))) throw Error(`${def.name}: unrecognized package repository.`);
	for (const d of [
		...m.javaDependencies,
		...m.jniDependencies,
		...m.cppDependencies
	]) {
		if (!(d.groupId === def.group || d.groupId.startsWith(def.group + "."))) throw Error(`${def.name}: unexpected Maven group.`);
		if (!isVendorVersion(id, d.version)) throw Error(`${def.name}: unsupported dependency version.`);
	}
	return {
		...m,
		fileName: def.file
	};
}
function validateLibraryLock(data) {
	const lock = libraryLockSchema.parse(data);
	if (!isSeasonVersion(lock.legacyPhoenix6, true)) throw Error("Invalid Phoenix 5 / 6 compatibility version.");
	if (!isSeasonVersion(lock.wpilib) || !isSeasonVersion(lock.robotpy)) throw Error("Use stable 2026 WPILib and RobotPy versions.");
	for (const id of vendorIds) {
		validateManifest(id, lock.vendors[id].manifest);
		if (lock.vendors[id].python && !isSeasonVersion(lock.vendors[id].python, id === "ctre")) throw Error(`${vendorRegistry[id].name}: unsupported Python version.`);
	}
	return lock;
}
function selectedVendors(settings) {
	return vendorIds.filter((id) => vendorRegistry[id].required || settings?.extras.includes(id));
}
function pythonRequirements(lock, extras = []) {
	return [`robotpy[commands2]==${lock.robotpy}`, ...selectedVendors({ extras }).filter((id) => vendorRegistry[id].python).map((id) => `${vendorRegistry[id].python}==${lock.vendors[id].python}`)];
}
function mergeNewer(current, available) {
	const newer = (a, b) => compareVersions(b, a) > 0 ? b : a;
	const result = structuredClone(current);
	result.checkedAt = available.checkedAt;
	result.legacyPhoenix6 = newer(current.legacyPhoenix6, available.legacyPhoenix6);
	result.wpilib = newer(current.wpilib, available.wpilib);
	result.robotpy = newer(current.robotpy, available.robotpy);
	for (const id of vendorIds) {
		if (compareVersions(available.vendors[id].manifest.version, current.vendors[id].manifest.version) > 0) result.vendors[id].manifest = available.vendors[id].manifest;
		if (id !== "thrifty") result.vendors[id].python = newer(current.vendors[id].python, available.vendors[id].python);
	}
	return result;
}
//#endregion
//#region lib/robot-model.ts
const id = stringType().regex(/^[A-Za-z][A-Za-z0-9_]{0,39}$/);
const finite = numberType().finite();
const motorSchema = objectType({
	id,
	name: stringType().min(1).max(60),
	type: enumType([
		"SparkMax",
		"SparkFlex",
		"TalonFX",
		"TalonFXS",
		"TalonSRX",
		"VictorSPX",
		"ThriftyNova",
		"PWMSparkMax",
		"PWMTalonSRX",
		"PWMVictorSPX",
		"PWMSpark",
		"PWMVictor"
	]),
	bus: busName.optional(),
	motorKind: enumType([
		"default",
		"brushed",
		"neo",
		"vortex",
		"minion",
		"falcon"
	]).optional(),
	can: finite.int().min(0).max(62),
	inverted: booleanType(),
	sensorSign: unionType([literalType(1), literalType(-1)]),
	current: finite.int().min(1).max(80),
	subsystem: id,
	role: enumType([
		"left",
		"right",
		"mechanism"
	]),
	limit: finite.int().min(-1).max(9)
}).strict();
const projectSchema = objectType({
	schema: literalType(1),
	name: stringType().min(1).max(60),
	team: finite.int().min(0).max(99999),
	language: enumType([
		"Java",
		"C++",
		"Python"
	]),
	motors: arrayType(motorSchema).min(2).max(40),
	subsystems: arrayType(objectType({
		id,
		name: stringType().min(1).max(40),
		description: stringType().max(200)
	})).min(1).max(20),
	devices: arrayType(deviceSchema).max(80).optional(),
	routines: arrayType(routineSchema).max(20).optional(),
	commands: arrayType(objectType({
		id,
		device: id.optional(),
		untilDevice: id.optional(),
		condition: enumType(["above", "below"]).optional(),
		threshold: finite.optional(),
		name: stringType().min(1).max(40),
		subsystem: id,
		output: finite.min(-1).max(1),
		timeout: finite.min(.05).max(15)
	})).max(30),
	bindings: arrayType(objectType({
		id,
		controller: enumType(["driver", "operator"]),
		button: finite.int().min(1).max(20),
		command: id,
		behavior: enumType([
			"whileHeld",
			"onPress",
			"toggle"
		])
	})).max(40),
	controls: objectType({
		driverPort: finite.int().min(0).max(5),
		operatorPort: finite.int().min(0).max(5),
		driverType: enumType(["Xbox", "Joystick"]),
		operatorType: enumType(["Xbox", "Joystick"]),
		forwardAxis: finite.int().min(0).max(11),
		turnAxis: finite.int().min(0).max(11),
		forwardSign: unionType([literalType(1), literalType(-1)]),
		turnSign: unionType([literalType(1), literalType(-1)]),
		deadband: finite.min(0).max(.3),
		maxOutput: finite.min(.05).max(1)
	}),
	drive: objectType({
		trackWidth: finite.min(.2).max(2),
		wheelDiameter: finite.min(.04).max(.5),
		gearing: finite.min(1).max(40),
		maxSpeed: finite.min(.1).max(8),
		mass: finite.min(5).max(100),
		moi: finite.min(.1).max(30),
		kS: finite.min(0).max(3),
		kV: finite.min(.1).max(20),
		kP: finite.min(0).max(20),
		gyro: enumType([
			"ADXRS450",
			"Pigeon2",
			"NavX"
		]),
		gyroBus: busName.optional(),
		navxInterface: enumType([
			"mxp",
			"usb1",
			"usb2",
			"onboard"
		]).optional(),
		gyroCan: finite.int().min(0).max(62)
	}),
	auto: objectType({
		name: id,
		maxSpeed: finite.min(.1).max(6),
		maxAcceleration: finite.min(.1).max(6),
		waypoints: arrayType(objectType({
			x: finite.min(0).max(16.54),
			y: finite.min(0).max(8.07)
		})).min(2).max(30),
		steps: arrayType(objectType({
			id,
			type: enumType([
				"path",
				"command",
				"wait"
			]),
			command: stringType().max(40),
			seconds: finite.min(.05).max(15)
		})).max(20)
	}),
	checks: recordType(booleanType()),
	libraries: librarySettingsSchema.optional()
}).strict();
[
	{
		id: "leftFront",
		name: "Left front",
		can: 1,
		role: "left",
		subsystem: "drive",
		inverted: false,
		sensorSign: 1
	},
	{
		id: "leftRear",
		name: "Left rear",
		can: 2,
		role: "left",
		subsystem: "drive",
		inverted: false,
		sensorSign: 1
	},
	{
		id: "rightFront",
		name: "Right front",
		can: 3,
		role: "right",
		subsystem: "drive",
		inverted: true,
		sensorSign: -1
	},
	{
		id: "rightRear",
		name: "Right rear",
		can: 4,
		role: "right",
		subsystem: "drive",
		inverted: true,
		sensorSign: -1
	},
	{
		id: "intakeMotor",
		name: "Intake motor",
		can: 5,
		role: "mechanism",
		subsystem: "intake",
		inverted: false,
		sensorSign: 1
	},
	{
		id: "shooterMotor",
		name: "Shooter motor",
		can: 6,
		role: "mechanism",
		subsystem: "shooter",
		inverted: false,
		sensorSign: 1
	}
].map((m) => ({
	...m,
	type: "SparkMax",
	current: 30,
	limit: -1
}));
const benchChecks = [
	["mechanical", "Robot is supported; mechanisms are clear and secured."],
	["can", "CAN IDs, firmware, wiring, and termination are verified."],
	["direction", "Drive output and encoder signs agree with forward motion."],
	["gyro", "Gyro heading and odometry are verified on the robot."],
	["limits", "Motor current limits and active-low limit switches are tested."],
	["tuning", "Wheel geometry, feedforward, feedback, and path constraints are tuned."],
	["disable", "Disable, button release, command timeout, and autonomous interruption stop outputs."],
	["simulation", "Project compiles and the command flow passes simulation."],
	["field", "Autonomous is tested at reduced speed on the actual field layout."]
];
function validate(p) {
	const issues = [];
	const error = (area, message) => issues.push({
		level: "error",
		area,
		message
	});
	const warn = (area, message) => issues.push({
		level: "warning",
		area,
		message
	});
	const shape = projectSchema.safeParse(p);
	if (!shape.success) {
		shape.error.issues.forEach((i) => error("Configuration", `${i.path.join(" → ")}: ${i.message}`));
		return issues;
	}
	if (p.libraries) try {
		validateLibraryLock(p.libraries.lock);
		if (p.libraries.previous) validateLibraryLock(p.libraries.previous);
	} catch (e) {
		error("Libraries & updates", e instanceof Error ? e.message : "Invalid library lock.");
	}
	if (p.team < 1) error("Code & export", "Enter your real team number before exporting robot code.");
	issues.push(...validateHardware(p), ...validateRoutines(p));
	p.motors.forEach((m) => {
		if (!p.subsystems.some((s) => s.id === m.subsystem)) error("Hardware", m.name + " references a missing subsystem.");
		if (m.role === "mechanism" === (m.subsystem === "drive")) error("Hardware", m.name + ": drivetrain motors need a left/right role; mechanisms need a mechanism role.");
	});
	for (const role of ["left", "right"]) if (!p.motors.some((m) => m.role === role && m.subsystem === "drive")) error("Hardware", `Add at least one ${role} drivetrain motor.`);
	for (const role of ["left", "right"]) {
		const ms = p.motors.filter((m) => m.role === role);
		if (new Set(ms.map((m) => m.type === "TalonFX" ? "kraken" : "neo")).size > 1) error("Hardware", `Use one motor family per drive side for the PathPlanner motor model.`);
	}
	if (new Set(p.motors.filter((m) => m.subsystem === "drive").map((m) => m.type === "TalonFX" ? "kraken" : "neo")).size > 1) error("Hardware", "Both drive sides must use the same motor family.");
	if (p.motors.filter((m) => m.role === "left").length !== p.motors.filter((m) => m.role === "right").length) error("Hardware", "Use equal motor counts on the left and right drive sides.");
	if (!p.subsystems.some((s) => s.id === "drive")) error("Subsystems", "The drivetrain subsystem is required.");
	for (const side of ["left", "right"]) if (p.motors.filter((m) => m.role === side).length !== 2) error("Hardware", "PathPlanner differential configuration requires two drive motors per side.");
	if (new Set(p.motors.filter((m) => m.subsystem === "drive").map((m) => m.type)).size > 1) error("Hardware", "Use the same controller and motor type for all drive motors.");
	const ports = p.motors.filter((m) => m.limit >= 0).map((m) => m.limit);
	if (new Set(ports).size !== ports.length) error("Hardware", "Each limit switch needs a unique DIO channel.");
	for (const group of [
		p.motors,
		p.subsystems,
		p.commands,
		p.bindings,
		p.auto.steps
	]) if (new Set(group.map((x) => x.id)).size !== group.length) error("Configuration", "Duplicate internal identifiers were found.");
	p.commands.forEach((c) => {
		if (c.subsystem === "drive") error("Commands", "Drive actions belong in autonomous paths, not mechanism commands.");
		if (!p.subsystems.some((s) => s.id === c.subsystem)) error("Commands", `${c.name} references a missing subsystem.`);
		if (!c.device && !p.motors.some((m) => m.subsystem === c.subsystem)) error("Commands", `${c.name} has no motors assigned.`);
	});
	const binds = /* @__PURE__ */ new Set();
	p.bindings.forEach((b) => {
		const key = `${b.controller}:${b.button}`;
		if (binds.has(key)) error("Controls", `${b.controller} button ${b.button} has multiple assignments.`);
		binds.add(key);
		if (!availableActions(p).some((c) => c.value === b.command)) error("Controls", "A button refers to a deleted command.");
		if (p.controls[`${b.controller}Type`] === "Xbox" && b.button > 10) error("Controls", "Xbox buttons must be 1–10.");
	});
	if (p.controls.driverPort === p.controls.operatorPort) error("Controls", "Driver and operator USB ports must differ.");
	if (p.controls.forwardAxis === p.controls.turnAxis) error("Controls", "Forward and turn must use different axes.");
	p.auto.waypoints.forEach((w, i) => {
		if (i && Math.hypot(w.x - p.auto.waypoints[i - 1].x, w.y - p.auto.waypoints[i - 1].y) < .1) error("Autonomous", "Waypoints must be at least 0.1 m apart.");
	});
	if (p.auto.maxSpeed > p.drive.maxSpeed) error("Autonomous", "Path speed exceeds the drivetrain maximum speed.");
	if (p.auto.steps.filter((s) => s.type === "path").length > 1) error("Autonomous", "This route can appear once in the sequence; duplicate it in PathPlanner for multi-path routines.");
	p.auto.steps.forEach((s) => {
		if (s.type === "command" && !availableActions(p).some((c) => c.value === s.command)) error("Autonomous", "An autonomous step refers to a missing command.");
	});
	if (!p.auto.steps.length) warn("Autonomous", "No autonomous steps are configured. The robot will remain stopped.");
	warn("Preflight", "Generated source requires a local WPILib build, motor-direction verification, tuning, and on-robot testing.");
	if (benchChecks.some(([key]) => !p.checks[key])) warn("Preflight", "Complete the bench and field checklist before competition.");
	return issues;
}
//#endregion
//#region lib/library-project.ts
const bundledLock = validateLibraryLock(bundled_libraries_default);
function hardwareVendors(project) {
	const ids = /* @__PURE__ */ new Set();
	for (const d of project.devices || []) {
		const v = productById(d.product)?.vendor;
		if (v) ids.add(v);
	}
	if (project.drive?.gyro === "NavX") ids.add("navx");
	if (project.motors?.some((m) => ["TalonSRX", "VictorSPX"].includes(m.type))) ids.add("phoenix5");
	if (project.motors?.some((m) => m.type === "ThriftyNova")) ids.add("thrifty");
	return [...ids];
}
function projectLibraryLock(project, lock) {
	if (project.language === "Python" && (hardwareVendors(project).includes("phoenix5") || project.libraries?.extras.includes("phoenix5"))) return {
		...lock,
		vendors: {
			...lock.vendors,
			ctre: {
				...lock.vendors.ctre,
				python: lock.legacyPhoenix6
			}
		}
	};
	return lock;
}
function librarySettings(project) {
	const settings = project.libraries || {
		mode: "automatic",
		extras: [],
		lock: bundledLock
	};
	return {
		...settings,
		lock: projectLibraryLock(project, validateLibraryLock(settings.lock)),
		extras: [...new Set([...settings.extras, ...hardwareVendors(project)])]
	};
}
function versionsFor(project) {
	const lock = librarySettings(project).lock;
	return {
		wpilib: lock.wpilib,
		robotpy: lock.robotpy,
		rev: lock.vendors.rev.manifest.version,
		robotpyRev: lock.vendors.rev.python,
		phoenix: project.language === "Python" ? lock.vendors.ctre.python : lock.vendors.ctre.manifest.version,
		pathplanner: lock.vendors.pathplanner.manifest.version,
		checked: lock.checkedAt.slice(0, 10)
	};
}
function pythonProjectFile(project) {
	const settings = librarySettings(project);
	const requires = selectedVendors(settings).filter((id) => vendorRegistry[id].python).map((id) => `${vendorRegistry[id].python}==${settings.lock.vendors[id].python}`);
	return `[tool.robotpy]\nrobotpy_version = "${settings.lock.robotpy}"\ncomponents = ["commands2"]\nrequires = ${JSON.stringify(requires)}\n`;
}
//#endregion
//#region lib/gen-motors.ts
const q$4 = JSON.stringify;
function javaMotor(p) {
	return `package frc.robot;
import edu.wpi.first.wpilibj.*;
import java.util.function.*;
public final class MotorIO {
 private DoubleSupplier readPosition=()->0,readVelocity=()->0; private DoubleConsumer write=v->{};
 private final double sign; private final DigitalInput limit; private boolean configured=false;
 public MotorIO(String kind,int can,boolean inverted,double encoderSign,int amps,int dio,String bus,String motorKind){
  sign=encoderSign;limit=dio>=0?new DigitalInput(dio):null;
  switch(kind){
${[...new Set(p.motors.map((m) => m.type))].map((type) => {
		if (type === "SparkMax" || type === "SparkFlex") return `case ${q$4(type)} -> {
   var motor=new com.revrobotics.spark.${type}(can,motorKind.equals("brushed")?com.revrobotics.spark.SparkLowLevel.MotorType.kBrushed:com.revrobotics.spark.SparkLowLevel.MotorType.kBrushless);
   var config=new com.revrobotics.spark.config.${type}Config();
   config.inverted(inverted).idleMode(com.revrobotics.spark.config.SparkBaseConfig.IdleMode.kBrake).smartCurrentLimit(amps);
   for(int i=0;i<3&&!configured;i++)configured=motor.configure(config,com.revrobotics.ResetMode.kResetSafeParameters,com.revrobotics.PersistMode.kPersistParameters)==com.revrobotics.REVLibError.kOk;
   if(!motorKind.equals("brushed")){readPosition=()->motor.getEncoder().getPosition();readVelocity=()->motor.getEncoder().getVelocity()/60.0;}
   write=motor::setVoltage;
  }`;
		if (type === "TalonFX" || type === "TalonFXS") return `case ${q$4(type)} -> {
   var motor=new com.ctre.phoenix6.hardware.${type}(can,new com.ctre.phoenix6.CANBus(bus));
   var config=new com.ctre.phoenix6.configs.${type}Configuration();
   config.MotorOutput.Inverted=inverted?com.ctre.phoenix6.signals.InvertedValue.Clockwise_Positive:com.ctre.phoenix6.signals.InvertedValue.CounterClockwise_Positive;
   config.MotorOutput.NeutralMode=com.ctre.phoenix6.signals.NeutralModeValue.Brake;
   config.CurrentLimits.StatorCurrentLimitEnable=true;config.CurrentLimits.StatorCurrentLimit=amps;
   ${type === "TalonFXS" ? `config.Commutation.MotorArrangement=motorKind.equals("brushed")?com.ctre.phoenix6.signals.MotorArrangementValue.Brushed_DC:motorKind.equals("neo")?com.ctre.phoenix6.signals.MotorArrangementValue.NEO_JST:com.ctre.phoenix6.signals.MotorArrangementValue.Minion_JST;
   config.Commutation.BrushedMotorWiring=com.ctre.phoenix6.signals.BrushedMotorWiringValue.Leads_A_and_B;` : ""}
   for(int i=0;i<3&&!configured;i++)configured=motor.getConfigurator().apply(config).isOK();
   readPosition=()->motor.getPosition().getValueAsDouble();readVelocity=()->motor.getVelocity().getValueAsDouble();write=motor::setVoltage;
  }`;
		if (type === "TalonSRX" || type === "VictorSPX") return `case ${q$4(type)} -> {
   var motor=new com.ctre.phoenix.motorcontrol.can.WPI_${type}(can);
   var config=new com.ctre.phoenix.motorcontrol.can.${type}Configuration();
   ${type === "TalonSRX" ? "config.continuousCurrentLimit=amps;config.peakCurrentLimit=amps;config.peakCurrentDuration=0;" : ""}
   for(int i=0;i<3&&!configured;i++)configured=motor.configAllSettings(config,100)==com.ctre.phoenix.ErrorCode.OK;
   motor.setInverted(inverted);motor.setNeutralMode(com.ctre.phoenix.motorcontrol.NeutralMode.Brake);${type === "TalonSRX" ? "motor.enableCurrentLimit(true);" : ""}
   write=motor::setVoltage;
  }`;
		if (type === "ThriftyNova") return `case "ThriftyNova" -> {
   var motor=new com.thethriftybot.devices.ThriftyNova(can,motorKind.equals("brushed")?com.thethriftybot.devices.ThriftyNova.MotorType.BRUSHED:motorKind.equals("minion")?com.thethriftybot.devices.ThriftyNova.MotorType.MINION:com.thethriftybot.devices.ThriftyNova.MotorType.NEO);
   motor.setInverted(inverted);motor.setBrakeMode(true);motor.setMaxCurrent(com.thethriftybot.devices.ThriftyNova.CurrentType.STATOR,amps);
   configured=motor.getErrors().isEmpty();write=motor::setVoltage;
  }`;
		return `case ${q$4(type)} -> {var motor=new edu.wpi.first.wpilibj.motorcontrol.${type === "PWMSpark" ? "Spark" : type === "PWMVictor" ? "VictorSP" : type}(can);motor.setInverted(inverted);write=motor::setVoltage;configured=true;}`;
	}).join("\n")}
   default -> throw new IllegalArgumentException("Unknown motor controller: "+kind);
  }
  if(!configured)DriverStation.reportError("Motor configuration failed; output inhibited: "+bus+":"+can,false);
 }
 public double position(){return sign*readPosition.getAsDouble();}
 public double velocity(){return sign*readVelocity.getAsDouble();}
 public boolean ready(){return configured;}
 public void voltage(double value){if(!configured||!DriverStation.isEnabled()||!Double.isFinite(value))value=0;if(limit!=null&&!limit.get()&&value>0)value=0;write.accept(Math.max(-12,Math.min(12,value)));}
 public void stop(){voltage(0);}
}
`;
}
function cppMotor(p) {
	const types = [...new Set(p.motors.map((m) => m.type))];
	return `#include <functional>
${types.map((t) => t.startsWith("PWM") ? `#include <frc/motorcontrol/${t === "PWMSpark" ? "Spark" : t === "PWMVictor" ? "VictorSP" : t}.h>` : t === "TalonFXS" ? `#include <ctre/phoenix6/TalonFXS.hpp>` : ["TalonSRX", "VictorSPX"].includes(t) ? `#include <ctre/phoenix/motorcontrol/can/WPI_${t}.h>` : "").join("\n")}
class MotorIO {
 std::function<double()> readPosition=[]{return 0.0;},readVelocity=[]{return 0.0;};std::function<void(double)> write=[](double){};
 std::unique_ptr<frc::DigitalInput> limit;double sign;bool configured=false;
public:
 MotorIO(std::string kind,int can,bool inverted,double encoderSign,int amps,int dio,std::string bus,std::string motorKind):sign(encoderSign){
  if(dio>=0)limit=std::make_unique<frc::DigitalInput>(dio);
${types.map((type, i) => {
		const pre = `${i ? "else " : ""}if(kind==${q$4(type)})`;
		if (type === "SparkMax" || type === "SparkFlex") return `${pre}{
   auto motor=std::make_shared<rev::spark::${type}>(can,motorKind=="brushed"?rev::spark::SparkLowLevel::MotorType::kBrushed:rev::spark::SparkLowLevel::MotorType::kBrushless);
   rev::spark::${type}Config config;config.Inverted(inverted).SetIdleMode(rev::spark::SparkBaseConfig::IdleMode::kBrake).SmartCurrentLimit(amps);
   for(int i=0;i<3&&!configured;i++)configured=motor->Configure(config,rev::ResetMode::kResetSafeParameters,rev::PersistMode::kPersistParameters)==rev::REVLibError::kOk;
   if(motorKind!="brushed"){readPosition=[motor]{return motor->GetEncoder().GetPosition();};readVelocity=[motor]{return motor->GetEncoder().GetVelocity()/60.0;};}
   write=[motor](double v){motor->SetVoltage(units::volt_t{v});};
  }`;
		if (type === "TalonFX" || type === "TalonFXS") return `${pre}{
   auto motor=std::make_shared<ctre::phoenix6::hardware::${type}>(can,ctre::phoenix6::CANBus{bus});ctre::phoenix6::configs::${type}Configuration config;
   config.MotorOutput.Inverted=inverted?ctre::phoenix6::signals::InvertedValue::Clockwise_Positive:ctre::phoenix6::signals::InvertedValue::CounterClockwise_Positive;
   config.MotorOutput.NeutralMode=ctre::phoenix6::signals::NeutralModeValue::Brake;
   config.CurrentLimits.StatorCurrentLimitEnable=true;config.CurrentLimits.StatorCurrentLimit=units::ampere_t{static_cast<double>(amps)};
   ${type === "TalonFXS" ? `config.Commutation.MotorArrangement=motorKind=="brushed"?ctre::phoenix6::signals::MotorArrangementValue::Brushed_DC:motorKind=="neo"?ctre::phoenix6::signals::MotorArrangementValue::NEO_JST:ctre::phoenix6::signals::MotorArrangementValue::Minion_JST;
   config.Commutation.BrushedMotorWiring=ctre::phoenix6::signals::BrushedMotorWiringValue::Leads_A_and_B;` : ""}
   for(int i=0;i<3&&!configured;i++)configured=motor->GetConfigurator().Apply(config).IsOK();
   readPosition=[motor]{return motor->GetPosition().GetValueAsDouble();};readVelocity=[motor]{return motor->GetVelocity().GetValueAsDouble();};write=[motor](double v){motor->SetVoltage(units::volt_t{v});};
  }`;
		if (type === "TalonSRX" || type === "VictorSPX") return `${pre}{
   auto motor=std::make_shared<ctre::phoenix::motorcontrol::can::WPI_${type}>(can);ctre::phoenix::motorcontrol::can::${type}Configuration config;
   ${type === "TalonSRX" ? "config.continuousCurrentLimit=amps;config.peakCurrentLimit=amps;config.peakCurrentDuration=0;" : ""}
   for(int i=0;i<3&&!configured;i++)configured=motor->ConfigAllSettings(config,100)==ctre::phoenix::ErrorCode::OK;
   motor->SetInverted(inverted);motor->SetNeutralMode(ctre::phoenix::motorcontrol::NeutralMode::Brake);${type === "TalonSRX" ? "motor->EnableCurrentLimit(true);" : ""}write=[motor](double v){motor->SetVoltage(units::volt_t{v});};
  }`;
		if (type === "ThriftyNova") return `${pre}{throw std::runtime_error("Thrifty Nova requires Java");}`;
		return `${pre}{auto motor=std::make_shared<frc::${type === "PWMSpark" ? "Spark" : type === "PWMVictor" ? "VictorSP" : type}>(can);motor->SetInverted(inverted);write=[motor](double v){motor->SetVoltage(units::volt_t{v});};configured=true;}`;
	}).join("\n")}
  else throw std::runtime_error("Unknown motor controller");
  if(!configured)FRC_ReportError(frc::err::Error,"{}","Motor configuration failed; output inhibited at "+bus+":"+std::to_string(can));
 }
 bool Ready(){return configured;}double Position(){return sign*readPosition();}double Velocity(){return sign*readVelocity();}
 void Voltage(double value){if(!configured||!frc::DriverStation::IsEnabled()||!std::isfinite(value))value=0;if(limit&&!limit->Get()&&value>0)value=0;write(std::clamp(value,-12.0,12.0));}
 void Stop(){Voltage(0);}
};
`;
}
function pythonMotor(p) {
	const types = [...new Set(p.motors.map((m) => m.type))];
	return `from phoenix6 import CANBus
from phoenix6.hardware import TalonFX, TalonFXS
from phoenix6.configs import TalonFXConfiguration, TalonFXSConfiguration
from phoenix6.signals import MotorArrangementValue, BrushedMotorWiringValue
${types.some((t) => ["TalonSRX", "VictorSPX"].includes(t)) ? "import phoenix5" : ""}
class MotorIO:
    def __init__(self, config):
        self.sign = config['sensorSign']
        self.limit = wpilib.DigitalInput(config['limit']) if config['limit'] >= 0 else None
        self.configured = False
        self.read_position = lambda: 0.0
        self.read_velocity = lambda: 0.0
        kind, motor_kind = config['type'], config.get('motorKind', 'default')
        can, amps, inverted = config['can'], config['current'], config['inverted']
        if kind in ('SparkMax', 'SparkFlex'):
            motor = (rev.SparkFlex if kind == 'SparkFlex' else rev.SparkMax)(can, rev.SparkLowLevel.MotorType.kBrushed if motor_kind == 'brushed' else rev.SparkLowLevel.MotorType.kBrushless)
            settings = rev.SparkFlexConfig() if kind == 'SparkFlex' else rev.SparkMaxConfig()
            settings.inverted(inverted).setIdleMode(rev.SparkBaseConfig.IdleMode.kBrake).smartCurrentLimit(amps)
            for _ in range(3):
                self.configured = motor.configure(settings, rev.ResetMode.kResetSafeParameters, rev.PersistMode.kPersistParameters) == rev.REVLibError.kOk
                if self.configured: break
            if motor_kind != 'brushed':
                self.read_position = lambda: motor.getEncoder().getPosition()
                self.read_velocity = lambda: motor.getEncoder().getVelocity() / 60.0
            self.write = motor.setVoltage
        elif kind in ('TalonFX', 'TalonFXS'):
            motor = (TalonFXS if kind == 'TalonFXS' else TalonFX)(can, CANBus(config.get('bus', 'rio')))
            settings = TalonFXSConfiguration() if kind == 'TalonFXS' else TalonFXConfiguration()
            settings.motor_output.inverted = InvertedValue.CLOCKWISE_POSITIVE if inverted else InvertedValue.COUNTER_CLOCKWISE_POSITIVE
            settings.motor_output.neutral_mode = NeutralModeValue.BRAKE
            settings.current_limits.stator_current_limit_enable = True
            settings.current_limits.stator_current_limit = amps
            if kind == 'TalonFXS':
                settings.commutation.motor_arrangement = MotorArrangementValue.BRUSHED_DC if motor_kind == 'brushed' else MotorArrangementValue.NEO_JST if motor_kind == 'neo' else MotorArrangementValue.MINION_JST
                settings.commutation.brushed_motor_wiring = BrushedMotorWiringValue.LEADS_A_AND_B
            for _ in range(3):
                self.configured = motor.configurator.apply(settings).is_ok()
                if self.configured: break
            self.read_position = lambda: motor.get_position().value_as_double
            self.read_velocity = lambda: motor.get_velocity().value_as_double
            self.write = lambda v: motor.set_control(VoltageOut(v))
${types.some((t) => ["TalonSRX", "VictorSPX"].includes(t)) ? `        elif kind in ('TalonSRX', 'VictorSPX'):
            motor = (phoenix5.WPI_TalonSRX if kind == 'TalonSRX' else phoenix5.WPI_VictorSPX)(can)
            settings = phoenix5.TalonSRXConfiguration() if kind == 'TalonSRX' else phoenix5.VictorSPXConfiguration()
            if kind == 'TalonSRX':
                settings.continuousCurrentLimit = amps
                settings.peakCurrentLimit = amps
                settings.peakCurrentDuration = 0
            for _ in range(3):
                self.configured = motor.configAllSettings(settings, 100) == phoenix5.ErrorCode.OK
                if self.configured: break
            motor.setInverted(inverted)
            motor.setNeutralMode(phoenix5.NeutralMode.Brake)
            if kind == 'TalonSRX': motor.enableCurrentLimit(True)
            self.write = motor.setVoltage
` : ""}        elif kind.startswith('PWM'):
            cls = {'PWMSparkMax': wpilib.PWMSparkMax, 'PWMTalonSRX': wpilib.PWMTalonSRX, 'PWMVictorSPX': wpilib.PWMVictorSPX, 'PWMSpark': wpilib.Spark, 'PWMVictor': wpilib.VictorSP}[kind]
            motor = cls(can)
            motor.setInverted(inverted)
            self.write = motor.setVoltage
            self.configured = True
        else:
            raise ValueError('No supported motor adapter for ' + kind)
        self.motor = motor
        if not self.configured: wpilib.reportError('Motor configuration failed; output inhibited: ' + str(can))

    def position(self): return self.sign * self.read_position()
    def velocity(self): return self.sign * self.read_velocity()
    def voltage(self, volts):
        if not self.configured or not wpilib.DriverStation.isEnabled() or not math.isfinite(volts): volts = 0.0
        if self.limit is not None and not self.limit.get() and volts > 0: volts = 0.0
        self.write(max(-12.0, min(12.0, volts)))
    def stop(self): self.voltage(0)

`;
}
//#endregion
//#region lib/gen-actions.ts
const q$3 = JSON.stringify;
function javaAction(c) {
	const set = c.device ? `hardware.set_${c.device}(${c.output})` : `mechanism_${c.subsystem}.set(${c.output})`, stop = c.device ? `hardware.stop_${c.device}()` : `mechanism_${c.subsystem}.stop()`;
	return `${c.untilDevice ? `private boolean condition_${c.id}(){double value=hardware.read_${c.untilDevice}();return !Double.isFinite(value)||value${c.condition === "below" ? "<=" : ">="}${c.threshold ?? .5};}\n` : ""}private Command action_${c.id}(){return mechanism_${c.subsystem}.runEnd(()->{${c.untilDevice ? `if(condition_${c.id}()){${stop};return;}` : ""}${set};},()->${stop}).withTimeout(${c.timeout})${c.untilDevice ? `.until(this::condition_${c.id})` : ""}.withName(${q$3(c.name)});}`;
}
function cppAction(c) {
	const set = c.device ? `hardware.set_${c.device}(${c.output})` : `mechanism_${c.subsystem}.Set(${c.output})`, stop = c.device ? `hardware.stop_${c.device}()` : `mechanism_${c.subsystem}.Stop()`;
	return `${c.untilDevice ? `bool Condition_${c.id}(){double value=hardware.read_${c.untilDevice}();return !std::isfinite(value)||value${c.condition === "below" ? "<=" : ">="}${c.threshold ?? .5};}\n` : ""}frc2::CommandPtr Action_${c.id}(){return mechanism_${c.subsystem}.RunEnd([this]{${c.untilDevice ? `if(Condition_${c.id}()){${stop};return;}` : ""}${set};},[this]{${stop};}).WithTimeout(units::second_t{${c.timeout}})${c.untilDevice ? `.Until([this]{return Condition_${c.id}();})` : ""}.WithName(${q$3(c.name)});}`;
}
//#endregion
//#region lib/gen-devices.ts
const q$2 = JSON.stringify;
const blank = () => [
	"",
	"",
	""
];
const navxPort = (s) => ({
	mxp: "kMXP_SPI",
	onboard: "kI2C",
	usb1: "kUSB1",
	usb2: "kUSB2"
})[s || "mxp"] || "kMXP_SPI";
function fragment(d, p) {
	const a = productById(d.product)?.adapter, n = "d_" + d.id, py = "self." + n, ch = d.channel, id = d.address;
	const f = {
		fields: blank(),
		init: blank(),
		read: [
			"Double.NaN",
			"NAN",
			"float('nan')"
		],
		extra: blank(),
		set: blank(),
		stop: blank()
	};
	const declare = (jt, jv, ct, cv, pv) => {
		f.fields = [
			`private final ${jt} ${n}=${jv};`,
			`${ct} ${n}${cv};`,
			`${py} = ${pv}`
		];
	};
	const calibrated = (r) => {
		f.read = r.map((x) => `(${d.inverted ? -1 : 1} * (${x}) * ${d.scale} + ${d.offset})`);
	};
	if ([
		"cancoder",
		"canrange",
		"candi",
		"pigeon"
	].includes(a || "")) {
		const cls = {
			cancoder: "CANcoder",
			canrange: "CANrange",
			candi: "CANdi",
			pigeon: "Pigeon2"
		}[a];
		declare(`com.ctre.phoenix6.hardware.${cls}`, `new com.ctre.phoenix6.hardware.${cls}(${id},new com.ctre.phoenix6.CANBus(${q$2(d.bus)}))`, `ctre::phoenix6::hardware::${cls}`, `{${id},ctre::phoenix6::CANBus{${q$2(d.bus)}}}`, `phoenix6.hardware.${cls}(${id}, phoenix6.CANBus(${q$2(d.bus)}))`);
		const method = {
			cancoder: [
				"getAbsolutePosition",
				"GetAbsolutePosition",
				"get_absolute_position"
			],
			canrange: [
				"getDistance",
				"GetDistance",
				"get_distance"
			],
			candi: [
				"getS1Closed",
				"GetS1Closed",
				"get_s1_closed"
			],
			pigeon: [
				"getYaw",
				"GetYaw",
				"get_yaw"
			]
		}[a];
		const sig = [
			`${n}.${method[0]}()`,
			`${n}.${method[1]}()`,
			`${py}.${method[2]}()`
		];
		const value = a === "candi" ? [
			`${sig[0]}.getValue()?1.0:0.0`,
			`${sig[1]}.GetValue()?1.0:0.0`,
			`1.0 if ${sig[2]}.value else 0.0`
		] : [
			`${sig[0]}.getValueAsDouble()`,
			`${sig[1]}.GetValueAsDouble()`,
			`${sig[2]}.value_as_double`
		];
		calibrated([
			`(${sig[0]}.getStatus().isOK() && ${sig[0]}.getTimestamp().getLatency()<0.25 ? (${value[0]}) : Double.NaN)`,
			`(${sig[1]}.GetStatus().IsOK() && ${sig[1]}.GetTimestamp().GetLatency().value()<0.25 ? (${value[1]}) : NAN)`,
			`((${value[2]}) if ${sig[2]}.status.is_ok() and ${sig[2]}.timestamp.get_latency()<0.25 else float('nan'))`
		]);
		if (a === "candi") f.extra = [
			`SmartDashboard.putBoolean(${q$2(d.name + "/S2 closed")},${n}.getS2Closed().getValue());SmartDashboard.putNumber(${q$2(d.name + "/quadrature rotations")},${n}.getQuadraturePosition().getValueAsDouble());`,
			`frc::SmartDashboard::PutBoolean(${q$2(d.name + "/S2 closed")},${n}.GetS2Closed().GetValue());frc::SmartDashboard::PutNumber(${q$2(d.name + "/quadrature rotations")},${n}.GetQuadraturePosition().GetValueAsDouble());`,
			`wpilib.SmartDashboard.putBoolean(${q$2(d.name + "/S2 closed")}, ${py}.get_s2_closed().value)\nwpilib.SmartDashboard.putNumber(${q$2(d.name + "/quadrature rotations")}, ${py}.get_quadrature_position().value_as_double)`
		];
	}
	if (a === "encoderLegacy" || a === "pigeonLegacy") {
		const cls = a === "encoderLegacy" ? "CANCoder" : "PigeonIMU";
		declare(`com.ctre.phoenix.sensors.${cls}`, `new com.ctre.phoenix.sensors.${cls}(${id})`, `ctre::phoenix::sensors::${cls}`, `{${id}}`, `phoenix5.sensors.${cls}(${id})`);
		const m = a === "encoderLegacy" ? [
			"getAbsolutePosition",
			"GetAbsolutePosition",
			"getAbsolutePosition"
		] : [
			"getFusedHeading",
			"GetFusedHeading",
			"getFusedHeading"
		];
		const scale = a === "encoderLegacy" ? "/360.0" : "";
		f.fields[0] += `\nprivate double legacyRead_${d.id}(){double value=${n}.${m[0]}()${scale};return ${n}.getLastError()==com.ctre.phoenix.ErrorCode.OK?value:Double.NaN;}`;
		f.fields[1] += `\ndouble legacyRead_${d.id}(){double value=${n}.${m[1]}()${scale};return ${n}.GetLastError()==ctre::phoenix::ErrorCode::OK?value:NAN;}`;
		calibrated([
			`legacyRead_${d.id}()`,
			`legacyRead_${d.id}()`,
			`(lambda value: value if ${py}.getLastError()==phoenix5.ErrorCode.OK else float('nan'))(${py}.${m[2]}()${scale})`
		]);
	}
	if (a === "navx") {
		declare("com.studica.frc.AHRS", `new com.studica.frc.AHRS(com.studica.frc.AHRS.NavXComType.${navxPort(d.interface)})`, "studica::AHRS", `{studica::AHRS::NavXComType::${navxPort(d.interface)}}`, `navx.AHRS(navx.AHRS.NavXComType.${navxPort(d.interface)})`);
		calibrated([
			`(${n}.isConnected()&&!${n}.isCalibrating()?${n}.getRotation2d().getDegrees():Double.NaN)`,
			`(${n}.IsConnected()&&!${n}.IsCalibrating()?${n}.GetRotation2d().Degrees().value():NAN)`,
			`(${py}.getRotation2d().degrees() if ${py}.isConnected() and not ${py}.isCalibrating() else float('nan'))`
		]);
	}
	if (a === "digital" || a === "digitalOut") {
		const cls = a === "digital" ? "DigitalInput" : "DigitalOutput";
		declare(cls, `new ${cls}(${ch})`, `frc::${cls}`, `{${ch}}`, `wpilib.${cls}(${ch})`);
		f.read = [
			`(${d.inverted ? "" : "!"}${n}.get()?1.0:0.0)`,
			`(${d.inverted ? "" : "!"}${n}.Get()?1.0:0.0)`,
			`1.0 if ${d.inverted ? "" : "not "}${py}.get() else 0.0`
		];
		if (a === "digitalOut") {
			f.set = [
				`${n}.set(value>0);`,
				`${n}.Set(value>0);`,
				`${py}.set(value > 0)`
			];
			f.stop = [
				`${n}.set(false);`,
				`${n}.Set(false);`,
				`${py}.set(False)`
			];
		}
	}
	if (a === "duty" || a === "analogEncoder") {
		const cls = a === "duty" ? "DutyCycleEncoder" : "AnalogEncoder";
		declare(cls, `new ${cls}(${ch})`, `frc::${cls}`, `{${ch}}`, `wpilib.${cls}(${ch})`);
		const read = [
			`${n}.get()`,
			`${n}.Get()`,
			`${py}.get()`
		];
		calibrated(a === "duty" ? [
			`(${n}.isConnected()?${read[0]}:Double.NaN)`,
			`(${n}.IsConnected()?${read[1]}:NAN)`,
			`(${read[2]} if ${py}.isConnected() else float('nan'))`
		] : read);
	}
	if (a === "quadrature") {
		declare("Encoder", `new Encoder(${ch},${d.channelB},${d.inverted})`, "frc::Encoder", `{${ch},${d.channelB},${d.inverted}}`, `wpilib.Encoder(${ch}, ${d.channelB}, ${d.inverted ? "True" : "False"})`);
		f.init = [
			`${n}.setDistancePerPulse(${d.scale});`,
			`${n}.SetDistancePerPulse(${d.scale});`,
			`${py}.setDistancePerPulse(${d.scale})`
		];
		f.read = [
			`${n}.getDistance()+${d.offset}`,
			`${n}.GetDistance()+${d.offset}`,
			`${py}.getDistance()+${d.offset}`
		];
	}
	if (a === "analog") {
		declare("AnalogInput", `new AnalogInput(${ch})`, "frc::AnalogInput", `{${ch}}`, `wpilib.AnalogInput(${ch})`);
		calibrated([
			`${n}.getVoltage()`,
			`${n}.GetVoltage()`,
			`${py}.getVoltage()`
		]);
	}
	if (a === "ultrasonic") {
		declare("Ultrasonic", `new Ultrasonic(${ch},${d.channelB})`, "frc::Ultrasonic", `{${ch},${d.channelB}}`, `wpilib.Ultrasonic(${ch}, ${d.channelB})`);
		f.init = [
			"Ultrasonic.setAutomaticMode(true);",
			"frc::Ultrasonic::SetAutomaticMode(true);",
			"wpilib.Ultrasonic.setAutomaticMode(True)"
		];
		calibrated([
			`(${n}.isRangeValid()?${n}.getRangeMM()/1000.0:Double.NaN)`,
			`(${n}.IsRangeValid()?${n}.GetRange().value():NAN)`,
			`(${py}.getRangeMM()/1000.0 if ${py}.isRangeValid() else float('nan'))`
		]);
	}
	if (a === "pdh" || a === "pdp") {
		const type = a === "pdh" ? "kRev" : "kCTRE";
		declare("PowerDistribution", `new PowerDistribution(${id},PowerDistribution.ModuleType.${type})`, "frc::PowerDistribution", `{${id},frc::PowerDistribution::ModuleType::${type}}`, `wpilib.PowerDistribution(${id}, wpilib.PowerDistribution.ModuleType.${type})`);
		f.read = [
			`${n}.getVoltage()`,
			`${n}.GetVoltage()`,
			`${py}.getVoltage()`
		];
		f.extra = [
			`SmartDashboard.putNumber(${q$2(d.name + "/total amps")},${n}.getTotalCurrent());SmartDashboard.putNumber(${q$2(d.name + "/temperature C")},${n}.getTemperature());for(int ch=0;ch<${a === "pdh" ? 24 : 16};ch++)SmartDashboard.putNumber(${q$2(d.name + "/channel ")}+ch+" amps",${n}.getCurrent(ch));`,
			`frc::SmartDashboard::PutNumber(${q$2(d.name + "/total amps")},${n}.GetTotalCurrent());frc::SmartDashboard::PutNumber(${q$2(d.name + "/temperature C")},${n}.GetTemperature());for(int ch=0;ch<${a === "pdh" ? 24 : 16};ch++)frc::SmartDashboard::PutNumber(${q$2(d.name + "/channel ")}+std::to_string(ch)+" amps",${n}.GetCurrent(ch));`,
			`wpilib.SmartDashboard.putNumber(${q$2(d.name + "/total amps")}, ${py}.getTotalCurrent())\nwpilib.SmartDashboard.putNumber(${q$2(d.name + "/temperature C")}, ${py}.getTemperature())\nfor ch in range(${a === "pdh" ? 24 : 16}): wpilib.SmartDashboard.putNumber(${q$2(d.name + "/channel ")} + str(ch) + ' amps', ${py}.getCurrent(ch))`
		];
	}
	if (a === "ph" || a === "pcm") {
		const type = a === "ph" ? "REVPH" : "CTREPCM";
		declare("Compressor", `new Compressor(${id},PneumaticsModuleType.${type})`, "frc::Compressor", `{${id},frc::PneumaticsModuleType::${type}}`, `wpilib.Compressor(${id}, wpilib.PneumaticsModuleType.${type})`);
		f.stop = [
			`${n}.disable();`,
			`${n}.Disable();`,
			`${py}.disable()`
		];
		f.extra = [
			`if(DriverStation.isEnabled()&&${d.compressor})${n}.enableDigital();else ${n}.disable();`,
			`if(frc::DriverStation::IsEnabled()&&${d.compressor})${n}.EnableDigital();else ${n}.Disable();`,
			`${py}.enableDigital() if wpilib.DriverStation.isEnabled() and ${d.compressor ? "True" : "False"} else ${py}.disable()`
		];
		f.read = [
			`${n}.getPressureSwitchValue()?1.0:0.0`,
			`${n}.GetPressureSwitchValue()?1.0:0.0`,
			`1.0 if ${py}.getPressureSwitchValue() else 0.0`
		];
	}
	if ([
		"solenoidRev",
		"solenoidCtre",
		"doubleRev",
		"doubleCtre"
	].includes(a || "")) {
		const hub = p.devices?.find((h) => h.id === d.module);
		const type = a.endsWith("Rev") ? "REVPH" : "CTREPCM", dbl = a.startsWith("double"), cls = dbl ? "DoubleSolenoid" : "Solenoid";
		const args = `${hub?.address ?? 0},PneumaticsModuleType.${type},${ch}${dbl ? "," + d.channelB : ""}`;
		declare(cls, `new ${cls}(${args})`, `frc::${cls}`, `{${args.replace("PneumaticsModuleType.", "frc::PneumaticsModuleType::")}}`, `wpilib.${cls}(${args.replace("PneumaticsModuleType.", "wpilib.PneumaticsModuleType.")})`);
		f.set = dbl ? [
			`${n}.set(value>0?DoubleSolenoid.Value.kForward:value<0?DoubleSolenoid.Value.kReverse:DoubleSolenoid.Value.kOff);`,
			`${n}.Set(value>0?frc::DoubleSolenoid::kForward:value<0?frc::DoubleSolenoid::kReverse:frc::DoubleSolenoid::kOff);`,
			`${py}.set(wpilib.DoubleSolenoid.Value.kForward if value>0 else wpilib.DoubleSolenoid.Value.kReverse if value<0 else wpilib.DoubleSolenoid.Value.kOff)`
		] : [
			`${n}.set(value>0);`,
			`${n}.Set(value>0);`,
			`${py}.set(value>0)`
		];
		f.stop = dbl ? [
			`${n}.set(DoubleSolenoid.Value.kOff);`,
			`${n}.Set(frc::DoubleSolenoid::kOff);`,
			`${py}.set(wpilib.DoubleSolenoid.Value.kOff)`
		] : [
			`${n}.set(false);`,
			`${n}.Set(false);`,
			`${py}.set(False)`
		];
	}
	if (a === "servo" || a === "blinkin") {
		const cls = a === "servo" ? "Servo" : "Spark";
		declare(cls, `new ${cls}(${ch})`, a === "servo" ? "frc::Servo" : "frc::Spark", `{${ch}}`, `wpilib.${a === "servo" ? "Servo" : "Spark"}(${ch})`);
		if (a === "servo") {
			f.init = [
				`${n}.setBoundsMicroseconds(${d.pulseMax},${Math.round((d.pulseMin + d.pulseMax) / 2)},${(d.pulseMin + d.pulseMax) / 2},${(d.pulseMin + d.pulseMax) / 2},${d.pulseMin});`,
				`${n}.SetBounds(units::microsecond_t{${d.pulseMax}},units::microsecond_t{${Math.round((d.pulseMin + d.pulseMax) / 2)}},units::microsecond_t{${Math.round((d.pulseMin + d.pulseMax) / 2)}},units::microsecond_t{${Math.round((d.pulseMin + d.pulseMax) / 2)}},units::microsecond_t{${d.pulseMin}});`,
				`${py}.setBounds(${d.pulseMax}, ${Math.round((d.pulseMin + d.pulseMax) / 2)}, ${Math.round((d.pulseMin + d.pulseMax) / 2)}, ${Math.round((d.pulseMin + d.pulseMax) / 2)}, ${d.pulseMin})`
			];
			f.set = [
				`${n}.set(Math.max(0,Math.min(1,value)));`,
				`${n}.Set(std::clamp(value,0.0,1.0));`,
				`${py}.set(max(0.0,min(1.0,value)))`
			];
			f.stop = [
				`${n}.setDisabled();`,
				`${n}.SetDisabled();`,
				`${py}.setDisabled()`
			];
		} else {
			f.set = [
				`${n}.set(value);`,
				`${n}.Set(value);`,
				`${py}.set(value)`
			];
			f.stop = [
				`${n}.set(0.99);`,
				`${n}.Set(0.99);`,
				`${py}.set(0.99)`
			];
		}
	}
	if (a === "color") {
		const port = d.interface === "onboard" ? "kOnboard" : "kMXP";
		declare("com.revrobotics.ColorSensorV3", `new com.revrobotics.ColorSensorV3(I2C.Port.${port})`, "rev::ColorSensorV3", `{frc::I2C::Port::${port}}`, `rev.ColorSensorV3(wpilib.I2C.Port.${port})`);
		f.read = [
			`(${n}.isConnected()?${n}.getProximity():Double.NaN)`,
			`(${n}.IsConnected()?${n}.GetProximity():NAN)`,
			`(${py}.getProximity() if ${py}.isConnected() else float('nan'))`
		];
		f.extra = [
			[
				"Red",
				"Green",
				"Blue",
				"IR"
			].map((k) => `SmartDashboard.putNumber(${q$2(d.name + "/" + k)},${n}.get${k}());`).join(""),
			[
				"Red",
				"Green",
				"Blue",
				"IR"
			].map((k) => `frc::SmartDashboard::PutNumber(${q$2(d.name + "/" + k)},${k === "IR" ? `${n}.GetIR()` : `${n}.GetRawColor().${k.toLowerCase()}`});`).join(""),
			[
				"Red",
				"Green",
				"Blue",
				"IR"
			].map((k) => `wpilib.SmartDashboard.putNumber(${q$2(d.name + "/" + k)}, ${k === "IR" ? `${py}.getIR()` : `${py}.getRawColor().${k.toLowerCase()}`})`).join("\n")
		];
	}
	if (a === "tof") {
		declare("com.playingwithfusion.TimeOfFlight", `new com.playingwithfusion.TimeOfFlight(${id})`, "pwf::TimeOfFlight", `{${id}}`, `playingwithfusion.TimeOfFlight(${id})`);
		f.init = [
			`${n}.setRangingMode(com.playingwithfusion.TimeOfFlight.RangingMode.Short,24);`,
			`${n}.SetRangingMode(pwf::TimeOfFlight::RangingMode::kShort,24);`,
			`${py}.setRangingMode(playingwithfusion.TimeOfFlight.RangingMode.kShort,24)`
		];
		calibrated([
			`(${n}.isRangeValid()?${n}.getRange()/1000.0:Double.NaN)`,
			`(${n}.IsRangeValid()?${n}.GetRange()/1000.0:NAN)`,
			`(${py}.getRange()/1000.0 if ${py}.isRangeValid() else float('nan'))`
		]);
	}
	if (a === "limelight") {
		declare("edu.wpi.first.networktables.NetworkTable", `edu.wpi.first.networktables.NetworkTableInstance.getDefault().getTable(${q$2(d.table)})`, "std::shared_ptr<nt::NetworkTable>", `=nt::NetworkTableInstance::GetDefault().GetTable(${q$2(d.table)})`, `ntcore.NetworkTableInstance.getDefault().getTable(${q$2(d.table)})`);
		f.fields[0] += `\nprivate double hb_${d.id}=-1,seen_${d.id}=-100;`;
		f.fields[1] += `\ndouble hb_${d.id}=-1,seen_${d.id}=-100;`;
		f.fields[2] += `\nself.hb_${d.id} = -1\nself.seen_${d.id} = -100`;
		f.extra = [
			`double hb=${n}.getEntry("hb").getDouble(-1);if(hb>=0&&hb!=hb_${d.id}){hb_${d.id}=hb;seen_${d.id}=Timer.getFPGATimestamp();}`,
			`double hb=${n}->GetNumber("hb",-1);if(hb>=0&&hb!=hb_${d.id}){hb_${d.id}=hb;seen_${d.id}=frc::Timer::GetFPGATimestamp().value();}`,
			`hb = ${py}.getNumber('hb', -1)\nif hb >= 0 and hb != self.hb_${d.id}:\n    self.hb_${d.id} = hb\n    self.seen_${d.id} = wpilib.Timer.getFPGATimestamp()`
		];
		f.read = [
			`(Timer.getFPGATimestamp()-seen_${d.id}<0.25?${n}.getEntry("tv").getDouble(0):Double.NaN)`,
			`(frc::Timer::GetFPGATimestamp().value()-seen_${d.id}<0.25?${n}->GetNumber("tv",0):NAN)`,
			`(${py}.getNumber('tv',0) if wpilib.Timer.getFPGATimestamp()-self.seen_${d.id}<0.25 else float('nan'))`
		];
		for (const key of [
			"tx",
			"ty",
			"ta",
			"tl",
			"cl"
		]) {
			f.extra[0] += `SmartDashboard.putNumber(${q$2(d.name + "/" + key)},${n}.getEntry(${q$2(key)}).getDouble(0));`;
			f.extra[1] += `frc::SmartDashboard::PutNumber(${q$2(d.name + "/" + key)},${n}->GetNumber(${q$2(key)},0));`;
			f.extra[2] += `\nwpilib.SmartDashboard.putNumber(${q$2(d.name + "/" + key)}, ${py}.getNumber(${q$2(key)},0))`;
		}
		f.extra[0] += `SmartDashboard.putNumberArray(${q$2(d.name + "/blue pose")},${n}.getEntry("botpose_wpiblue").getDoubleArray(new double[0]));`;
		f.extra[1] += `frc::SmartDashboard::PutNumberArray(${q$2(d.name + "/blue pose")},${n}->GetNumberArray("botpose_wpiblue",{}));`;
		f.extra[2] += `\nwpilib.SmartDashboard.putNumberArray(${q$2(d.name + "/blue pose")}, ${py}.getNumberArray('botpose_wpiblue',[]))`;
	}
	if (a === "canbus") {
		declare("com.ctre.phoenix6.CANBus", `new com.ctre.phoenix6.CANBus(${q$2(d.bus)})`, "ctre::phoenix6::CANBus", `{${q$2(d.bus)}}`, `phoenix6.CANBus(${q$2(d.bus)})`);
		f.read = [
			`${n}.getStatus().BusUtilization`,
			`${n}.GetStatus().BusUtilization`,
			`${py}.get_status().bus_utilization`
		];
	}
	if (a === "candle") {
		declare("com.ctre.phoenix6.hardware.CANdle", `new com.ctre.phoenix6.hardware.CANdle(${id},new com.ctre.phoenix6.CANBus(${q$2(d.bus)}))`, "ctre::phoenix6::hardware::CANdle", `{${id},ctre::phoenix6::CANBus{${q$2(d.bus)}}}`, `phoenix6.hardware.CANdle(${id}, phoenix6.CANBus(${q$2(d.bus)}))`);
		f.set = [
			`${n}.setControl(new com.ctre.phoenix6.controls.SolidColor(0,${d.count - 1}).withColor(new com.ctre.phoenix6.signals.RGBWColor(value>0?${d.red}:0,value>0?${d.green}:0,value>0?${d.blue}:0)));`,
			`${n}.SetControl(ctre::phoenix6::controls::SolidColor{0,${d.count - 1}}.WithColor(ctre::phoenix6::signals::RGBWColor{static_cast<uint8_t>(value>0?${d.red}:0),static_cast<uint8_t>(value>0?${d.green}:0),static_cast<uint8_t>(value>0?${d.blue}:0)}));`,
			`${py}.set_control(phoenix6.controls.SolidColor(0, ${d.count - 1}, phoenix6.signals.RGBWColor(${d.red} if value>0 else 0, ${d.green} if value>0 else 0, ${d.blue} if value>0 else 0)))`
		];
		f.stop = f.set.map((x) => x.replaceAll("value>0", "false"));
		f.stop[2] = f.set[2].replaceAll("value>0", "False");
		f.init = [
			`// Configure the physical LED strip type in Phoenix Tuner before use.\nfor(int slot=0;slot<8;slot++)${n}.setControl(new com.ctre.phoenix6.controls.EmptyAnimation(slot));`,
			`for(int slot=0;slot<8;slot++)${n}.SetControl(ctre::phoenix6::controls::EmptyAnimation{slot});`,
			`# Configure the physical LED strip type in Phoenix Tuner before use.\nfor slot in range(8): ${py}.set_control(phoenix6.controls.EmptyAnimation(slot))`
		];
	}
	if (a === "servoHub") {
		declare("com.revrobotics.servohub.ServoHub", `new com.revrobotics.servohub.ServoHub(${id})`, "rev::servohub::ServoHub", `{${id}}`, `rev.ServoHub(${id})`);
		const cj = `${n}.getServoChannel(com.revrobotics.servohub.ServoChannel.ChannelId.kChannelId${ch})`, cc = `${n}.GetServoChannel(rev::servohub::ServoChannel::ChannelId::kChannelId${ch})`, cp = `${py}.getServoChannel(rev.ServoChannel.ChannelId.kChannelId${ch})`;
		f.fields[0] += `\nprivate boolean ok_${d.id}=false;`;
		f.fields[1] += `\nbool ok_${d.id}=false;`;
		f.fields[2] += `\nself.ok_${d.id} = False`;
		f.init = [
			`var config_${d.id}=new com.revrobotics.servohub.config.ServoHubConfig();\nconfig_${d.id}.channel${ch}.pulseRange(${d.pulseMin},${Math.round((d.pulseMin + d.pulseMax) / 2)},${d.pulseMax}).disableBehavior(com.revrobotics.servohub.config.ServoChannelConfig.BehaviorWhenDisabled.kDoNotSupplyPower);\nfor(int i=0;i<3&&!ok_${d.id};i++)ok_${d.id}=${n}.configure(config_${d.id},com.revrobotics.ResetMode.kResetSafeParameters)==com.revrobotics.REVLibError.kOk;`,
			`rev::servohub::ServoHubConfig config_${d.id};config_${d.id}.channel${ch}.PulseRange(${d.pulseMin},${Math.round((d.pulseMin + d.pulseMax) / 2)},${d.pulseMax}).DisableBehavior(rev::servohub::ServoChannelConfig::BehaviorWhenDisabled::kDoNotSupplyPower);for(int i=0;i<3&&!ok_${d.id};i++)ok_${d.id}=${n}.Configure(config_${d.id},rev::ResetMode::kResetSafeParameters)==rev::REVLibError::kOk;`,
			`config_${d.id} = rev.ServoHubConfig()\nconfig_${d.id}.channel${ch}.pulseRange(${d.pulseMin},${Math.round((d.pulseMin + d.pulseMax) / 2)},${d.pulseMax}).disableBehavior(rev.ServoChannelConfig.BehaviorWhenDisabled.kDoNotSupplyPower)\nfor _ in range(3):\n    self.ok_${d.id} = ${py}.configure(config_${d.id}, rev.ResetMode.kResetSafeParameters) == rev.REVLibError.kOk\n    if self.ok_${d.id}: break`
		];
		for (let channel = 0; channel < 6; channel++) {
			f.init[0] += `\n${n}.getServoChannel(com.revrobotics.servohub.ServoChannel.ChannelId.kChannelId${channel}).setEnabled(false);${n}.getServoChannel(com.revrobotics.servohub.ServoChannel.ChannelId.kChannelId${channel}).setPowered(false);`;
			f.init[1] += `\n${n}.GetServoChannel(rev::servohub::ServoChannel::ChannelId::kChannelId${channel}).SetEnabled(false);${n}.GetServoChannel(rev::servohub::ServoChannel::ChannelId::kChannelId${channel}).SetPowered(false);`;
			f.init[2] += `\n${py}.getServoChannel(rev.ServoChannel.ChannelId.kChannelId${channel}).setEnabled(False)\n${py}.getServoChannel(rev.ServoChannel.ChannelId.kChannelId${channel}).setPowered(False)`;
		}
		f.set = [
			`if(!ok_${d.id})return;${cj}.setPulseWidth((int)(${d.pulseMin}+Math.max(0,Math.min(1,value))*${d.pulseMax - d.pulseMin}));${cj}.setPowered(true);${cj}.setEnabled(true);`,
			`if(!ok_${d.id})return;${cc}.SetPulseWidth(static_cast<int>(${d.pulseMin}+std::clamp(value,0.0,1.0)*${d.pulseMax - d.pulseMin}));${cc}.SetPowered(true);${cc}.SetEnabled(true);`,
			`if not self.ok_${d.id}: return\n${cp}.setPulseWidth(int(${d.pulseMin}+max(0.0,min(1.0,value))*${d.pulseMax - d.pulseMin}))\n${cp}.setPowered(True)\n${cp}.setEnabled(True)`
		];
		f.stop = [
			`${cj}.setEnabled(false);${cj}.setPowered(false);`,
			`${cc}.SetEnabled(false);${cc}.SetPowered(false);`,
			`${cp}.setEnabled(False)\n${cp}.setPowered(False)`
		];
	}
	return f;
}
const indent = (s, n = 8) => s.split("\n").filter((x) => x.trim()).map((x) => " ".repeat(n) + x).join("\n");
function deviceSources(p) {
	const ds = (p.devices || []).filter((d) => !["passive", "custom"].includes(productById(d.product)?.adapter || "custom"));
	const fs = ds.map((d) => ({
		d,
		f: fragment(d, p)
	}));
	const actuators = fs.filter((x) => isActuator(productById(x.d.product).adapter));
	const compressors = fs.filter((x) => ["ph", "pcm"].includes(productById(x.d.product).adapter));
	const java = `package frc.robot;
import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.motorcontrol.*;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
/** Peripheral ownership, telemetry and guarded outputs. Each action uses its assigned mechanism's requirement. */
public final class HardwareIO extends SubsystemBase {
${fs.map((x) => x.f.fields[0]).join("\n")}
${actuators.map(({ d }) => `private double last_${d.id}=-100;`).join("\n")}
public HardwareIO(){${fs.map((x) => x.f.init[0]).join("\n")}stopAll();}
public void stopAll(){${actuators.map(({ d }) => `stop_${d.id}();`).join("")}${compressors.map((x) => x.f.stop[0]).join("")}}
${fs.map(({ d, f }) => `public double read_${d.id}(){return ${f.read[0]};}`).join("\n")}
${actuators.map(({ d, f }) => `public void set_${d.id}(double value){if(!DriverStation.isEnabled()||!Double.isFinite(value)){stop_${d.id}();return;}last_${d.id}=Timer.getFPGATimestamp();${f.set[0]}}\npublic void stop_${d.id}(){${f.stop[0]}}`).join("\n")}
@Override public void periodic(){
${actuators.map(({ d }) => `if(DriverStation.isDisabled()||Timer.getFPGATimestamp()-last_${d.id}>0.1)stop_${d.id}();`).join("\n")}
${fs.map(({ d, f }) => `{${f.extra[0]}double value=read_${d.id}();${isSensor(productById(d.product).adapter) ? `SmartDashboard.putBoolean(${q$2(d.name + "/valid")},Double.isFinite(value));` : ""}if(Double.isFinite(value))SmartDashboard.putNumber(${q$2(d.name + "/value")},value);}`).join("\n")}
}
}
`;
	const adapters = new Set(ds.map((d) => productById(d.product).adapter));
	const headers = [
		"frc/DigitalInput.h",
		"frc/DigitalOutput.h",
		"frc/DutyCycleEncoder.h",
		"frc/AnalogEncoder.h",
		"frc/Encoder.h",
		"frc/AnalogInput.h",
		"frc/Ultrasonic.h",
		"frc/PowerDistribution.h",
		"frc/Compressor.h",
		"frc/Solenoid.h",
		"frc/DoubleSolenoid.h",
		"frc/Servo.h",
		"frc/I2C.h",
		"frc/motorcontrol/Spark.h",
		"frc/Timer.h",
		"frc/DriverStation.h",
		"frc/smartdashboard/SmartDashboard.h",
		"frc2/command/SubsystemBase.h",
		"ctre/phoenix6/CANBus.hpp"
	];
	for (const [a, h] of Object.entries({
		cancoder: "ctre/phoenix6/CANcoder.hpp",
		canrange: "ctre/phoenix6/CANrange.hpp",
		candi: "ctre/phoenix6/CANdi.hpp",
		candle: "ctre/phoenix6/CANdle.hpp",
		pigeon: "ctre/phoenix6/Pigeon2.hpp",
		pigeonLegacy: "ctre/phoenix/sensors/PigeonIMU.h",
		encoderLegacy: "ctre/phoenix/sensors/CANCoder.h",
		navx: "studica/AHRS.h",
		color: "rev/ColorSensorV3.h",
		tof: "TimeOfFlight.h",
		limelight: "networktables/NetworkTableInstance.h",
		servoHub: "rev/ServoHub.h"
	})) if (adapters.has(a)) headers.push(h);
	if (adapters.has("servoHub")) headers.push("rev/config/ServoHubConfig.h");
	const cpp = `#pragma once
#include <cmath>
#include <algorithm>
#include <memory>
#include <string>
${headers.map((h) => "#include <" + h + ">").join("\n")}
class HardwareIO:public frc2::SubsystemBase {
${fs.map((x) => x.f.fields[1]).join("\n")}
${actuators.map(({ d }) => `double last_${d.id}=-100;`).join("\n")}
public:
HardwareIO(){${fs.map((x) => x.f.init[1]).join("\n")}StopAll();}
void StopAll(){${actuators.map(({ d }) => `stop_${d.id}();`).join("")}${compressors.map((x) => x.f.stop[1]).join("")}}
${fs.map(({ d, f }) => `double read_${d.id}(){return ${f.read[1]};}`).join("\n")}
${actuators.map(({ d, f }) => `void set_${d.id}(double value){if(!frc::DriverStation::IsEnabled()||!std::isfinite(value)){stop_${d.id}();return;}last_${d.id}=frc::Timer::GetFPGATimestamp().value();${f.set[1]}}\nvoid stop_${d.id}(){${f.stop[1]}}`).join("\n")}
void Periodic() override {
${actuators.map(({ d }) => `if(frc::DriverStation::IsDisabled()||frc::Timer::GetFPGATimestamp().value()-last_${d.id}>0.1)stop_${d.id}();`).join("\n")}
${fs.map(({ d, f }) => `{${f.extra[1]}double value=read_${d.id}();${isSensor(productById(d.product).adapter) ? `frc::SmartDashboard::PutBoolean(${q$2(d.name + "/valid")},std::isfinite(value));` : ""}if(std::isfinite(value))frc::SmartDashboard::PutNumber(${q$2(d.name + "/value")},value);}`).join("\n")}
}
};
`;
	const python = `import math
import commands2
import wpilib
import rev
import phoenix6
import phoenix6.hardware
import phoenix6.controls
import phoenix6.signals
${adapters.has("navx") ? "import navx" : ""}
${adapters.has("tof") ? "import playingwithfusion" : ""}
${adapters.has("limelight") ? "import ntcore" : ""}
${adapters.has("pigeonLegacy") || adapters.has("encoderLegacy") ? "import phoenix5\nimport phoenix5.sensors" : ""}

class HardwareIO(commands2.Subsystem):
    def __init__(self):
        super().__init__()
${fs.map((x) => indent(x.f.fields[2])).join("\n")}
${actuators.map(({ d }) => `        self.last_${d.id} = -100`).join("\n")}
${fs.map((x) => indent(x.f.init[2])).join("\n")}
        self.stop_all()

    def stop_all(self):
${actuators.length ? actuators.map(({ d }) => `        self.stop_${d.id}()`).join("\n") : "        pass"}
${compressors.map((x) => indent(x.f.stop[2])).join("\n")}
${fs.map(({ d, f }) => `\n    def read_${d.id}(self):\n        return ${f.read[2]}`).join("\n")}
${actuators.map(({ d, f }) => `\n    def set_${d.id}(self, value):\n        if not wpilib.DriverStation.isEnabled() or not math.isfinite(value):\n            self.stop_${d.id}()\n            return\n        self.last_${d.id} = wpilib.Timer.getFPGATimestamp()\n${indent(f.set[2])}\n\n    def stop_${d.id}(self):\n${indent(f.stop[2])}`).join("\n")}

    def periodic(self):
${actuators.map(({ d }) => `        if wpilib.DriverStation.isDisabled() or wpilib.Timer.getFPGATimestamp()-self.last_${d.id}>0.1: self.stop_${d.id}()`).join("\n")}
${fs.length ? fs.map(({ d, f }) => `${indent(f.extra[2])}\n        value = self.read_${d.id}()\n${isSensor(productById(d.product).adapter) ? `        wpilib.SmartDashboard.putBoolean(${q$2(d.name + "/valid")}, math.isfinite(value))` : ""}\n        if math.isfinite(value): wpilib.SmartDashboard.putNumber(${q$2(d.name + "/value")}, value)`).join("\n") : "        pass"}
`;
	return p.language === "Java" ? { "src/main/java/frc/robot/HardwareIO.java": java } : p.language === "C++" ? { "src/main/include/HardwareIO.h": cpp } : { "peripherals.py": python };
}
//#endregion
//#region lib/gen-java.ts
const q$1 = JSON.stringify;
function javaSources(p) {
	const d = p.drive, c = p.controls;
	const motor = (m) => `new MotorIO(${q$1(m.type)}, ${m.can}, ${m.inverted}, ${m.sensorSign}, ${m.current}, ${m.limit}, ${q$1(m.bus || "rio")}, ${q$1(m.motorKind || "default")})`;
	const driveMotors = (side) => p.motors.filter((m) => m.role === side).map(motor).join(", ");
	const mechanisms = p.subsystems.filter((s) => s.id !== "drive");
	return {
		"src/main/java/frc/robot/Robot.java": `package frc.robot;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.DataLogManager;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
public class Robot extends TimedRobot {
  private RobotContainer container;
  private Command autonomous;
  @Override public void robotInit() { DataLogManager.start(); DriverStation.startDataLog(DataLogManager.getLog()); container = new RobotContainer(); }
  @Override public void robotPeriodic() { CommandScheduler.getInstance().run(); }
  @Override public void autonomousInit() { container.stopAll(); autonomous = container.autonomous(); if (autonomous != null) CommandScheduler.getInstance().schedule(autonomous); }
  @Override public void teleopInit() { if (autonomous != null) autonomous.cancel(); container.stopAll(); }
  @Override public void disabledInit() { CommandScheduler.getInstance().cancelAll(); if (container != null) container.stopAll(); }
  @Override public void testInit() { CommandScheduler.getInstance().cancelAll(); container.stopAll(); }
}
`,
		"src/main/java/frc/robot/Main.java": `package frc.robot;
import edu.wpi.first.wpilibj.RobotBase;
public final class Main { private Main() {} public static void main(String... args) { RobotBase.startRobot(Robot::new); } }
`,
		"src/main/java/frc/robot/MotorIO.java": javaMotor(p),
		"src/main/java/frc/robot/Mechanism.java": `package frc.robot;
import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj2.command.*;
/** Owns every motor in one mechanism and supplies bounded commands. */
public final class Mechanism extends SubsystemBase {
  private final MotorIO[] motors; private double last=0;
  public Mechanism(String name, MotorIO... motors) { setName(name); this.motors=motors; }
  public void set(double output) { last=Timer.getFPGATimestamp(); for(var motor:motors) motor.voltage(output*12.0); }
  public void stop() { for(var motor:motors) motor.stop(); }
  public Command action(double output,double timeout) { return runEnd(()->set(output),this::stop).withTimeout(timeout); }
  @Override public void periodic() { if(DriverStation.isDisabled()||Timer.getFPGATimestamp()-last>0.1) stop(); }
}
`,
		"src/main/java/frc/robot/Drive.java": `package frc.robot;
import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.smartdashboard.*;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.*;
import edu.wpi.first.math.kinematics.*;
import edu.wpi.first.math.controller.PIDController;
import com.ctre.phoenix6.hardware.Pigeon2;
import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.config.RobotConfig;
import com.pathplanner.lib.controllers.PPLTVController;
public final class Drive extends SubsystemBase {
  private final MotorIO[] left={${driveMotors("left")}};
  private final MotorIO[] right={${driveMotors("right")}};
  private final ${d.gyro === "Pigeon2" ? `Pigeon2 gyro=new Pigeon2(${d.gyroCan},new com.ctre.phoenix6.CANBus(${q$1(d.gyroBus || "rio")}))` : d.gyro === "NavX" ? `com.studica.frc.AHRS gyro=new com.studica.frc.AHRS(com.studica.frc.AHRS.NavXComType.${navxPort(d.navxInterface)})` : "ADXRS450_Gyro gyro=new ADXRS450_Gyro()"};
  private final double metersPerRotation=Math.PI*${d.wheelDiameter}/${d.gearing};
  private final DifferentialDriveKinematics kinematics=new DifferentialDriveKinematics(${d.trackWidth});
  private final DifferentialDriveOdometry odometry;
  private final PIDController leftPID=new PIDController(${d.kP},0,0),rightPID=new PIDController(${d.kP},0,0);
  private final Field2d field=new Field2d();
  private double last=0; private boolean autoReady=false;
  public Drive() {
    ${d.gyro === "ADXRS450" ? "gyro.calibrate();" : ""}
    odometry=new DifferentialDriveOdometry(heading(),distance(left),distance(right));
    SmartDashboard.putData("Robot pose",field);
    try { AutoBuilder.configure(this::pose,this::resetPose,this::speeds,(speeds,feedforwards)->driveSpeeds(speeds),new PPLTVController(0.02),RobotConfig.fromGUISettings(),()->DriverStation.getAlliance().orElse(DriverStation.Alliance.Blue)==DriverStation.Alliance.Red,this);autoReady=true; }
    catch(Exception e) { DriverStation.reportError("Autonomous configuration failed: "+e.getMessage(),false); }
  }
  private Rotation2d heading() { return gyro.getRotation2d(); }
  private double distance(MotorIO[] motors) { double sum=0;for(var m:motors)sum+=m.position();return motors.length==0?0:sum/motors.length*metersPerRotation; }
  private double velocity(MotorIO[] motors) { double sum=0;for(var m:motors)sum+=m.velocity();return motors.length==0?0:sum/motors.length*metersPerRotation; }
  public Pose2d pose() { return odometry.getPoseMeters(); }
  public void resetPose(Pose2d pose) { odometry.resetPosition(heading(),distance(left),distance(right),pose);leftPID.reset();rightPID.reset(); }
  public ChassisSpeeds speeds() { return kinematics.toChassisSpeeds(new DifferentialDriveWheelSpeeds(velocity(left),velocity(right))); }
  public boolean autoReady() { return autoReady; }
  private void voltage(double l,double r) { last=Timer.getFPGATimestamp();for(var m:left)if(!m.ready())l=r=0;for(var m:right)if(!m.ready())l=r=0;for(var m:left)m.voltage(l);for(var m:right)m.voltage(r); }
  public void stop() { voltage(0,0);leftPID.reset();rightPID.reset(); }
  public void arcade(double forward,double turn) {
    if(!DriverStation.isTeleopEnabled()) { stop();return; }
    double l=forward-turn,r=forward+turn,scale=Math.max(1,Math.max(Math.abs(l),Math.abs(r)));
    voltage(l/scale*12*${c.maxOutput},r/scale*12*${c.maxOutput});
  }
  private double ff(double velocity) { return Math.abs(velocity)<0.001?0:Math.copySign(${d.kS},velocity)+${d.kV}*velocity; }
  private void driveSpeeds(ChassisSpeeds speeds) {
    var wheels=kinematics.toWheelSpeeds(speeds);wheels.desaturate(${d.maxSpeed});
    voltage(ff(wheels.leftMetersPerSecond)+leftPID.calculate(velocity(left),wheels.leftMetersPerSecond),ff(wheels.rightMetersPerSecond)+rightPID.calculate(velocity(right),wheels.rightMetersPerSecond));
  }
  @Override public void periodic() {
    if(DriverStation.isDisabled()||Timer.getFPGATimestamp()-last>0.1)stop();
    odometry.update(heading(),distance(left),distance(right));field.setRobotPose(pose());
    SmartDashboard.putNumber("Drive/left meters",distance(left));SmartDashboard.putNumber("Drive/right meters",distance(right));SmartDashboard.putBoolean("Drive/auto configured",autoReady);
  }
}
`,
		"src/main/java/frc/robot/RobotContainer.java": `package frc.robot;
import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.smartdashboard.*;
import edu.wpi.first.math.MathUtil;
import edu.wpi.first.wpilibj2.command.*;
import edu.wpi.first.wpilibj2.command.button.Trigger;
import com.pathplanner.lib.auto.NamedCommands;
import com.pathplanner.lib.commands.PathPlannerAuto;
public final class RobotContainer {
  private final Drive drive=new Drive();
  private final HardwareIO hardware=new HardwareIO();
  private final GenericHID driver=new GenericHID(${c.driverPort}),operator=new GenericHID(${c.operatorPort});
  ${mechanisms.map((s) => `private final Mechanism mechanism_${s.id}=new Mechanism(${q$1(s.name)}${p.motors.filter((m) => m.subsystem === s.id).map((m) => ", " + motor(m)).join("")});`).join("\n  ")}
  private final SendableChooser<Command> chooser=new SendableChooser<>();
  public RobotContainer() {
    drive.setDefaultCommand(drive.runEnd(()->drive.arcade(${c.forwardSign}*MathUtil.applyDeadband(driver.getRawAxis(${c.forwardAxis}),${c.deadband}),${c.turnSign}*MathUtil.applyDeadband(driver.getRawAxis(${c.turnAxis}),${c.deadband})),drive::stop));
    ${[...p.commands, ...p.routines || []].map((x) => `NamedCommands.registerCommand(${q$1(x.id)},action_${x.id}());`).join("\n    ")}
    ${p.bindings.map((b) => `new Trigger(()->DriverStation.isTeleopEnabled() && ${b.controller}.getRawButton(${b.button})).${b.behavior === "whileHeld" ? "whileTrue" : b.behavior === "onPress" ? "onTrue" : "toggleOnTrue"}(action_${b.command}());`).join("\n    ")}
    chooser.setDefaultOption("Do nothing",Commands.none());
    if(drive.autoReady()) try { chooser.addOption(${q$1(p.auto.name)},new PathPlannerAuto(${q$1(p.auto.name)}).withTimeout(15).finallyDo(interrupted->stopAll())); } catch(Exception e) { DriverStation.reportError("Auto failed to load: "+e.getMessage(),false); }
    SmartDashboard.putData("Auto chooser",chooser);
  }
  ${p.commands.map(javaAction).join("\n  ")}
  ${(p.routines || []).map((r) => routineSource(r, "Java")).join("\n  ")}
  public Command autonomous() { return chooser.getSelected(); }
  public void stopAll() { drive.stop(); hardware.stopAll(); ${mechanisms.map((s) => `mechanism_${s.id}.stop();`).join(" ")} }
}
`
	};
}
//#endregion
//#region lib/gen-python.ts
function pythonSources(p) {
	return {
		"robot.py": `import math
import commands2
import wpilib
from wpimath import applyDeadband
from commands2.button import Trigger
from pathplannerlib.auto import NamedCommands, PathPlannerAuto
from config import CONFIG
from hardware import MotorIO, Mechanism
from drive import Drive
from peripherals import HardwareIO

class Robot(wpilib.TimedRobot):
    def robotInit(self):
        wpilib.DataLogManager.start()
        wpilib.DriverStation.startDataLog(wpilib.DataLogManager.getLog())
        self.drive = Drive()
        self.hardware = HardwareIO()
        self.driver = wpilib.Joystick(CONFIG['controls']['driverPort'])
        self.operator = wpilib.Joystick(CONFIG['controls']['operatorPort'])
        self.mechanisms = {s['id']: Mechanism(s['name'], [MotorIO(m) for m in CONFIG['motors'] if m['subsystem'] == s['id']]) for s in CONFIG['subsystems'] if s['id'] != 'drive'}
        self.drive.setDefaultCommand(self.drive.runEnd(self.teleop_drive, self.drive.stop))
        for command in CONFIG['commands'] + CONFIG.get('routines', []):
            NamedCommands.registerCommand(command['id'], self.action(command['id']))
        self.triggers = []
        for binding in CONFIG['bindings']:
            controller = self.driver if binding['controller'] == 'driver' else self.operator
            trigger = Trigger(lambda controller=controller, button=binding['button']: wpilib.DriverStation.isTeleopEnabled() and controller.getRawButton(button))
            getattr(trigger, {'whileHeld': 'whileTrue', 'onPress': 'onTrue', 'toggle': 'toggleOnTrue'}[binding['behavior']])(self.action(binding['command']))
            self.triggers.append(trigger)
        self.chooser = wpilib.SendableChooser()
        self.chooser.setDefaultOption('Do nothing', commands2.cmd.none())
        if self.drive.auto_ready:
            try:
                auto = PathPlannerAuto(CONFIG['auto']['name']).withTimeout(15).finallyDo(lambda interrupted: self.stop_all())
                self.chooser.addOption(CONFIG['auto']['name'], auto)
            except Exception as error:
                wpilib.reportError('Autonomous failed to load: ' + str(error))
        wpilib.SmartDashboard.putData('Auto chooser', self.chooser)
        self.autonomous = None

    ${(p.routines || []).map((r) => routineSource(r, "Python").replaceAll("\n", "\n    ")).join("\n\n    ")}

    def action(self, command_id):
        ${(p.routines || []).map((r) => `if command_id == ${JSON.stringify(r.id)}: return self.routine_${r.id}()`).join("\n        ")}
        c = next(c for c in CONFIG['commands'] if c['id'] == command_id)
        owner = self.mechanisms[c['subsystem']]
        stop = getattr(self.hardware, 'stop_' + c['device']) if c.get('device') else owner.stop
        setter = getattr(self.hardware, 'set_' + c['device']) if c.get('device') else owner.set
        def should_stop():
            if not c.get('untilDevice'): return False
            value = getattr(self.hardware, 'read_' + c['untilDevice'])()
            return not math.isfinite(value) or (value <= c.get('threshold', 0.5) if c.get('condition') == 'below' else value >= c.get('threshold', 0.5))
        def execute():
            if should_stop(): stop()
            else: setter(c['output'])
        command = owner.runEnd(execute, stop).withTimeout(c['timeout'])
        if c.get('untilDevice'): command = command.until(should_stop)
        return command.withName(c['name'])

    def teleop_drive(self):
        c = CONFIG['controls']
        self.drive.arcade(c['forwardSign'] * applyDeadband(self.driver.getRawAxis(c['forwardAxis']), c['deadband']), c['turnSign'] * applyDeadband(self.driver.getRawAxis(c['turnAxis']), c['deadband']))

    def robotPeriodic(self):
        commands2.CommandScheduler.getInstance().run()

    def autonomousInit(self):
        self.stop_all()
        self.autonomous = self.chooser.getSelected()
        if self.autonomous is not None:
            self.autonomous.schedule()

    def teleopInit(self):
        if self.autonomous is not None:
            self.autonomous.cancel()
        self.stop_all()

    def disabledInit(self):
        commands2.CommandScheduler.getInstance().cancelAll()
        self.stop_all()

    def testInit(self):
        commands2.CommandScheduler.getInstance().cancelAll()
        self.stop_all()

    def stop_all(self):
        self.hardware.stop_all()
        self.drive.stop()
        for mechanism in self.mechanisms.values():
            mechanism.stop()
`,
		"config.py": `# Generated configuration. Edit the project in RobotForge and re-export.\nimport json\nCONFIG = json.loads(${JSON.stringify(JSON.stringify(p))})\n`,
		"hardware.py": `import math
import commands2
import wpilib
import rev
from phoenix6.hardware import TalonFX
from phoenix6.configs import TalonFXConfiguration
from phoenix6.controls import VoltageOut
from phoenix6.signals import InvertedValue, NeutralModeValue

${pythonMotor(p)}
class Mechanism(commands2.Subsystem):
    def __init__(self, name, motors):
        super().__init__()
        self.setName(name)
        self.motors = motors
        self.last = 0.0

    def set(self, output):
        self.last = wpilib.Timer.getFPGATimestamp()
        for motor in self.motors:
            motor.voltage(output * 12.0)

    def stop(self):
        for motor in self.motors:
            motor.stop()

    def action(self, output, timeout):
        return self.runEnd(lambda: self.set(output), self.stop).withTimeout(timeout)

    def periodic(self):
        if wpilib.DriverStation.isDisabled() or wpilib.Timer.getFPGATimestamp() - self.last > 0.1:
            self.stop()
`,
		"drive.py": `import math
import commands2
import wpilib
from wpimath.kinematics import DifferentialDriveKinematics, DifferentialDriveOdometry, DifferentialDriveWheelSpeeds
from wpimath.controller import PIDController
from phoenix6 import CANBus
from phoenix6.hardware import Pigeon2
${p.drive.gyro === "NavX" ? "import navx" : ""}
from pathplannerlib.auto import AutoBuilder
from pathplannerlib.config import RobotConfig
from pathplannerlib.controller import PPLTVController
from hardware import MotorIO
from config import CONFIG

class Drive(commands2.Subsystem):
    def __init__(self):
        super().__init__()
        self.d = CONFIG['drive']
        self.left = [MotorIO(m) for m in CONFIG['motors'] if m['role'] == 'left']
        self.right = [MotorIO(m) for m in CONFIG['motors'] if m['role'] == 'right']
        self.gyro = Pigeon2(self.d['gyroCan'], CANBus(self.d.get('gyroBus','rio'))) if self.d['gyro'] == 'Pigeon2' else ${p.drive.gyro === "NavX" ? `navx.AHRS(navx.AHRS.NavXComType.${navxPort(p.drive.navxInterface)})` : "wpilib.ADXRS450_Gyro()"}
        if self.d['gyro'] == 'ADXRS450' and wpilib.RobotBase.isReal():
            self.gyro.calibrate()
        self.meters_per_rotation = math.pi * self.d['wheelDiameter'] / self.d['gearing']
        self.kinematics = DifferentialDriveKinematics(self.d['trackWidth'])
        self.odometry = DifferentialDriveOdometry(self.heading(), self.distance(self.left), self.distance(self.right))
        self.left_pid = PIDController(self.d['kP'], 0, 0)
        self.right_pid = PIDController(self.d['kP'], 0, 0)
        self.field = wpilib.Field2d()
        self.last = 0.0
        self.auto_ready = False
        wpilib.SmartDashboard.putData('Robot pose', self.field)
        try:
            AutoBuilder.configure(self.pose, self.reset_pose, self.speeds, lambda speeds, ff: self.drive_speeds(speeds), PPLTVController(0.02), RobotConfig.fromGUISettings(), lambda: wpilib.DriverStation.getAlliance() == wpilib.DriverStation.Alliance.kRed, self)
            self.auto_ready = True
        except Exception as error:
            wpilib.reportError('Autonomous configuration failed: ' + str(error))

    def heading(self):
        return self.gyro.getRotation2d() if self.d['gyro'] == 'ADXRS450' else self.gyro.getRotation2d()

    def distance(self, motors):
        return sum(m.position() for m in motors) / max(1, len(motors)) * self.meters_per_rotation

    def velocity(self, motors):
        return sum(m.velocity() for m in motors) / max(1, len(motors)) * self.meters_per_rotation

    def pose(self):
        return self.odometry.getPose()

    def reset_pose(self, pose):
        self.odometry.resetPosition(self.heading(), self.distance(self.left), self.distance(self.right), pose)
        self.left_pid.reset()
        self.right_pid.reset()

    def speeds(self):
        return self.kinematics.toChassisSpeeds(DifferentialDriveWheelSpeeds(self.velocity(self.left), self.velocity(self.right)))

    def voltage(self, left, right):
        self.last = wpilib.Timer.getFPGATimestamp()
        if not all(m.configured for m in self.left + self.right):
            left = right = 0.0
        for motor in self.left:
            motor.voltage(left)
        for motor in self.right:
            motor.voltage(right)

    def stop(self):
        self.voltage(0, 0)
        self.left_pid.reset()
        self.right_pid.reset()

    def arcade(self, forward, turn):
        if not wpilib.DriverStation.isTeleopEnabled():
            self.stop()
            return
        left, right = forward - turn, forward + turn
        scale = max(1, abs(left), abs(right))
        cap = CONFIG['controls']['maxOutput'] * 12
        self.voltage(left / scale * cap, right / scale * cap)

    def feedforward(self, speed):
        return 0 if abs(speed) < 0.001 else math.copysign(self.d['kS'], speed) + self.d['kV'] * speed

    def drive_speeds(self, speeds):
        wheels = self.kinematics.toWheelSpeeds(speeds)
        wheels.desaturate(self.d['maxSpeed'])
        self.voltage(self.feedforward(wheels.left) + self.left_pid.calculate(self.velocity(self.left), wheels.left), self.feedforward(wheels.right) + self.right_pid.calculate(self.velocity(self.right), wheels.right))

    def periodic(self):
        if wpilib.DriverStation.isDisabled() or wpilib.Timer.getFPGATimestamp() - self.last > 0.1:
            self.stop()
        self.odometry.update(self.heading(), self.distance(self.left), self.distance(self.right))
        self.field.setRobotPose(self.pose())
        wpilib.SmartDashboard.putNumber('Drive/left meters', self.distance(self.left))
        wpilib.SmartDashboard.putNumber('Drive/right meters', self.distance(self.right))
        wpilib.SmartDashboard.putBoolean('Drive/auto configured', self.auto_ready)
`,
		"pyproject.toml": pythonProjectFile(p)
	};
}
//#endregion
//#region lib/gen-cpp.ts
const q = JSON.stringify;
function cppSources(p) {
	const d = p.drive, c = p.controls;
	const motor = (m) => `std::make_shared<MotorIO>(${q(m.type)},${m.can},${m.inverted},${m.sensorSign},${m.current},${m.limit},${q(m.bus || "rio")},${q(m.motorKind || "default")})`;
	const side = (role) => p.motors.filter((m) => m.role === role).map(motor).join(",");
	const mechanisms = p.subsystems.filter((s) => s.id !== "drive");
	return { "src/main/cpp/Robot.cpp": `#include "HardwareIO.h"
${d.gyro === "NavX" ? "#include <studica/AHRS.h>" : ""}
#include <algorithm>
#include <cmath>
#include <memory>
#include <optional>
#include <string>
#include <vector>
#include <frc/TimedRobot.h>
#include <frc/RobotBase.h>
#include <frc/DriverStation.h>
#include <frc/Errors.h>
#include <frc/Timer.h>
#include <frc/DataLogManager.h>
#include <frc/GenericHID.h>
#include <frc/DigitalInput.h>
#include <frc/ADXRS450_Gyro.h>
#include <frc/geometry/Pose2d.h>
#include <frc/kinematics/DifferentialDriveKinematics.h>
#include <frc/kinematics/DifferentialDriveOdometry.h>
#include <frc/controller/PIDController.h>
#include <frc/smartdashboard/SmartDashboard.h>
#include <frc/smartdashboard/Field2d.h>
#include <frc/smartdashboard/SendableChooser.h>
#include <frc2/command/SubsystemBase.h>
#include <frc2/command/CommandScheduler.h>
#include <frc2/command/Commands.h>
#include <frc2/command/button/Trigger.h>
#include <rev/SparkMax.h>
#include <rev/SparkFlex.h>
#include <rev/config/SparkMaxConfig.h>
#include <rev/config/SparkFlexConfig.h>
#include <ctre/phoenix6/TalonFX.hpp>
#include <ctre/phoenix6/Pigeon2.hpp>
#include <pathplanner/lib/auto/AutoBuilder.h>
#include <pathplanner/lib/auto/NamedCommands.h>
#include <pathplanner/lib/commands/PathPlannerAuto.h>
#include <pathplanner/lib/config/RobotConfig.h>
#include <pathplanner/lib/controllers/PPLTVController.h>
using namespace units::literals;

${cppMotor(p)}
using Motors=std::vector<std::shared_ptr<MotorIO>>;
class Mechanism:public frc2::SubsystemBase {
  Motors motors; double last=0;
public:
  Mechanism(std::string name,Motors configured):motors(std::move(configured)){SetName(name);}
  void Set(double output){last=frc::Timer::GetFPGATimestamp().value();for(auto&m:motors)m->Voltage(output*12);}
  void Stop(){for(auto&m:motors)m->Stop();}
  frc2::CommandPtr Action(double output,double timeout){return RunEnd([this,output]{Set(output);},[this]{Stop();}).WithTimeout(units::second_t{timeout});}
  void Periodic() override {if(frc::DriverStation::IsDisabled()||frc::Timer::GetFPGATimestamp().value()-last>0.1)Stop();}
};
class Drive:public frc2::SubsystemBase {
  Motors left{${side("left")}},right{${side("right")}};
  ${d.gyro === "Pigeon2" ? `ctre::phoenix6::hardware::Pigeon2 gyro{${d.gyroCan},ctre::phoenix6::CANBus{${q(d.gyroBus || "rio")}}};` : d.gyro === "NavX" ? `studica::AHRS gyro{studica::AHRS::NavXComType::${navxPort(d.navxInterface)}};` : "frc::ADXRS450_Gyro gyro;"}
  double conversion=3.141592653589793*${d.wheelDiameter}/${d.gearing};
  frc::DifferentialDriveKinematics kinematics{units::meter_t{${d.trackWidth}}};
  frc::DifferentialDriveOdometry odometry{gyro.GetRotation2d(),units::meter_t{Distance(left)},units::meter_t{Distance(right)}};
  frc::PIDController leftPID{${d.kP},0,0},rightPID{${d.kP},0,0};
  frc::Field2d field;double last=0;
  double Distance(const Motors& motors){double sum=0;for(auto&m:motors)sum+=m->Position();return motors.empty()?0:sum/motors.size()*conversion;}
  double Velocity(const Motors& motors){double sum=0;for(auto&m:motors)sum+=m->Velocity();return motors.empty()?0:sum/motors.size()*conversion;}
  void Voltage(double l,double r){last=frc::Timer::GetFPGATimestamp().value();for(auto&m:left)if(!m->Ready())l=r=0;for(auto&m:right)if(!m->Ready())l=r=0;for(auto&m:left)m->Voltage(l);for(auto&m:right)m->Voltage(r);}
  double FF(double v){return std::abs(v)<0.001?0:std::copysign(${d.kS},v)+${d.kV}*v;}
public:
  bool autoReady=false;
  Drive(){
    ${d.gyro === "ADXRS450" ? "gyro.Calibrate();" : ""}
    frc::SmartDashboard::PutData("Robot pose",&field);
    try {pathplanner::AutoBuilder::configure([this]{return Pose();},[this](frc::Pose2d pose){ResetPose(pose);},[this]{return Speeds();},[this](auto speeds,auto feedforwards){DriveSpeeds(speeds);},std::make_shared<pathplanner::PPLTVController>(0.02_s),pathplanner::RobotConfig::fromGUISettings(),[]{return frc::DriverStation::GetAlliance()==frc::DriverStation::Alliance::kRed;},this);autoReady=true;}
    catch(const std::exception&e){FRC_ReportError(frc::err::Error, "{}", std::string("Autonomous configuration failed: ")+e.what());}
  }
  frc::Pose2d Pose(){return odometry.GetPose();}
  void ResetPose(frc::Pose2d pose){odometry.ResetPosition(gyro.GetRotation2d(),units::meter_t{Distance(left)},units::meter_t{Distance(right)},pose);leftPID.Reset();rightPID.Reset();}
  frc::ChassisSpeeds Speeds(){return kinematics.ToChassisSpeeds({units::meters_per_second_t{Velocity(left)},units::meters_per_second_t{Velocity(right)}});}
  void Stop(){Voltage(0,0);leftPID.Reset();rightPID.Reset();}
  void Arcade(double forward,double turn){if(!frc::DriverStation::IsTeleopEnabled()){Stop();return;}double l=forward-turn,r=forward+turn,scale=std::max({1.0,std::abs(l),std::abs(r)});Voltage(l/scale*12*${c.maxOutput},r/scale*12*${c.maxOutput});}
  void DriveSpeeds(frc::ChassisSpeeds speeds){auto wheels=kinematics.ToWheelSpeeds(speeds);wheels.Desaturate(units::meters_per_second_t{${d.maxSpeed}});Voltage(FF(wheels.left.value())+leftPID.Calculate(Velocity(left),wheels.left.value()),FF(wheels.right.value())+rightPID.Calculate(Velocity(right),wheels.right.value()));}
  void Periodic() override {if(frc::DriverStation::IsDisabled()||frc::Timer::GetFPGATimestamp().value()-last>0.1)Stop();odometry.Update(gyro.GetRotation2d(),units::meter_t{Distance(left)},units::meter_t{Distance(right)});field.SetRobotPose(Pose());frc::SmartDashboard::PutNumber("Drive/left meters",Distance(left));frc::SmartDashboard::PutNumber("Drive/right meters",Distance(right));frc::SmartDashboard::PutBoolean("Drive/auto configured",autoReady);}
};
class Robot:public frc::TimedRobot {
  Drive drive;
  HardwareIO hardware;
  frc::GenericHID driver{${c.driverPort}},operatorController{${c.operatorPort}};
  ${mechanisms.map((s) => `Mechanism mechanism_${s.id}{${q(s.name)},Motors{${p.motors.filter((m) => m.subsystem === s.id).map(motor).join(",")}}};`).join("\n  ")}
  frc::SendableChooser<frc2::Command*> chooser;
  frc2::CommandPtr none=frc2::cmd::None();
  std::optional<frc2::CommandPtr> autoCommand;
  frc2::Command* selected=nullptr;
  double Deadband(double value){return std::abs(value)<=${c.deadband}?0:std::copysign((std::abs(value)-${c.deadband})/(1-${c.deadband}),value);}
  ${p.commands.map(cppAction).join("\n  ")}
  ${(p.routines || []).map((r) => routineSource(r, "C++")).join("\n  ")}
  void StopAll(){drive.Stop();hardware.StopAll();${mechanisms.map((s) => `mechanism_${s.id}.Stop();`).join("")}}
public:
  void RobotInit() override {
    frc::DataLogManager::Start();frc::DriverStation::StartDataLog(frc::DataLogManager::GetLog());
    drive.SetDefaultCommand(drive.RunEnd([this]{drive.Arcade(${c.forwardSign}*Deadband(driver.GetRawAxis(${c.forwardAxis})),${c.turnSign}*Deadband(driver.GetRawAxis(${c.turnAxis})));},[this]{drive.Stop();}));
    ${[...p.commands, ...p.routines || []].map((x) => `pathplanner::NamedCommands::registerCommand(${q(x.id)},Action_${x.id}());`).join("\n    ")}
    ${p.bindings.map((b) => `frc2::Trigger([this]{return frc::DriverStation::IsTeleopEnabled()&&${b.controller === "driver" ? "driver" : "operatorController"}.GetRawButton(${b.button});}).${b.behavior === "whileHeld" ? "WhileTrue" : b.behavior === "onPress" ? "OnTrue" : "ToggleOnTrue"}(Action_${b.command}());`).join("\n    ")}
    chooser.SetDefaultOption("Do nothing",none.get());
    if(drive.autoReady)try{autoCommand.emplace(pathplanner::PathPlannerAuto(${q(p.auto.name)}).ToPtr().WithTimeout(15_s).FinallyDo([this](bool){StopAll();}));chooser.AddOption(${q(p.auto.name)},autoCommand->get());}catch(const std::exception&e){FRC_ReportError(frc::err::Error, "{}", std::string("Auto failed to load: ")+e.what());}
    frc::SmartDashboard::PutData("Auto chooser",&chooser);
  }
  void RobotPeriodic() override {frc2::CommandScheduler::GetInstance().Run();}
  void AutonomousInit() override {StopAll();selected=chooser.GetSelected();if(selected)frc2::CommandScheduler::GetInstance().Schedule(selected);}
  void TeleopInit() override {if(selected)selected->Cancel();StopAll();}
  void DisabledInit() override {frc2::CommandScheduler::GetInstance().CancelAll();StopAll();}
  void TestInit() override {frc2::CommandScheduler::GetInstance().CancelAll();StopAll();}
};
#ifndef RUNNING_FRC_TESTS
int main(){return frc::StartRobot<Robot>();}
#endif
` };
}
//#endregion
//#region lib/generator.ts
function bezierWaypoints(points) {
	return points.map((anchor, i) => {
		const before = points[Math.max(0, i - 1)], after = points[Math.min(points.length - 1, i + 1)];
		const dx = (after.x - before.x) / 6, dy = (after.y - before.y) / 6;
		return {
			anchor,
			prevControl: i ? {
				x: anchor.x - dx,
				y: anchor.y - dy
			} : null,
			nextControl: i < points.length - 1 ? {
				x: anchor.x + dx,
				y: anchor.y + dy
			} : null,
			isLocked: false,
			linkedName: null
		};
	});
}
function pathFiles(p) {
	const a = p.auto, d = p.drive, w = a.waypoints;
	const heading = Math.atan2(w[1].y - w[0].y, w[1].x - w[0].x) * 180 / Math.PI;
	const path = {
		version: "2025.0",
		waypoints: bezierWaypoints(w),
		rotationTargets: [],
		constraintZones: [],
		pointTowardsZones: [],
		eventMarkers: [],
		globalConstraints: {
			maxVelocity: a.maxSpeed,
			maxAcceleration: a.maxAcceleration,
			maxAngularVelocity: 360,
			maxAngularAcceleration: 540,
			nominalVoltage: 12,
			unlimited: false
		},
		goalEndState: {
			velocity: 0,
			rotation: 0
		},
		reversed: false,
		folder: null,
		idealStartingState: {
			velocity: 0,
			rotation: heading
		},
		useDefaultConstraints: false
	};
	const settings = {
		robotWidth: d.trackWidth + .2,
		robotLength: .9,
		holonomicMode: false,
		pathFolders: [],
		autoFolders: [],
		defaultMaxVel: a.maxSpeed,
		defaultMaxAccel: a.maxAcceleration,
		defaultMaxAngVel: 360,
		defaultMaxAngAccel: 540,
		defaultNominalVoltage: 12,
		robotMass: d.mass,
		robotMOI: d.moi,
		robotTrackwidth: d.trackWidth,
		driveWheelRadius: d.wheelDiameter / 2,
		driveGearing: d.gearing,
		maxDriveSpeed: d.maxSpeed,
		driveMotorType: p.motors.find((m) => m.role === "left")?.type === "TalonFX" ? p.motors.find((m) => m.role === "left")?.motorKind === "falcon" ? "falcon500" : "krakenX60" : p.motors.find((m) => m.role === "left")?.type === "SparkFlex" ? "vortex" : "NEO",
		driveCurrentLimit: Math.min(...p.motors.filter((m) => m.subsystem === "drive").map((m) => m.current)),
		wheelCOF: 1.2
	};
	const auto = {
		version: "2025.0",
		command: {
			type: "sequential",
			data: { commands: a.steps.map((s) => s.type === "path" ? {
				type: "path",
				data: { pathName: a.name }
			} : s.type === "command" ? {
				type: "named",
				data: { name: s.command }
			} : {
				type: "wait",
				data: { waitTime: s.seconds }
			}) }
		},
		resetOdom: true,
		folder: null,
		choreoAuto: false
	};
	return Object.fromEntries([
		[`paths/${a.name}.path`, path],
		[`autos/${a.name}.auto`, auto],
		["settings.json", settings]
	].map(([name, data]) => ["pathplanner/" + name, JSON.stringify(data, null, 2)]));
}
function generateSources(p) {
	try {
		return {
			...p.language === "Java" ? javaSources(p) : p.language === "Python" ? pythonSources(p) : cppSources(p),
			...deviceSources(p),
			"HARDWARE.md": hardwareGuide(p),
			"LOGIC.md": logicGuide(p)
		};
	} catch {
		return { "Configuration.txt": "Resolve invalid configuration values in Preflight to preview generated source." };
	}
}
function readme(p) {
	const versions = versionsFor(p);
	return `# Team ${p.team}: ${p.name}\n\nGenerated by RobotForge for the 2026 FRC season.\n\n## Scope\nDifferential drive with encoder odometry, ADXRS450, Pigeon 2, or navX heading, open-loop mechanism commands, active-low forward DIO limits, command timeouts, driver mappings, and PathPlanner autonomous. This is generated source, not a certification of competition readiness. Swerve, vision fusion, advanced closed-loop mechanisms, and a drivetrain physics simulation are not included.\n\n## Build and run\n${p.language === "Python" ? `Install Python 3.12 and RobotPy ${versions.robotpy}. In this directory run:\n\n    python -m pip install robotpy==${versions.robotpy}\n    python -m robotpy sync\n    python -m robotpy sim\n    python -m robotpy deploy --team ${p.team}\n\nRobotPy deploys the deploy/ directory with the project.` : `Install the WPILib ${versions.wpilib} development environment and 2026 roboRIO toolchain. Open this folder in WPILib VS Code.\n\n    ${p.language === "Java" ? "./gradlew build" : "./gradlew build"}\n    ./gradlew simulate${p.language === "Java" ? "Java" : "Native"}\n    ./gradlew deploy\n\nOn Windows use gradlew.bat. On macOS/Linux, chmod +x gradlew if needed. The Gradle wrapper is included. Vendor metadata is pinned in vendordeps/.`}\n\n## Hardware assumptions\nThe motor model, controller, CAN bus, and electrical settings must match each physical device. PWM motor controllers and Victor SPX do not enforce a software current limit. Named CANivore networks are supported for Phoenix 6 devices; other CAN adapters use roboRIO CAN. See HARDWARE.md for every configured device. The motor output inversion and encoder sign are independent; verify each so forward motion increases both side distances. Drivetrain encoders are integrated motor-shaft encoders. Additional device readings and unit conversions are described in HARDWARE.md. Reduction is motor revolutions per wheel revolution. The ADXRS450 uses onboard SPI and must remain still while calibrating. Pigeon 2 must be mounted with its documented axes and positive counterclockwise heading.\n\n## Commission in order\n1. Verify all CAN IDs, firmware, wiring, current limits and DIO channels.\n2. Support the robot and start with the ${p.controls.maxOutput} teleop output cap. Verify motor directions, controller axes and encoder signs.\n3. Test disable, command timeout, release, interruption, limit switches and disconnect behavior.\n4. Measure wheel diameter, gear ratio, track width, mass, MOI and friction. Tune kS/kV/kP from measurements.\n5. Open deploy/pathplanner (Python) or src/main/deploy/pathplanner in PathPlanner 2026. Choose the correct game field. Confirm dimensions, blue-origin convention, alliance transforms, all path clearance and constraints. The canvas is a generic grid; no collision detection was performed.\n6. Build and simulate command flow. The included simulated sensor feedback is not a physical drivetrain model. Test all paths at reduced speed on the real robot.\n7. Select the autonomous routine in SmartDashboard/Elastic. Default is Do nothing. The generated routine is bounded to 15 seconds and all outputs stop on interruption and mode transitions.\n\nMechanism commands intentionally control duty cycle. An elevator, arm or precision shooter requires mentor-authored closed-loop control, sensor integration and appropriate bidirectional limits before use. A timed command does not establish a physical mechanism position.\n\n## Generated architecture\nMotorIO encapsulates vendor APIs; Drive owns all drive motors, gyro, odometry and velocity control. Each Mechanism owns its motors. Commands require their subsystem and always stop it on end. Dashboard exports robot pose, drive distances and readiness. A 100 ms output freshness watchdog and disabled checks stop stale outputs. Failed startup motor configuration inhibits output for that device.\n\n## Dependencies checked ${versions.checked}\nWPILib ${versions.wpilib}; RobotPy ${versions.robotpy}; REVLib ${p.language === "Python" ? versions.robotpyRev : versions.rev}; Phoenix 6 ${versions.phoenix}; PathPlannerLib ${versions.pathplanner}. Exact build versions are pinned in robotforge-libraries.lock.json. The accompanying project backup is frozen to these versions. The Libraries & updates page can check stable 2026 releases and opt into newer versions. Hardware selections automatically include their required libraries. HARDWARE.md describes each generated adapter and its remaining setup.\n\nOfficial references: https://docs.wpilib.org/ ; https://pathplanner.dev/ ; https://docs.revrobotics.com/ ; https://v6.docs.ctr-electronics.com/\n\nrobotforge-project.json is the editable configuration backup. Import it into RobotForge to continue. Regeneration replaces generated source; retain custom robot edits separately in version control.\n`;
}
async function assembleProject(p, asset) {
	const versions = versionsFor(p);
	const settings = librarySettings(p);
	validateLibraryLock(settings.lock);
	const errors = validate(p).filter((i) => i.level === "error");
	if (errors.length) throw Error(errors.map((i) => i.message).join("\n"));
	const files = {
		...generateSources(p),
		"robotforge-libraries.lock.json": JSON.stringify(settings.lock, null, 2),
		"README.md": readme(p),
		"robotforge-project.json": JSON.stringify({
			...p,
			libraries: {
				...settings,
				mode: "frozen"
			}
		}, null, 2),
		".gitignore": ".gradle/\nbuild/\n__pycache__/\n.venv/\n"
	};
	const deploy = p.language === "Python" ? "deploy/" : "src/main/deploy/";
	for (const [name, data] of Object.entries(pathFiles(p))) files[deploy + name] = data;
	if (p.language !== "Python") {
		const text = new TextDecoder();
		const template = await asset("/templates/" + (p.language === "Java" ? "java" : "cpp") + ".gradle");
		files["build.gradle"] = text.decode(template).replaceAll("###GRADLERIOREPLACE###", versions.wpilib).replaceAll("###ROBOTCLASSREPLACE###", "frc.robot.Main").replaceAll("includeDesktopSupport = false", "includeDesktopSupport = true").replaceAll("deleteOldFiles = false", "deleteOldFiles = true");
		files["settings.gradle"] = `pluginManagement { repositories { mavenLocal(); gradlePluginPortal(); maven { url 'https://frcmaven.wpi.edu/artifactory/release/' } } }\nrootProject.name = 'RobotForgeRobot'\n`;
		files[".wpilib/wpilib_preferences.json"] = JSON.stringify({
			enableCppIntellisense: p.language === "C++",
			currentLanguage: p.language.toLowerCase() === "c++" ? "cpp" : "java",
			projectYear: "2026",
			teamNumber: p.team
		}, null, 2);
		for (const id of selectedVendors(settings)) files["vendordeps/" + vendorRegistry[id].file] = JSON.stringify(validateManifest(id, settings.lock.vendors[id].manifest), null, 2);
		const vendors = ["WPILibNewCommands"];
		await Promise.all([...[
			"gradlew",
			"gradlew.bat",
			"gradle/wrapper/gradle-wrapper.jar",
			"gradle/wrapper/gradle-wrapper.properties"
		].map(async (f) => {
			files[f] = await asset("/templates/" + f);
		}), ...vendors.map(async (f) => {
			files["vendordeps/" + f + ".json"] = await asset("/vendor/" + f + ".json");
		})]);
	}
	return files;
}
function hardwareGuide(p) {
	return "# Hardware configuration\n\nGenerated adapters publish readings and validity under each device name in SmartDashboard. Sensor stop conditions stop on invalid readings; calibrate units and polarity before testing. Digital wiring failures that mimic a valid electrical state cannot be detected by software.\n\n" + (p.devices || []).map((d) => {
		const def = productById(d.product);
		return "## " + d.name + "\n" + def?.brand + " · " + def?.name + "\n\n" + def?.description + "\n\nConnection: " + def?.connection + "; bus " + d.bus + "; CAN ID " + d.address + "; channel " + d.channel + "; secondary " + d.channelB + "; parent module " + (d.module || "none") + "; subsystem " + d.subsystem + ". Scale " + d.scale + ", offset " + d.offset + ".\n\n" + d.notes + "\n\nGuide: " + def?.docs + "\n";
	}).join("\n") + "\nSolenoid commands de-energize on end; stored pneumatic energy and double-solenoid valve position may remain. Servo outputs disable on end. Blinkin uses 0.99 for black. CANdle expects its strip type configured in Phoenix Tuner. Limelight publishes telemetry only; no vision pose fusion or automatic aiming is generated. Mechanical module inventory does not generate swerve code.\n";
}
//#endregion
//#region lib/library-service.ts
const INDEX = "https://api.github.com/repos/wpilibsuite/vendor-json-repo/contents/2026";
const RAW = "https://raw.githubusercontent.com/wpilibsuite/vendor-json-repo/main/2026/";
const TTL = 3600 * 1e3;
let cache;
let pending;
async function json(url, fetcher) {
	const response = await fetcher(url, {
		headers: {
			Accept: "application/json",
			"User-Agent": "RobotForge-Library-Updates/1.1"
		},
		redirect: "manual",
		signal: AbortSignal.timeout(1e4)
	});
	if (!response.ok) throw Error(`Publisher returned HTTP ${response.status}`);
	const reader = response.body?.getReader();
	if (!reader) throw Error("Publisher returned an empty response");
	const chunks = [];
	let size = 0;
	while (true) {
		const { value, done } = await reader.read();
		if (done) break;
		size += value.length;
		if (size > 4e6) {
			await reader.cancel();
			throw Error("Publisher response exceeds the size limit");
		}
		chunks.push(value);
	}
	const bytes = new Uint8Array(size);
	let offset = 0;
	for (const chunk of chunks) {
		bytes.set(chunk, offset);
		offset += chunk.length;
	}
	return JSON.parse(new TextDecoder().decode(bytes));
}
function latestPython(data, short = false) {
	const candidates = Object.entries(data.releases || {}).filter(([v, files]) => isSeasonVersion(v, short) && Array.isArray(files) && files.some((f) => !f.yanked)).map(([v]) => v);
	candidates.sort(compareVersions);
	if (!candidates.length) throw Error("No stable release for this season");
	return candidates.at(-1);
}
function registryFile(index, id) {
	if (!Array.isArray(index)) throw Error("Invalid WPILib vendor index");
	const prefix = vendorRegistry[id].prefix;
	const names = index.map((f) => f.name).filter((name) => typeof name === "string" && name.startsWith(prefix) && name.endsWith(".json") && isVendorVersion(id, name.slice(prefix.length, -5)));
	names.sort((a, b) => compareVersions(a.slice(prefix.length, -5), b.slice(prefix.length, -5)));
	if (!names.length) throw Error("No stable vendor release for this season");
	return names.at(-1);
}
async function refreshLibraryCatalog(fetcher = fetch) {
	const checkedAt = (/* @__PURE__ */ new Date()).toISOString();
	const result = {
		lock: structuredClone(bundledLock),
		errors: [],
		checkedAt,
		sources: {}
	};
	const index = json(INDEX, fetcher).then((value) => ({ value }), (error) => ({ error }));
	const task = async (key, action) => {
		try {
			await action();
			result.sources[key] = "live";
		} catch (error) {
			result.sources[key] = "bundled";
			result.errors.push(`${key}: ${error instanceof Error ? error.message : "Update check failed"}. Keeping the saved version.`);
		}
	};
	await Promise.all([
		task("WPILib", async () => {
			const stable = (await json("https://api.github.com/repos/wpilibsuite/allwpilib/releases?per_page=100", fetcher)).filter((r) => !r.prerelease && !r.draft && isSeasonVersion(r.tag_name)).map((r) => r.tag_name.replace(/^v/, "")).sort(compareVersions);
			if (!stable.length) throw Error(`No stable ${SEASON} release`);
			result.lock.wpilib = stable.at(-1);
		}),
		task("RobotPy", async () => {
			result.lock.robotpy = latestPython(await json("https://pypi.org/pypi/robotpy/json", fetcher));
		}),
		...vendorIds.flatMap((id) => [task(vendorRegistry[id].name, async () => {
			let data;
			if (vendorRegistry[id].feed) try {
				data = validateManifest(id, await json(vendorRegistry[id].feed, fetcher));
			} catch {}
			if (!data) {
				const listing = await index;
				if ("error" in listing) throw listing.error;
				data = await json(RAW + registryFile(listing.value, id), fetcher);
			}
			result.lock.vendors[id].manifest = validateManifest(id, data);
		}), ...id === "thrifty" ? [] : [task(vendorRegistry[id].python, async () => {
			result.lock.vendors[id].python = latestPython(await json(`https://pypi.org/pypi/${vendorRegistry[id].python}/json`, fetcher), id === "ctre");
		})]])
	]);
	await task("Legacy CTRE Python compatibility", async () => {
		const match = ((await json("https://pypi.org/pypi/robotpy-ctre/" + result.lock.vendors.phoenix5.python + "/json", fetcher)).info.requires_dist.find((v) => v.toLowerCase().startsWith("phoenix6")) || "").match(/^phoenix6\s*~=\s*(26\.\d+)\.(\d+)$/i);
		if (!match) throw Error("Unrecognized Phoenix 6 constraint; retaining verified legacy package pair");
		const phoenix = await json("https://pypi.org/pypi/phoenix6/json", fetcher);
		const candidates = Object.keys(phoenix.releases).filter((v) => isSeasonVersion(v, true) && v.startsWith(match[1] + ".") && compareVersions(v, match[1] + "." + match[2]) >= 0 && phoenix.releases[v].some((f) => !f.yanked)).sort(compareVersions);
		if (!candidates.length) throw Error("No compatible stable Phoenix 6 Python release");
		result.lock.legacyPhoenix6 = candidates.at(-1);
	});
	if (result.sources["Legacy CTRE Python compatibility"] === "bundled") {
		result.lock.vendors.phoenix5.python = bundledLock.vendors.phoenix5.python;
		result.lock.legacyPhoenix6 = bundledLock.legacyPhoenix6;
	}
	result.lock.checkedAt = checkedAt;
	validateLibraryLock(result.lock);
	return result;
}
function getLibraryCatalog(force = false) {
	const maxAge = force || cache?.value.errors.length ? 6e4 : TTL;
	if (cache && Date.now() - cache.time < maxAge) return Promise.resolve(cache.value);
	if (!pending) pending = refreshLibraryCatalog().then((value) => {
		cache = {
			time: Date.now(),
			value
		};
		return value;
	}).finally(() => {
		pending = void 0;
	});
	return pending;
}
//#endregion
//#region companion/server.mjs
const PORT = 5819;
const SITE = "https://robot-forge-frc.paul-seed121071.chatgpt.site";
const digest = (value) => createHash("sha256").update(value).digest("hex");
const fail = (message, status = 400) => {
	throw Object.assign(new Error(message), { status });
};
const targetFor = (team, connection) => connection === "usb" ? "172.22.11.2" : `roborio-${team}-FRC.local`;
function runProcess(command, args, { cwd, log, signal }) {
	return new Promise((resolve, reject) => {
		const child = spawn(command, args, {
			cwd,
			shell: false,
			windowsHide: true,
			detached: process.platform !== "win32",
			stdio: [
				"ignore",
				"pipe",
				"pipe"
			],
			env: {
				...process.env,
				PYTHONUNBUFFERED: "1",
				PIP_DISABLE_PIP_VERSION_CHECK: "1"
			}
		});
		let stopped = false;
		const stop = () => {
			stopped = true;
			if (!child.pid) return;
			if (process.platform === "win32") spawn("taskkill.exe", [
				"/pid",
				String(child.pid),
				"/T",
				"/F"
			], {
				windowsHide: true,
				stdio: "ignore"
			});
			else try {
				process.kill(-child.pid, "SIGKILL");
			} catch {}
		};
		signal?.addEventListener("abort", stop, { once: true });
		if (signal?.aborted) stop();
		child.stdout.on("data", (data) => log(data.toString()));
		child.stderr.on("data", (data) => log(data.toString()));
		child.once("error", (error) => {
			signal?.removeEventListener("abort", stop);
			reject(/* @__PURE__ */ new Error(`Could not start ${path.basename(command)}. Check the companion setup guide. ${error.message}`));
		});
		child.once("close", (code) => {
			signal?.removeEventListener("abort", stop);
			if (stopped) reject(/* @__PURE__ */ new Error("Build cancelled."));
			else if (code === 0) resolve();
			else reject(/* @__PURE__ */ new Error(`${path.basename(command)} exited with code ${code}. Read the build log above.`));
		});
	});
}
async function findJava() {
	const roots = [
		process.env.ROBOTFORGE_JAVA_HOME,
		process.env.WPILIB_JAVA_HOME,
		path.join(process.env.PUBLIC || "C:/Users/Public", "wpilib/2026/jdk"),
		path.join(os.homedir(), "wpilib/2026/jdk"),
		process.env.JAVA_HOME
	];
	for (const root of roots.filter(Boolean)) {
		const file = path.join(root, "bin", process.platform === "win32" ? "java.exe" : "java");
		try {
			await fs.access(file);
			return file;
		} catch {}
	}
	return "java";
}
function createCompanion({ assets, root = path.join(os.homedir(), ".robotforge"), run = runProcess, catalog = getLibraryCatalog, token = randomBytes(24).toString("hex"), origins = [SITE], port = PORT }) {
	const allowed = new Set(origins);
	let job = null, busy = false, lastStart = 0;
	const log = (value) => {
		if (job) job.log = (job.log + value.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, "")).slice(-8e4);
	};
	const publicJob = () => job ? {
		id: job.id,
		state: job.state,
		team: job.project.team,
		language: job.project.language,
		target: job.target,
		connection: job.connection,
		offline: job.offline,
		fingerprint: job.fingerprint,
		startedAt: job.startedAt,
		log: job.log,
		libraries: job.librarySummary || null,
		error: job.error || null
	} : null;
	const fingerprint = (project, connection, offline) => digest(JSON.stringify({
		project,
		connection,
		offline
	}));
	async function execute(stage) {
		const current = job;
		const controller = new AbortController();
		current.controller = controller;
		const timer = setTimeout(() => controller.abort(), 1200 * 1e3);
		const invoke = async (command, args, cwd = current.directory) => {
			if (controller.signal.aborted) throw Error("Build cancelled or timed out.");
			log(`\n> ${path.basename(command)} ${args.join(" ")}\n`);
			await run(command, args, {
				cwd,
				log,
				signal: controller.signal
			});
		};
		try {
			if (stage === "build") {
				const settings = librarySettings(current.project);
				let lock = settings.lock;
				if (settings.mode === "automatic" && !current.offline) {
					log("Checking stable 2026 library releases…\n");
					const available = await catalog();
					lock = projectLibraryLock(current.project, mergeNewer(lock, available.lock));
					for (const warning of available.errors) log(`Update check: ${warning}\n`);
				}
				current.settings = {
					...settings,
					lock
				};
				current.buildProject = {
					...current.project,
					libraries: {
						...current.settings,
						mode: "frozen"
					}
				};
				current.librarySummary = [
					`WPILib ${lock.wpilib}`,
					`RobotPy ${lock.robotpy}`,
					...selectedVendors(settings).map((id) => `${vendorRegistry[id].name} ${current.project.language === "Python" ? lock.vendors[id].python : lock.vendors[id].manifest.version}`)
				].join(" · ");
				log(`Build library snapshot: ${current.librarySummary}\n`);
				await fs.mkdir(current.directory, { recursive: true });
				const files = await assembleProject(current.buildProject, async (name) => {
					if (!(name in assets)) throw Error(`Missing bundled template ${name}`);
					return Buffer.from(assets[name], "base64");
				});
				if (files["build.gradle"]) files["build.gradle"] += `\n// Deploy only to the address reviewed in RobotForge.\ndeploy.targets.roborio.locations.clear()\ndeploy.targets.roborio.addAddress('${current.target}')\n${current.project.language === "Java" ? "tasks.register('robotForgePrepare') { doLast { configurations.roborioRelease.resolve() } }" : ""}\n`;
				current.manifest = {};
				for (const [name, contents] of Object.entries(files)) {
					const dest = path.join(current.directory, name);
					await fs.mkdir(path.dirname(dest), { recursive: true });
					await fs.writeFile(dest, contents);
					current.manifest[name] = digest(contents);
				}
			} else for (const [name, hash] of Object.entries(current.manifest)) if (digest(await fs.readFile(path.join(current.directory, name))) !== hash) throw Error("Generated project changed on disk. Build again before deploying.");
			if (current.project.language === "Python") {
				const requirements = pythonRequirements(current.settings.lock, current.settings.extras);
				const venv = path.join(root, `python-${digest(JSON.stringify(requirements)).slice(0, 16)}`);
				const python = path.join(venv, process.platform === "win32" ? "Scripts/python.exe" : "bin/python");
				if (stage === "build") {
					if (!current.offline) {
						await invoke(process.env.ROBOTFORGE_PYTHON || (process.platform === "win32" ? "py" : "python3.12"), [
							...process.platform === "win32" && !process.env.ROBOTFORGE_PYTHON ? ["-3.12"] : [],
							"-m",
							"venv",
							venv
						]);
						await invoke(python, [
							"-m",
							"pip",
							"install",
							...requirements
						]);
						await invoke(python, [
							"-m",
							"robotpy",
							"sync",
							"--no-install",
							"--no-upgrade-project"
						]);
					}
					await invoke(python, [
						"-m",
						"compileall",
						"-q",
						"."
					]);
					await invoke(python, [
						"-m",
						"robotpy",
						"test",
						"--builtin"
					]);
				} else await invoke(python, [
					"-m",
					"robotpy",
					"deploy",
					"--builtin",
					"--robot",
					current.target
				]);
			} else {
				const java = await findJava();
				const args = [
					"-classpath",
					"gradle/wrapper/gradle-wrapper.jar",
					"org.gradle.wrapper.GradleWrapperMain",
					...stage === "deploy" ? ["deploy"] : current.project.language === "C++" ? ["frcUserProgramLinuxathenaReleaseExecutable"] : ["build", "robotForgePrepare"],
					"--console=plain",
					"--no-daemon",
					"-Ptoolchain-optional-desktop"
				];
				if (current.offline || stage === "deploy") args.push("--offline");
				await invoke(java, args);
			}
			if (controller.signal.aborted) throw Error("Operation timed out or was cancelled.");
			current.state = stage === "build" ? "ready" : "deployed";
			log(stage === "build" ? "\nBuild passed. Nothing has been sent to the robot. Review and confirm deployment in the app.\n" : "\nDeployment tool reported success. Check Driver Station and robot logs before enabling.\n");
		} catch (error) {
			current.state = controller.signal.aborted ? "cancelled" : "failed";
			current.error = error.message;
			log(`\n${error.message}\n`);
		} finally {
			clearTimeout(timer);
			busy = false;
		}
	}
	async function body(req) {
		if (!req.headers["content-type"]?.startsWith("application/json")) fail("JSON required.", 415);
		let text = "";
		for await (const chunk of req) {
			text += chunk;
			if (Buffer.byteLength(text) > 2e5) fail("Request too large.", 413);
		}
		try {
			return JSON.parse(text);
		} catch {
			fail("Invalid JSON.");
		}
	}
	const server = http.createServer(async (req, res) => {
		const send = (status, data) => {
			res.writeHead(status, {
				"Content-Type": "application/json",
				"Cache-Control": "no-store",
				"X-Content-Type-Options": "nosniff"
			});
			res.end(JSON.stringify(data));
		};
		try {
			if (req.headers.host !== `127.0.0.1:${server.address().port}`) fail("Invalid host.", 403);
			const origin = req.headers.origin;
			if (!allowed.has(origin)) fail("This site is not paired with this companion.", 403);
			res.setHeader("Access-Control-Allow-Origin", origin);
			res.setHeader("Vary", "Origin");
			if (req.method === "OPTIONS") {
				res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
				res.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
				res.setHeader("Access-Control-Allow-Private-Network", "true");
				res.writeHead(204);
				res.end();
				return;
			}
			const supplied = Buffer.from(req.headers.authorization || "");
			const expected = Buffer.from(`Bearer ${token}`);
			if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) fail("Pairing code is incorrect. Copy the code shown by your companion.", 401);
			if (req.method === "GET" && req.url === "/status") return send(200, {
				protocol: 4,
				version: "1.3.0",
				job: publicJob()
			});
			if (req.method !== "POST") fail("Not found.", 404);
			const data = await body(req);
			if (req.url === "/build") {
				if (busy) fail("Another operation is still running.", 409);
				if (Date.now() - lastStart < 1e3) fail("Please wait a moment before starting another build.", 429);
				const parsed = projectSchema.safeParse(data.project);
				if (!parsed.success) fail("Invalid robot configuration. Resolve the project errors first.");
				const project = parsed.data;
				const errors = validate(project).filter((issue) => issue.level === "error");
				if (errors.length) fail(errors.map((issue) => issue.message).join(" "));
				if (!["network", "usb"].includes(data.connection) || typeof data.offline !== "boolean") fail("Choose a valid connection and build mode.");
				const id = randomBytes(12).toString("hex");
				job = {
					id,
					project,
					connection: data.connection,
					offline: data.offline,
					target: targetFor(project.team, data.connection),
					fingerprint: fingerprint(project, data.connection, data.offline),
					state: "building",
					log: "",
					startedAt: (/* @__PURE__ */ new Date()).toISOString(),
					directory: path.join(root, "builds", id)
				};
				busy = true;
				lastStart = Date.now();
				execute("build");
				return send(202, { job: publicJob() });
			}
			if (!job || data.id !== job.id) fail("This build is no longer available. Build again.", 409);
			if (req.url === "/cancel") {
				if (job.state !== "building") fail("Only a build can be cancelled. Do not interrupt a robot upload.", 409);
				job.controller.abort();
				return send(202, { job: publicJob() });
			}
			if (req.url === "/deploy") {
				if (busy || job.state !== "ready") fail("A successful build is required before deployment.", 409);
				const parsed = projectSchema.safeParse(data.project);
				if (!parsed.success || fingerprint(parsed.data, data.connection, data.offline) !== job.fingerprint) fail("Configuration changed. Build again before deploying.", 409);
				if (data.confirmTeam !== String(job.project.team) || data.disabled !== true) fail("Confirm the team number and that the robot is disabled.");
				job.state = "deploying";
				busy = true;
				execute("deploy");
				return send(202, { job: publicJob() });
			}
			fail("Not found.", 404);
		} catch (error) {
			if (!res.headersSent) send(error.status || 500, { error: error.status ? error.message : "Companion error. Check its terminal and try again." });
		}
	});
	server.requestTimeout = 1e4;
	server.headersTimeout = 1e4;
	return {
		server,
		token,
		start: () => new Promise((resolve, reject) => {
			server.once("error", reject);
			server.listen(port, "127.0.0.1", resolve);
		}),
		stop: () => new Promise((resolve) => {
			if (job?.state === "building") job.controller.abort();
			server.close(resolve);
			server.closeIdleConnections();
		})
	};
}
//#endregion
//#region companion/main.mjs
const assets = JSON.parse(await fs.readFile(new URL("./assets.json", import.meta.url), "utf8"));
const origins = [SITE];
if (process.env.ROBOTFORGE_DEV_ORIGIN) {
	const url = new URL(process.env.ROBOTFORGE_DEV_ORIGIN);
	if (url.protocol !== "http:" || !["127.0.0.1", "localhost"].includes(url.hostname)) throw Error("Development origin must be a loopback HTTP URL.");
	origins.push(url.origin);
}
const companion = createCompanion({
	assets,
	origins
});
try {
	await companion.start();
} catch (error) {
	console.error(`Cannot start RobotForge Companion: ${error.message}. Close another running companion and retry.`);
	process.exit(1);
}
console.log(`\nRobotForge Companion 1.3.0\nListening on this computer only: 127.0.0.1:${PORT}\n\nOpen ${SITE}\nCode & export > Deploy to robot\n\nPairing code: ${companion.token}\n\nKeep this window open. The pairing code changes every time you restart.\nBuilds are saved in your home folder under .robotforge/builds.\nDo not close this window while deploying. Press Ctrl+C when finished.\n`);
//#endregion
export {};
