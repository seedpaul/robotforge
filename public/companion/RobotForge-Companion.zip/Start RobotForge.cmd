@echo off
cd /d "%~dp0"
node companion.mjs
pause
